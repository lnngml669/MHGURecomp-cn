// Cheat codes in Atmosphere's format (the one Ryujinx and a modded Switch use): every .txt file in cheats/ (beside
// mods/; MHGU_CHEATS_DIR overrides), in name order; a file whose name starts with '_' is skipped. A file holds any
// number of cheats: "[Name]" starts one, "{Name}" a master code (run before the others), then its code words, 8 hex
// digits each. Lines starting with '#' or "//" are comments. Every cheat found is on, except those listed in
// cheats/_off.txt (the settings' Cheats tab writes it: "<file>\t<cheat name>" per line; master codes are always on).
// A cheat turned off while the game runs stops running; the words of the game's code it changed get their original
// values back (so a code-changing cheat is undone), except those another cheat still on changed too, until that one
// is turned off as well. Anything else it wrote stays as it is.
// The codes run on Atmosphere's cheat virtual machine (every code type of its docs/features/cheats.md: written from
// that description), once before the game starts and then once per frame the game presents, from the window loop
// (as Atmosphere runs them beside the game). Memory regions: main is the main module (0x200000), heap, alias and aslr
// the regions GetInfo reports to the game; an address that is not mapped reads as 0 and is not written.
// A write into the game's code: the port runs code compiled ahead of time, which never sees it, so the function
// holding the changed word runs in the interpreter from then on (dispatch_interpret: that function alone, at the
// interpreter's speed); words written into the room after the code (padding up to the read-only data, where cheats
// put new code) are interpreted when the changed code jumps there. A call already running when the code changes
// finishes the old code.
#include <ctype.h>
#include <dirent.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>

#include "hle/input.h"
#include "cheats.h"
#include "interp.h"
#include "mods.h"
#include "rt.h"

#define NIB(w, i) (((w) >> (28 - 4 * (i))) & 15u)
#define MAX_OPS   1024
#define BUDGET    (1 << 20)  // instructions per cheat per run (a loop that never ends is cut off)

typedef struct {
    uint16_t type;  // 0x0-0xA: the top nybble; 0xC0-0xC4: the top byte; 0xFF0, 0xFF1, 0xFFF
    uint8_t n;      // words
    bool latched;   // (0xC4 without auto-repeat: its keys are still held since it ran)
    int jump;       // a block's begin or else: the op after its else / end; a loop's start: after its end, its end:
                    // after its start
    uint32_t w[5];
} Op;

typedef struct {
    uint32_t addr, word;  // a word of the game's code and its value before any cheat changed it
} Original;

typedef struct {
    char name[96], file[64];
    bool master;
    Op *ops;
    int nops;
    int on, ran;          // on: wanted (the settings set it, any thread); ran: running (the window loop's)
    bool stopping;        // (run_all: turned off this run)
    uint32_t *words;      // the code words it changed, to put back when it is turned off
    int nwords;
} Cheat;

#define MAX_CHEATS 4096
// Each cheat on its own, in a list that only grows: the settings (the game's thread) add cheats while the window loop
// runs them, so a cheat never moves, and ncheats goes up only once the new one is in place (cheats_rescan aside:
// it rebuilds the list while cheats_frame waits).
static Cheat *cheats[MAX_CHEATS];
static int ncheats;
static int count(void) { return __atomic_load_n(&ncheats, __ATOMIC_ACQUIRE); }
// Every code word a cheat changed, with its value from before any of them did: two cheats can change the same word,
// and the second one's "before" would be the first one's value.
static Original *orig;
static int norig;
static uint64_t reg[16], saved[16], statics[128];
static uint64_t keys;
static Cheat *cur;  // the one running (for the log, and the code words it changes)

const char *cheats_dir(void) {
    const char *e = getenv("MHGU_CHEATS_DIR");
    return e && *e ? e : "cheats";
}

void cheats_make_dir(void) {
    struct stat st;
    if (stat(cheats_dir(), &st)) mkdir(cheats_dir(), 0755);
}

// ------------------------------------------------------------------ decoding
static bool width_ok(uint32_t t) { return t == 1 || t == 2 || t == 4 || t == 8; }

static uint16_t op_type(uint32_t w) {
    uint32_t t = w >> 28;
    if (t < 0xC) return (uint16_t)t;
    if (t == 0xF && (w >> 24) == 0xFF) return (uint16_t)(w >> 20);
    return (uint16_t)(w >> 24);
}

// The op's word count from its first word (0: not a valid op).
static int op_words(uint32_t w) {
    switch (op_type(w)) {
    case 0x0: case 0x1: return width_ok(NIB(w, 1)) && NIB(w, 2) <= 4 ? (NIB(w, 1) == 8 ? 4 : 3) : 0;
    case 0x2: return NIB(w, 1) <= 1;
    case 0x3: return NIB(w, 1) == 0 ? 2 : NIB(w, 1) == 1;
    case 0x4: return 3;
    case 0x5: return width_ok(NIB(w, 1)) && NIB(w, 2) <= 4 && NIB(w, 4) <= 3 ? 2 : 0;
    case 0x6: return width_ok(NIB(w, 1)) ? 3 : 0;
    case 0x7: return width_ok(NIB(w, 1)) && NIB(w, 4) <= 4 ? 2 : 0;
    case 0x8: return 1;
    case 0x9:
        if (!width_ok(NIB(w, 1)) || NIB(w, 2) > 13 || (NIB(w, 2) >= 10 && NIB(w, 1) < 4)) return 0;
        return NIB(w, 5) == 1 ? (NIB(w, 1) == 8 ? 3 : 2) : NIB(w, 5) == 0;
    case 0xA:
        if (!width_ok(NIB(w, 1)) || NIB(w, 5) > 5) return 0;
        return NIB(w, 5) == 2 || NIB(w, 5) == 4 || NIB(w, 5) == 5 ? 2 : 1;
    case 0xC0:
        if (!width_ok(NIB(w, 2)) || NIB(w, 3) < 1 || NIB(w, 3) > 6 || NIB(w, 5) > 5) return 0;
        if (NIB(w, 5) == 0 || NIB(w, 5) == 2) return 2;
        return NIB(w, 5) == 4 ? (NIB(w, 2) == 8 ? 3 : 2) : 1;
    case 0xC1: return NIB(w, 6) <= 3;
    case 0xC2: return NIB(w, 2) <= 3;
    case 0xC3: return 1;
    case 0xC4: return 3;
    case 0xFF0: case 0xFF1: return 1;
    case 0xFFF:
        if (!width_ok(NIB(w, 3)) || NIB(w, 5) > 4) return 0;
        return NIB(w, 5) == 0 || NIB(w, 5) == 2 ? 2 : 1;
    }
    return 0;
}

static bool cond_ok(const Op *o) {  // (the condition nybble of 0x1)
    return o->type != 0x1 || (NIB(o->w[0], 3) >= 1 && NIB(o->w[0], 3) <= 6 && NIB(o->w[0], 4) <= 1);
}

// Words -> ops, with the blocks and loops matched. NULL (why in *err) if it does not decode.
static const char *decode(Cheat *ch, const uint32_t *w, int n) {
    ch->ops = calloc(MAX_OPS, sizeof(Op));
    int stack[64], depth = 0;
    for (int i = 0; i < n;) {
        int k = op_words(w[i]);
        if (!k) return "an unknown or invalid code";
        if (i + k > n) return "a code is cut short";
        if (ch->nops == MAX_OPS) return "too many codes";
        Op *o = &ch->ops[ch->nops];
        o->type = op_type(w[i]);
        o->n = (uint8_t)k;
        memcpy(o->w, w + i, k * 4);
        o->jump = -1;
        if (!cond_ok(o)) return "an invalid condition";
        bool begin = o->type == 0x1 || o->type == 0x8 || o->type == 0xC0 || o->type == 0xC4 ||
                     (o->type == 0x3 && NIB(o->w[0], 1) == 0);
        if (begin) {
            if (depth == 64) return "blocks nested too deep";
            stack[depth++] = ch->nops;
        } else if (o->type == 0x2 || o->type == 0x3) {  // else / end / end of loop
            bool loop_end = o->type == 0x3;
            if (!depth) return loop_end ? "an end of loop without its start" : "an end of block without its start";
            Op *b = &ch->ops[stack[depth - 1]];
            if ((b->type == 0x3) != loop_end) return "a block and a loop overlap";
            if (loop_end && NIB(b->w[0], 3) != NIB(o->w[0], 3)) return "a loop ends on another register";
            b->jump = ch->nops + 1;
            if (loop_end) o->jump = stack[depth - 1] + 1;
            if (o->type == 0x2 && NIB(o->w[0], 1) == 1) {  // else: the block goes on to its end
                if (b->type == 0x2) return "two elses in one block";
                stack[depth - 1] = ch->nops;
            } else {
                depth--;
            }
        }
        ch->nops++;
        i += k;
    }
    while (depth) ch->ops[stack[--depth]].jump = ch->nops;  // (open at the end: they end with the cheat)
    return NULL;
}

// ------------------------------------------------------------------ loading
// Checking a cheat pasted in the settings (cheats_add): decoded, not kept; the first problem goes in dry_err
static bool dry;
static char dry_err[200];
static int dry_count;

static void add_cheat(const char *file, const char *name, bool master, const uint32_t *w, int n, const char *bad) {
    Cheat ch = {0};
    snprintf(ch.name, sizeof ch.name, "%s", name);
    snprintf(ch.file, sizeof ch.file, "%s", file);
    ch.master = master;
    ch.on = 1;
    const char *err = bad ? bad : decode(&ch, w, n);
    if (dry) {
        if (err && !dry_err[0]) snprintf(dry_err, sizeof dry_err, "[%s]: %s", name, err);
        dry_count++;
        free(ch.ops);
        return;
    }
    if (err || ncheats == MAX_CHEATS) {
        LOG("[cheats] %s: [%s]: %s, the cheat is left out\n", file, name, err ? err : "too many cheats");
        free(ch.ops);
        return;
    }
    Cheat *c = malloc(sizeof *c);
    *c = ch;
    cheats[ncheats] = c;
    __atomic_store_n(&ncheats, ncheats + 1, __ATOMIC_RELEASE);
}

// The cheats in a file's text (s: its own copy). Codes before the first [name]: *stray.
static void parse_text(char *s, const char *file, bool *stray_out) {
    static uint32_t words[MAX_OPS * 4];
    int n = 0, before = ncheats;
    char name[96] = "";
    bool open = false, master = false, stray = false;
    const char *bad = NULL;
    for (char *p = s; *p;) {
        if (isspace((unsigned char)*p)) { p++; continue; }
        if (*p == '#' || (p[0] == '/' && p[1] == '/')) { while (*p && *p != '\n') p++; continue; }
        if (*p == '[' || *p == '{') {
            char close = *p == '[' ? ']' : '}';
            char *e = strchr(p + 1, close);
            if (!e) { LOG("[cheats] %s: a name without its '%c'\n", file, close); break; }
            if (open) add_cheat(file, name, master, words, n, bad);
            snprintf(name, sizeof name, "%.*s", (int)(e - p - 1), p + 1);
            master = *p == '{', open = true, n = 0, bad = NULL;
            p = e + 1;
            continue;
        }
        char *e = p;
        while (*e && !isspace((unsigned char)*e)) e++;
        bool hex = e - p == 8;
        for (char *q = p; hex && q < e; q++) hex = isxdigit((unsigned char)*q);
        if (!open) stray = true;
        else if (!hex) bad = bad ? bad : "something that is not a code word (8 hex digits)";
        else if (n < (int)(sizeof words / 4)) words[n++] = (uint32_t)strtoul(p, NULL, 16);
        else bad = "too many codes";
        p = e;
    }
    if (open) add_cheat(file, name, master, words, n, bad);
    *stray_out = stray;
    if (dry) return;
    if (stray) LOG("[cheats] %s: codes before the first [name] are left out\n", file);
    LOG("[cheats] %s: %d cheat(s)", file, ncheats - before);
    for (int i = before; i < ncheats; i++) LOG("%s%s%s%s", i == before ? ": " : ", ", cheats[i]->master ? "{" : "",
                                             cheats[i]->name, cheats[i]->master ? "}" : "");
    LOG("\n");
}

static void load_file(const char *path, const char *file) {
    FILE *f = fopen(path, "rb");
    if (!f) return;
    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *s = malloc(len + 1);
    len = (long)fread(s, 1, len, f);
    s[len] = 0;
    fclose(f);
    bool stray;
    parse_text(s, file, &stray);
    free(s);
}

static int cmp_name(const void *a, const void *b) { return strcasecmp(*(char *const *)a, *(char *const *)b); }

// ------------------------------------------------------------------ memory
static uint64_t region(uint32_t m) {
    switch (m) {
    case 0: return MAIN_BASE;
    case 1: return HEAP_BASE;
    case 2: return ALIAS_BASE;
    case 3: return MAIN_BASE;  // (the address space: GetInfo's ASLR region)
    default: return 0;         // 4: not relative
    }
}

static uint64_t mask(uint32_t t, uint64_t v) { return t == 8 ? v : v & ((1ull << (8 * t)) - 1); }

static uint64_t rd(uint64_t a, uint32_t t) {
    uint64_t v = 0;
    if (kernel_mapped(a, t)) memcpy(&v, G2H((uint32_t)a), t);
    return v;
}

// A changed word of the game's code: the function holding it runs in the interpreter from now on.
static void code_changed(uint32_t a) {
    const Module *m = &g_modules[a >= SDK_BASE];
    if (a >= m->base + m->text_off + m->text_size) {  // after the code (padding up to the read-only data): new code
        interp_add_range(a, a + 4);
        return;
    }
    uint32_t next, entry = dispatch_function_at(a, &next);
    if (!entry) return;
    uint32_t end = next ? next : m->base + m->text_off + m->text_size;
    int r = dispatch_interpret(entry, end);
    if (r > 0) LOG("[cheats] %s: changes the code at %s+%#x: the function at %s+%#x runs in the interpreter now\n",
                   cur->name, m->name, a - m->base, m->name, entry - m->base);
    else if (r < 0) LOG("[cheats] %s: changes the code at %s+%#x, which cannot take effect\n", cur->name, m->name,
                        a - m->base);
}

static void wr(uint64_t a, uint32_t t, uint64_t v) {
    if (!kernel_mapped(a, t)) return;
    uint8_t *p = G2H((uint32_t)a);
    bool code = false;
    for (int i = 0; i < 2 && i < g_nmodules; i++) {
        const Module *m = &g_modules[i];
        if (a < m->base + m->ro_off && a + t > m->base + m->text_off) code = true;
    }
    if (code && cur)  // (each word this cheat writes, and its original the first time any cheat does; also when
                      // another cheat already wrote the same value: this one keeps it changed too)
        for (uint32_t w = (uint32_t)a & ~3u; w < a + t; w += 4) {
            if (!kernel_mapped(w, 4)) continue;
            bool seen = false;
            for (int i = 0; i < cur->nwords && !seen; i++) seen = cur->words[i] == w;
            if (seen) continue;
            cur->words = realloc(cur->words, (cur->nwords + 1) * sizeof *cur->words);
            cur->words[cur->nwords++] = w;
            for (int i = 0; i < norig && !seen; i++) seen = orig[i].addr == w;
            if (seen) continue;
            orig = realloc(orig, (norig + 1) * sizeof *orig);
            orig[norig].addr = w;
            memcpy(&orig[norig++].word, G2H(w), 4);
        }
    if (code && !memcmp(p, &v, t)) return;
    memcpy(p, &v, t);
    if (code)
        for (uint32_t w = (uint32_t)a & ~3u; w < a + t; w += 4) code_changed(w);
}

// ------------------------------------------------------------------ running
static bool compare(uint32_t c, uint64_t a, uint64_t b) {
    switch (c) {
    case 1: return a > b;
    case 2: return a >= b;
    case 3: return a < b;
    case 4: return a <= b;
    case 5: return a == b;
    default: return a != b;
    }
}

static uint64_t arith(uint32_t op, uint32_t t, uint64_t a, uint64_t b) {
    if (op >= 10) {  // floats: T 4 single, 8 double
        if (t == 4) {
            float x, y, r;
            uint32_t xa = (uint32_t)a, xb = (uint32_t)b, out;
            memcpy(&x, &xa, 4), memcpy(&y, &xb, 4);
            r = op == 10 ? x + y : op == 11 ? x - y : op == 12 ? x * y : x / y;
            memcpy(&out, &r, 4);
            return out;
        }
        double x, y, r;
        memcpy(&x, &a, 8), memcpy(&y, &b, 8);
        r = op == 10 ? x + y : op == 11 ? x - y : op == 12 ? x * y : x / y;
        uint64_t out;
        memcpy(&out, &r, 8);
        return out;
    }
    uint64_t r;
    switch (op) {
    case 0: r = a + b; break;
    case 1: r = a - b; break;
    case 2: r = a * b; break;
    case 3: r = b < 64 ? a << b : 0; break;
    case 4: r = b < 64 ? a >> b : 0; break;
    case 5: r = a & b; break;
    case 6: r = a | b; break;
    case 7: r = ~a; break;
    case 8: r = a ^ b; break;
    default: r = a; break;  // 9: move
    }
    return mask(t, r);
}

static uint64_t imm(const Op *o, int i, uint32_t t) {  // a value word (two for width 8: high, low)
    return t == 8 ? (uint64_t)o->w[i] << 32 | o->w[i + 1] : o->w[i];
}

static uint64_t addr40(const Op *o) { return (uint64_t)(o->w[0] & 0xFF) << 32 | o->w[1]; }
static uint64_t addr36(const Op *o) { return (uint64_t)(o->w[0] & 0xF) << 32 | o->w[1]; }

// Each cheat starts with its registers and saved registers at 0 (as Ryujinx runs them, each on its own): a cheat
// that leaves a register set must not move the next one's writes, which add a register to their address (0TMR...:
// R, mostly 0). Static registers are shared: they are how cheats pass values on.
static void run(Cheat *ch) {
    cur = ch;
    memset(reg, 0, sizeof reg);
    memset(saved, 0, sizeof saved);
    int budget = BUDGET;
    for (int i = 0; i < ch->nops && budget--;) {
        Op *o = &ch->ops[i];
        uint32_t w = o->w[0];
        int next = i + 1;
        switch (o->type) {
        case 0x0: {  // store a value: 0TMR00AA AAAAAAAA V
            uint32_t t = NIB(w, 1);
            wr(region(NIB(w, 2)) + addr40(o) + reg[NIB(w, 3)], t, mask(t, imm(o, 2, t)));
            break;
        }
        case 0x1: {  // memory condition: 1TMCXrAA AAAAAAAA V
            uint32_t t = NIB(w, 1);
            uint64_t a = region(NIB(w, 2)) + addr40(o) + (NIB(w, 4) ? reg[NIB(w, 5)] : 0);
            if (!compare(NIB(w, 3), rd(a, t), mask(t, imm(o, 2, t)))) next = o->jump;
            break;
        }
        case 0x2:  // end, or else reached at the end of the taken part: on past the block
            if (NIB(w, 1) == 1) next = o->jump;
            break;
        case 0x3:
            if (NIB(w, 1) == 0) {  // loop start: 300R0000 V
                reg[NIB(w, 3)] = o->w[1];
                if (!o->w[1]) next = o->jump;
            } else if (reg[NIB(w, 3)] && --reg[NIB(w, 3)]) {  // loop end: 310R0000
                next = o->jump;
            }
            break;
        case 0x4:  // load a value: 400R0000 V V
            reg[NIB(w, 3)] = (uint64_t)o->w[1] << 32 | o->w[2];
            break;
        case 0x5: {  // load from memory: 5TMRIS AA AAAAAAAA
            uint32_t t = NIB(w, 1), r = NIB(w, 3), s = NIB(w, 5);
            uint64_t a = addr40(o);
            switch (NIB(w, 4)) {
            case 0: a += region(NIB(w, 2)); break;
            case 1: a += reg[r]; break;
            case 2: a += reg[s]; break;
            default: a += region(NIB(w, 2)) + reg[s]; break;
            }
            reg[r] = rd(a, t);
            break;
        }
        case 0x6: {  // store a value at a register's address: 6T0RIor0 V V
            uint32_t t = NIB(w, 1), r = NIB(w, 3);
            wr(reg[r] + (NIB(w, 5) ? reg[NIB(w, 6)] : 0), t, mask(t, (uint64_t)o->w[1] << 32 | o->w[2]));
            if (NIB(w, 4)) reg[r] += t;
            break;
        }
        case 0x7: {  // legacy arithmetic: 7T0RC000 V
            uint32_t t = NIB(w, 1), r = NIB(w, 3);
            reg[r] = arith(NIB(w, 4), t, reg[r], o->w[1]);
            break;
        }
        case 0x8: {  // keys held: 8kkkkkkk
            uint64_t k = w & 0x0FFFFFFFu;
            if ((keys & k) != k) next = o->jump;
            break;
        }
        case 0x9: {  // arithmetic: 9TCRS0s0 / 9TCRS100 V
            uint32_t t = NIB(w, 1);
            uint64_t b = NIB(w, 5) ? imm(o, 1, t) : reg[NIB(w, 6)];
            reg[NIB(w, 3)] = arith(NIB(w, 2), t, mask(t, reg[NIB(w, 4)]), mask(t, b));
            break;
        }
        case 0xA: {  // store a register: ATSRIOxa (aaaaaaaa)
            uint32_t t = NIB(w, 1), r = NIB(w, 3), x = NIB(w, 6);
            uint64_t a;
            switch (NIB(w, 5)) {
            case 0: a = reg[r]; break;
            case 1: a = reg[r] + reg[x]; break;
            case 2: a = reg[r] + addr36(o); break;
            case 3: a = region(x) + reg[r]; break;
            case 4: a = region(x) + addr36(o); break;
            default: a = region(x) + addr36(o) + reg[r]; break;
            }
            wr(a, t, mask(t, reg[NIB(w, 2)]));
            if (NIB(w, 4)) reg[r] += t;
            break;
        }
        case 0xC0: {  // register condition: C0TcSX..
            uint32_t t = NIB(w, 2), x6 = NIB(w, 6), x7 = NIB(w, 7);
            uint64_t b;
            switch (NIB(w, 5)) {
            case 0: b = rd(region(x6) + addr36(o), t); break;
            case 1: b = rd(region(x6) + reg[x7], t); break;
            case 2: b = rd(reg[x6] + addr36(o), t); break;
            case 3: b = rd(reg[x6] + reg[x7], t); break;
            case 4: b = imm(o, 1, t); break;
            default: b = reg[x6]; break;
            }
            if (!compare(NIB(w, 3), mask(t, reg[NIB(w, 4)]), mask(t, b))) next = o->jump;
            break;
        }
        case 0xC1: {  // save / restore a register: C10D0Sx0
            uint32_t d = NIB(w, 3), s = NIB(w, 5);
            switch (NIB(w, 6)) {
            case 0: reg[d] = saved[s]; break;
            case 1: saved[d] = reg[s]; break;
            case 2: saved[d] = 0; break;
            default: reg[d] = 0; break;
            }
            break;
        }
        case 0xC2:  // the same by a mask: C2x0XXXX
            for (int k = 0; k < 16; k++) {
                if (!(w >> k & 1)) continue;
                switch (NIB(w, 2)) {
                case 0: reg[k] = saved[k]; break;
                case 1: saved[k] = reg[k]; break;
                case 2: saved[k] = 0; break;
                default: reg[k] = 0; break;
                }
            }
            break;
        case 0xC3: {  // static register: C3000XXx (XX 0x00-0x7F read, 0x80-0xFF write)
            uint32_t s = (w >> 4) & 0xFF;
            if (s < 0x80) reg[w & 15] = statics[s];
            else statics[s & 0x7F] = reg[w & 15];
            break;
        }
        case 0xC4: {  // keys held, extended: C4r00000 K K (r 0: once per press)
            uint64_t k = (uint64_t)o->w[1] << 32 | o->w[2];
            bool held = (keys & k) == k, fire = held && (NIB(w, 2) || !o->latched);
            o->latched = held;
            if (!fire) next = o->jump;
            break;
        }
        case 0xFF0: case 0xFF1: {  // pause / resume the game: not done here
            static bool said;
            if (!said) said = true, LOG("[cheats] %s: pausing / resuming the game is not supported\n", ch->name);
            break;
        }
        case 0xFFF: {  // debug log: FFFTIX..
            uint32_t t = NIB(w, 3), x6 = NIB(w, 6), x7 = NIB(w, 7);
            uint64_t v;
            switch (NIB(w, 5)) {
            case 0: v = rd(region(x6) + addr36(o), t); break;
            case 1: v = rd(region(x6) + reg[x7], t); break;
            case 2: v = rd(reg[x6] + addr36(o), t); break;
            case 3: v = rd(reg[x6] + reg[x7], t); break;
            default: v = mask(t, reg[x6]); break;
            }
            LOG("[cheats] %s: log %x: %#llx\n", ch->name, NIB(w, 4), (unsigned long long)v);
            break;
        }
        }
        i = next;
    }
    if (budget < 0) LOG("[cheats] %s: ran too long (a loop that never ends?): stopped for this frame\n", ch->name);
}

// A cheat turned off: the code words it changed get their values from before any cheat changed them back, except
// those a cheat still running changed too (it keeps them as it wants them; the last of them turned off puts them back).
static void undo(Cheat *ch) {
    cur = NULL;  // (putting a word back is not a change to remember)
    int back = 0, kept = 0;
    for (int i = 0; i < ch->nwords; i++) {
        uint32_t w = ch->words[i];
        bool shared = false;
        for (int k = 0, nk = count(); k < nk && !shared; k++)
            if (cheats[k]->ran)
                for (int j = 0; j < cheats[k]->nwords && !shared; j++) shared = cheats[k]->words[j] == w;
        if (shared) { kept++; continue; }
        int o = 0;
        while (o < norig && orig[o].addr != w) o++;
        if (o == norig) continue;
        uint8_t *p = G2H(w);
        if (memcmp(p, &orig[o].word, 4)) {
            memcpy(p, &orig[o].word, 4);
            code_changed(w);  // (stays in the interpreter: now with the original code)
            back++;
        }
        orig[o] = orig[--norig];  // (the game's own again)
    }
    if (kept && back)
        LOG("[cheats] %s: off, %d word(s) of code put back, %d kept by cheats still on\n", ch->name, back, kept);
    else if (kept) LOG("[cheats] %s: off, %d word(s) of code kept by cheats still on\n", ch->name, kept);
    else if (back) LOG("[cheats] %s: off, %d word(s) of code put back\n", ch->name, back);
    else LOG("[cheats] %s: off\n", ch->name);
    free(ch->words);
    ch->words = NULL, ch->nwords = 0;
}

static void run_all(void) {
    int n = count();  // (cheats the settings add from now on: the next frame)
    for (int i = 0; i < n; i++) {  // (every cheat's new state first: undo asks which ones keep running)
        Cheat *ch = cheats[i];
        bool on = ch->master || __atomic_load_n(&ch->on, __ATOMIC_ACQUIRE);
        ch->stopping = !on && ch->ran;
        if (on && !ch->ran && g_present_count) LOG("[cheats] %s: on\n", ch->name);
        ch->ran = on;
    }
    for (int i = 0; i < n; i++)
        if (cheats[i]->stopping) undo(cheats[i]);
    for (int pass = 0; pass < 2; pass++)  // master codes first
        for (int i = 0; i < n; i++)
            if (cheats[i]->master == !pass && cheats[i]->ran) run(cheats[i]);
}

// ------------------------------------------------------------------ on / off (the settings' Cheats tab)
#define OFF_FILE "_off.txt"  // (a '_' name: not read as cheats)
static void off_path(char *out, size_t n) { snprintf(out, n, "%s/" OFF_FILE, cheats_dir()); }

static void load_off(void) {
    char path[1024], line[256];
    off_path(path, sizeof path);
    FILE *f = fopen(path, "rb");
    if (!f) return;
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = 0;
        char *tab = strchr(line, '\t');
        if (line[0] == '#' || !tab) continue;
        *tab = 0;
        for (int i = 0; i < ncheats; i++)
            if (!strcmp(cheats[i]->file, line) && !strcmp(cheats[i]->name, tab + 1)) cheats[i]->on = 0;
    }
    fclose(f);
}

int cheats_count(void) { return count(); }
const char *cheats_name(int i) { return i >= 0 && i < count() ? cheats[i]->name : ""; }
const char *cheats_file(int i) { return i >= 0 && i < count() ? cheats[i]->file : ""; }
bool cheats_master(int i) { return i >= 0 && i < count() && cheats[i]->master; }
bool cheats_on(int i) { return i >= 0 && i < count() && (cheats[i]->master || __atomic_load_n(&cheats[i]->on, __ATOMIC_ACQUIRE)); }

bool cheats_set(const bool *on, int n, char *err, size_t errsz) {
    char path[1024], tmp[1040];
    off_path(path, sizeof path);
    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    cheats_make_dir();
    FILE *f = fopen(tmp, "wb");
    if (!f) { snprintf(err, errsz, "Could not write %s", path); return false; }
    fputs("# Cheats turned off in the settings (the Cheats tab writes this file): <file><tab><cheat name>\n", f);
    int total = count();
    for (int i = 0; i < total && i < n; i++)
        if (!on[i] && !cheats[i]->master) fprintf(f, "%s\t%s\n", cheats[i]->file, cheats[i]->name);
    bool ok = !ferror(f);
    ok = !fclose(f) && ok;
#ifdef _WIN32
    if (ok) remove(path);  // (Windows' rename won't replace a file; this one is small and rewritten whole)
#endif
    if (!ok || rename(tmp, path)) { remove(tmp); snprintf(err, errsz, "Could not write %s", path); return false; }
    for (int i = 0; i < total && i < n; i++) __atomic_store_n(&cheats[i]->on, on[i] ? 1 : 0, __ATOMIC_RELEASE);
    return true;
}

// ------------------------------------------------------------------ adding one (the settings' "Add a cheat")
#define ADDED_FILE "added.txt"  // (in cheats/: read with the others at the next start)

bool cheats_add(const char *text, char *err, size_t errsz) {
    char *s = strdup(text);
    bool stray = false;
    dry = true, dry_err[0] = 0, dry_count = 0;
    parse_text(s, ADDED_FILE, &stray);
    dry = false;
    free(s);
    if (dry_err[0]) { snprintf(err, errsz, "%s", dry_err); return false; }
    if (stray && !dry_count) { snprintf(err, errsz, "No cheat name: the codes need a [Name] line above them"); return false; }
    if (!dry_count) { snprintf(err, errsz, "No cheat found: paste a [Name] line and its codes"); return false; }
    if (stray) { snprintf(err, errsz, "Codes before the first [Name] line: give them a name"); return false; }
    if (count() + dry_count > MAX_CHEATS) { snprintf(err, errsz, "Too many cheats"); return false; }
    char path[1024];
    snprintf(path, sizeof path, "%s/" ADDED_FILE, cheats_dir());
    cheats_make_dir();
    FILE *f = fopen(path, "ab");
    bool ok = f && fprintf(f, "\n%s\n", text) >= 0;
    ok = f && !fclose(f) && ok;
    if (!ok) { snprintf(err, errsz, "Could not write %s", path); return false; }
    s = strdup(text);
    parse_text(s, ADDED_FILE, &stray);  // (on from the next frame: cheats_frame)
    free(s);
    return true;
}

// ------------------------------------------------------------------ entry points
// The cheats folder, every file in name order, into cheats
static void load_dir(void) {
    DIR *d = opendir(cheats_dir());
    if (!d) return;
    char *names[256];
    int n = 0;
    struct dirent *e;
    while ((e = readdir(d)) && n < 256) {
        size_t l = strlen(e->d_name);
        if (e->d_name[0] != '_' && e->d_name[0] != '.' && l > 4 && !strcasecmp(e->d_name + l - 4, ".txt"))
            names[n++] = strdup(e->d_name);
    }
    closedir(d);
    qsort(names, n, sizeof *names, cmp_name);
    for (int i = 0; i < n; i++) {
        char path[1024];
        snprintf(path, sizeof path, "%s/%s", cheats_dir(), names[i]);
        load_file(path, names[i]);
        free(names[i]);
    }
}

void cheats_init(void) {
    load_dir();
    for (int i = 0; i < ncheats; i++) cheats[i]->on = 1;
    load_off();
    for (int i = 0; i < ncheats; i++)
        if (!cheats[i]->master && !cheats[i]->on) LOG("[cheats] %s: off (turned off in the settings)\n", cheats[i]->name);
    if (ncheats) run_all();  // (before the game starts: changes to its code are in place from the start)
}

static bool same_codes(const Cheat *a, const Cheat *b) {
    if (a->master != b->master || a->nops != b->nops) return false;
    for (int i = 0; i < a->nops; i++)
        if (a->ops[i].n != b->ops[i].n || memcmp(a->ops[i].w, b->ops[i].w, sizeof(uint32_t) * a->ops[i].n)) return false;
    return true;
}

// The settings menu, as it opens (its thread): the cheats folder read again. A cheat still there with the same codes
// keeps running as it was; one whose codes changed first gets what the old codes changed in the game's code put back
// (as when it is turned off), then runs its new codes from the next frame; one gone from the folder is undone and
// dropped; a new one is on unless _off.txt says otherwise. The one time the list does not only grow: cheats_frame
// skips the frames this takes (cheats_mu), and the settings' other calls are on this same thread.
static pthread_mutex_t cheats_mu = PTHREAD_MUTEX_INITIALIZER;
void cheats_rescan(void) {
    pthread_mutex_lock(&cheats_mu);
    int nold = ncheats, added = 0, changed = 0, gone = 0;
    Cheat **old = malloc(sizeof *old * (nold + 1));
    memcpy(old, cheats, sizeof *old * nold);
    __atomic_store_n(&ncheats, 0, __ATOMIC_RELEASE);
    load_dir();
    bool *taken = calloc(nold + 1, 1);
    for (int i = 0; i < ncheats; i++) {
        Cheat *ch = cheats[i];
        int j = 0;
        while (j < nold && (taken[j] || strcmp(old[j]->file, ch->file) || strcmp(old[j]->name, ch->name))) j++;
        if (j == nold) { ch->on = 1, added++; continue; }
        taken[j] = true;
        ch->on = old[j]->on;
        if (same_codes(ch, old[j])) {  // (as it was: running state and the code words it changed)
            ch->ran = old[j]->ran, ch->words = old[j]->words, ch->nwords = old[j]->nwords;
            old[j]->ran = 0, old[j]->words = NULL, old[j]->nwords = 0;
        } else {
            changed++;
        }
    }
    // Only now the undoing: it asks which cheats keep running, so every cheat that stays must be in the list by now
    // (the code words one of them changed too stay changed).
    for (int j = 0; j < nold; j++) {
        if (!taken[j]) gone++;
        if (old[j]->ran) undo(old[j]);
        free(old[j]->ops);
        free(old[j]->words);
        free(old[j]);
    }
    free(taken);
    free(old);
    load_off();
    if (added || changed || gone)
        LOG("[cheats] folder read again: %d new, %d with new codes, %d gone; %d cheat(s) now\n", added, changed, gone, ncheats);
    pthread_mutex_unlock(&cheats_mu);
}

void cheats_frame(void) {
    static uint64_t last;
    if (!count() || g_present_count == last) return;
    if (pthread_mutex_trylock(&cheats_mu)) return;  // (cheats_rescan: next frame)
    last = g_present_count;
    uint64_t b;
    int32_t s[4];
    input_get(&b, s);
    enum { T = 16384 };  // (stick directions: half way)
    b &= 0xFFFF;
    if (s[0] < -T) b |= 1u << 16;
    if (s[1] > T) b |= 1u << 17;
    if (s[0] > T) b |= 1u << 18;
    if (s[1] < -T) b |= 1u << 19;
    if (s[2] < -T) b |= 1u << 20;
    if (s[3] > T) b |= 1u << 21;
    if (s[2] > T) b |= 1u << 22;
    if (s[3] < -T) b |= 1u << 23;
    keys = b;
    run_all();
    pthread_mutex_unlock(&cheats_mu);
}
