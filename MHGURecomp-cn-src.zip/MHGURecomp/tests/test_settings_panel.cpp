// Controller navigation exercised against the real ImGui frame loop.
#include "settings_panel.h"
#include "config.h"
#include "app_actions.h"
#include "overlay.h"
#include "modorder.h"
#include "imgui_internal.h"
#include <SDL3/SDL.h>
#include <cassert>
#include <cstdio>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <iterator>
#include <thread>
#include <filesystem>
#include <fstream>
#include <string>
static int requested;
extern "C" const char *g_game_dir = "obj/settings-test/game";  // (modorder.c compares archives with the game's)
extern "C" volatile uint64_t g_present_count = 0;  // (runtime/ui.c's frame counter: config.c's model previews read it)
extern "C" void ui_request_action(bool restart) { requested = restart ? 2 : 1; }
extern "C" bool ui_action_failed(void) { return false; }
extern "C" int host_input_last_device(void) { return 0; }
extern "C" int host_input_sw_sources(int, int, int *, int) { return 0; }
extern "C" int host_input_held(int *, int) { return 0; }
extern "C" bool input_view_dash_zr(void) { return false; }
extern "C" void input_view_apply(void) {}  // (the game side of the action layer: nothing to hook here)
static int import_requested;
static const char *picked_folder;  // (what the folder picker "chose": ui_take_picked_folder hands it out once)
extern "C" void ui_request_import(int what) { import_requested = what; }
extern "C" int ui_take_picked_folder(char *out, size_t size) {
    if (!picked_folder) return 0;
    SDL_strlcpy(out, picked_folder, size);
    picked_folder = nullptr;
    return 4;
}
extern "C" int ldn_hub_status(const char *, const char *, int *, int *) { return 0; }
extern "C" void ldn_hub_check(const char *, const char *) {}
extern "C" bool forge_plugins_have(int) { return false; }  // (no Forge plugins started)
extern "C" int forge_plugin_titles(const char **, int) { return 0; }
// (cheats.c: two cheats, a master code and one that can be turned off)
static bool cheat_on[2] = {true, true};
extern "C" int cheats_count(void) { return 2; }
extern "C" void cheats_rescan(void) {}
extern "C" const char *cheats_name(int i) { return i ? "Test cheat" : "Master"; }
extern "C" const char *cheats_file(int i) { (void)i; return "test.txt"; }
extern "C" bool cheats_master(int i) { return i == 0; }
extern "C" bool cheats_on(int i) { return cheat_on[i]; }
extern "C" bool cheats_set(const bool *on, int n, char *, size_t) {
    for (int i = 0; i < n && i < 2; i++)
        cheat_on[i] = on[i];
    return true;
}
extern "C" bool cheats_add(const char *, char *err, size_t n) {  // (Add a cheat: not reached here)
    snprintf(err, n, "not in the test");
    return false;
}
extern "C" int overlay_face_position(int semantic) {
    const int p[] = {1, 0, 3, 2};
    return p[semantic];
}
static bool opened = true;
static void frame() {
    settings_panel_before_frame(opened);
    ImGui::NewFrame();
    settings_panel(&opened);
    ImGui::Render();
}
static void idle(int n = 3) {
    while (n--)
        frame();
}
static void press(ImGuiKey key) {
    ImGui::GetIO().AddKeyEvent(key, true);
    idle();
    ImGui::GetIO().AddKeyEvent(key, false);
    idle();
}
static ImGuiID id(const char *name) {  // (a dropdown's choices are in a window of their own)
    auto *w = ImGui::FindWindowByName(strncmp(name, "choice.", 7) ? "Settings##main" : "Settings##dropdown");
    assert(w);
    return ImHashStr("###row", 0, ImHashStr(name, 0, w->ID));
}
static void selected(const char *name) {
    auto &g = *ImGui::GetCurrentContext();
    if (g.NavId != id(name))
        fprintf(stderr, "focus %s: %x != %x\n", name, g.NavId, id(name));
    assert(g.NavId == id(name));
    assert(g.NavCursorVisible);
}
static float pinned_content_bottom() {
    auto *w = ImGui::FindWindowByName("Settings##main");
    float bottom = 0;
    for (const auto &command : w->DrawList->CmdBuffer) {
        auto clip = command.ClipRect;
        if (command.ElemCount && clip.x == w->InnerClipRect.Min.x && clip.z == w->InnerClipRect.Max.x &&
            clip.w < w->InnerClipRect.Max.y - 1 && clip.w > bottom)
            bottom = clip.w;
    }
    assert(bottom > w->InnerClipRect.Min.y);
    return bottom;
}
static float pinned_content_top() {
    auto *w = ImGui::FindWindowByName("Settings##main");
    float top = 0;
    for (const auto &command : w->DrawList->CmdBuffer) {
        auto clip = command.ClipRect;
        if (command.ElemCount && clip.x == w->InnerClipRect.Min.x && clip.z == w->InnerClipRect.Max.x &&
            clip.w < w->InnerClipRect.Max.y - 1 && clip.y > top)
            top = clip.y;
    }
    assert(top > w->InnerClipRect.Min.y);
    return top;
}
static void down(int n = 1) {
    while (n--)
        press(ImGuiKey_GamepadDpadDown);
}
static void tab() { press(ImGuiKey_GamepadR1); }
static void back() { press(ImGuiKey_GamepadFaceRight); }
static void confirm() { press(ImGuiKey_GamepadFaceDown); }
int main() {
#ifdef _WIN32
    _putenv_s("MHGU_CONFIG", "obj/settings-test/panel-settings.ini");
#else
    setenv("MHGU_CONFIG", "obj/settings-test/panel-settings.ini", 1);
#endif
    // Mods tab fixtures: Aaa (two files) and Bbb (one) both replace a.bin, Ccc stands alone, Ddd is off ('_')
    namespace fs = std::filesystem;
    fs::remove_all("obj/settings-test/mods");
    auto put = [](const char *path, const char *text) {
        fs::create_directories(fs::path(path).parent_path());
        std::ofstream(path, std::ios::binary) << text;
    };
    put("obj/settings-test/mods/Aaa/romfs/a.bin", "1");
    put("obj/settings-test/mods/Aaa/romfs/b.bin", "bb");
    put("obj/settings-test/mods/Bbb/romfs/a.bin", "22");
    put("obj/settings-test/mods/Ccc/romfs/c.bin", "3");
    put("obj/settings-test/mods/_Ddd/romfs/d.bin", "4");
#ifdef _WIN32
    _putenv_s("MHGU_MODS_DIR", "obj/settings-test/mods");
#else
    setenv("MHGU_MODS_DIR", "obj/settings-test/mods", 1);
#endif
    ImGui::CreateContext();
    auto &io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.DisplaySize = ImVec2(1280, 720);
    io.DeltaTime = 1.f / 60;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard | ImGuiConfigFlags_NavEnableGamepad;
    io.BackendFlags |= ImGuiBackendFlags_HasGamepad;
    io.Fonts->AddFontDefault();
    io.Fonts->Build();
    Config baseline = config_defaults();
    config_store_loaded(&baseline);
    config_runtime_init(&baseline);

    idle();
    selected("display.mode");
    // A click outside the menu unfocuses every window; the menu takes its focus back (it used to assert in SetNavID)
    io.AddMousePosEvent(4, 4);
    io.AddMouseButtonEvent(ImGuiMouseButton_Left, true);
    idle();
    io.AddMouseButtonEvent(ImGuiMouseButton_Left, false);
    idle();
    selected("display.mode");
    confirm();
    selected("choice.2");
    back();
    selected("display.mode");
    down(2);
    selected("display.width");
    confirm();
    selected("display.width");
    assert(opened && !settings_panel_confirming() &&
           !settings_panel_dirty()); // Numeric activation never opens an editor.
    press(ImGuiKey_GamepadDpadRight);
    assert(settings_panel_dirty());
    back();
    selected("dialog.cancel");
    down(2);
    confirm();
    assert(!opened);
    frame();
    opened = true;
    idle();
    selected("display.mode");
    io.AddKeyEvent(ImGuiKey_GamepadR1, true);
    idle(35);
    selected("volume");  // (Audio first)
    down(3);  // (mutebg, show.fps, fps)
    selected("fps");
    io.AddKeyEvent(ImGuiKey_GamepadR1, false);
    idle();
    // The frame rate: Confirm lists the common ones, left / right go a frame at a time
    confirm();
    selected("choice.1");  // (60, the one it has)
    down();
    confirm();
    selected("fps");
    press(ImGuiKey_GamepadDpadRight);
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(config_editable().fps == 91);
    press(ImGuiKey_Home);
    down(3);
    selected("fps");
    confirm();
    selected("choice.2");  // (91 is none of them: the one below)
    press(ImGuiKey_GamepadDpadUp);
    confirm();
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    confirm();
    assert(config_editable().fps == 60);
    press(ImGuiKey_Home);
    down(3);
    confirm();
    selected("choice.1");
    back();  // (Back closes the dropdown, nothing changed)
    selected("fps");
    assert(!settings_panel_dirty() && opened);
    tab();
    selected("face");
    // The Keybinds submenu: a key chosen for B, then a mouse button as its second; the recomp's own keys refused
    press(ImGuiKey_Home);
    down(9);  // (background, keyboard prompts, combo, mouse, vertical, invert, smoothing, capture, keybinds)
    selected("keybinds");
    confirm();
    selected("bind.0");  // (past the section's title)
    down(6);             // (past the Buttons title)
    selected("bind.6");
    confirm();
    selected("choice.0");  // Set key
    confirm();
    selected("capture.cancel");
    assert(settings_panel_key(SDL_SCANCODE_F12));
    idle();
    selected("capture.cancel");  // (refused: still choosing)
    assert(settings_panel_key(SDL_SCANCODE_G));
    idle();
    selected("bind.6");
    confirm();
    down();
    selected("choice.1");  // Add a second key
    confirm();
    assert(settings_panel_mouse(SDL_BUTTON_MIDDLE));
    idle();
    selected("bind.6");
    assert(!settings_panel_mouse(SDL_BUTTON_LEFT));  // (not choosing: a click is the menu's)
    // The pointer on the capture view's Cancel: a left click is that row's, a side button (Mouse 4) still the key
    down();
    selected("bind.7");
    confirm();
    selected("choice.0");  // Set key
    confirm();
    selected("capture.cancel");
    {
        ImGuiWindow *w = ImGui::GetCurrentContext()->NavWindow;
        ImRect r = ImGui::WindowRectRelToAbs(w, w->NavRectRel[0]);
        ImGui::GetIO().AddMousePosEvent(r.GetCenter().x, r.GetCenter().y);
        idle();
    }
    assert(!settings_panel_mouse(SDL_BUTTON_LEFT));
    assert(settings_panel_mouse(SDL_BUTTON_X1));
    idle();
    ImGui::GetIO().AddMousePosEvent(-FLT_MAX, -FLT_MAX);
    idle();
    selected("bind.7");
    back();
    selected("keybinds");
    assert(settings_panel_dirty());
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(config_live_bind(BIND_B, 0) == SDL_SCANCODE_G && config_live_bind(BIND_B, 1) == KEY_MOUSE + SDL_BUTTON_MIDDLE);
    assert(config_live_bind(BIND_X, 0) == KEY_MOUSE + SDL_BUTTON_X1);
    press(ImGuiKey_Home);
    down(9);
    confirm();
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("bind.reset");
    confirm();
    back();
    selected("keybinds");
    // The Game actions screen: the tabs over the drawing (Hunt | Town and Hub | Menus | Keys) answer the mouse
    down();
    selected("actions");
    confirm();
    selected("act.enable");
    {
        auto *bw = ImGui::FindWindowByName("Settings##bind");
        assert(bw);
        float y = bw->Pos.y + ImGui::GetStyle().WindowPadding.y + bw->FontWindowScale * ImGui::GetFontSize();
        bool found = false;
        for (float x = bw->Pos.x + 60; x < bw->Pos.x + bw->Size.x - 60 && !found; x += 8) {
            io.AddMousePosEvent(x, y);
            idle();
            io.AddMouseButtonEvent(ImGuiMouseButton_Left, true);
            frame();
            io.AddMouseButtonEvent(ImGuiMouseButton_Left, false);
            idle(4);
            found = ImGui::GetCurrentContext()->NavId == id("act.tab");  // (a tab click puts the focus on the list's Show row)
        }
        assert(found);  // (a tab of the drawing took a click)
        io.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
        idle();
    }
    back();
    selected("actions");
    press(ImGuiKey_GamepadDpadUp);
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    confirm();
    assert(config_live_bind(BIND_B, 0) == SDL_SCANCODE_SPACE && !config_live_bind(BIND_B, 1));
    tab();
    selected("port");
    press(ImGuiKey_GamepadL1);
    selected("face");
    tab();
    tab();
    selected("sync");  // (the Hub heading first)
    down(4);  // (lag compensation, village quests, urgent quests, then the HP heading is passed)
    selected("hp.0");
    tab();
    selected("mod.Aaa");
    // The Mods tab: the conflict scan runs on another thread; Aaa and Bbb both replace a.bin
    std::this_thread::sleep_for(std::chrono::milliseconds(300));
    idle();
    down(4);  // (Aaa, Bbb, Ccc, then _Ddd that is off)
    selected("mods.conflicts");  // one row for them all
    down();
    selected("mods.rescan");  // (the suggested order is the one it has: Aaa changes more files, so Bbb comes after)
    press(ImGuiKey_Home);
    down();
    selected("mod.Bbb");
    confirm();
    down();  // Move up
    confirm();
    selected("mod.Bbb");
    assert(settings_panel_dirty());
    press(ImGuiKey_Home);
    selected("mod.Bbb");
    down(5);  // (Bbb, Aaa, Ccc, _Ddd, the conflict)
    selected("mods.suggest");  // Bbb now wins over the bigger Aaa: the order is suggested back
    confirm();
    press(ImGuiKey_Home);
    selected("mod.Aaa");
    down(2);
    selected("mod.Ccc");
    press(ImGuiKey_GamepadDpadLeft);  // off
    assert(settings_panel_dirty());
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(!settings_panel_dirty());
    {
        std::ifstream in("obj/settings-test/mods/load_order.txt");
        std::string list((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        assert(list.find("\nAaa\nBbb\n") != std::string::npos);
        assert(list.find("\nCcc\n") == std::string::npos && list.find("# off: Ccc\n") != std::string::npos);
        assert(list.find("\n_Ddd\n") == std::string::npos);
    }
    // Choosing which of two conflicting mods is used moves it below the other
    press(ImGuiKey_Home);
    down(4);  // (Aaa, Bbb, then the off ones _Ddd and Ccc)
    selected("mods.conflicts");
    confirm();
    selected("mods.conflict.0");
    confirm();
    selected("choice.1");  // (Use Bbb, the one used now)
    press(ImGuiKey_GamepadDpadUp);
    selected("choice.0");  // Use Aaa
    confirm();
    selected("mods.conflict.0");
    down();
    selected("conflicts.back");
    confirm();
    selected("mods.conflicts");
    assert(settings_panel_dirty());
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    {
        std::ifstream in("obj/settings-test/mods/load_order.txt");
        std::string list((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
        assert(list.find("\nBbb\nAaa\n") != std::string::npos);
    }
    // A mod that is off keeps its place in the list: turned on again, it loads where it was
    {
        ModEntry order[] = {{"Bbb", true}, {"Ccc", false}, {"Aaa", true}, {"_Ddd", false}};
        char error[256];
        assert(mods_save_order(order, 4, error, sizeof error));
        ModEntry list[MODS_MAX];
        assert(mods_installed(list, MODS_MAX) == 4);
        for (int i = 0; i < 4; i++)
            assert(!strcmp(list[i].name, order[i].name) && list[i].on == order[i].on);
    }
    // A mod folder added after the Mods tab saved loads (on), after the ones it lists
    put("obj/settings-test/mods/Eee/romfs/e.bin", "5");
    {
        ModEntry list[MODS_MAX];
        int n = mods_installed(list, MODS_MAX);
        assert(n == 5);
        const char *want[] = {"Bbb", "Ccc", "Aaa", "_Ddd", "Eee"};
        const bool on[] = {true, false, true, false, true};
        for (int i = 0; i < n; i++)
            assert(!strcmp(list[i].name, want[i]) && list[i].on == on[i]);
    }
    fs::remove_all("obj/settings-test/mods/Eee");
    tab();
    selected("cheats.add");  // (the Cheats tab: Add a cheat, then the cheats)
    tab();
    selected("language");
    tab();
    selected("display.mode");
    tab();
    selected("volume");
    confirm();
    selected("volume");
    press(ImGuiKey_GamepadDpadLeft);
    assert(settings_panel_dirty());
    settings_panel_request_back();
    idle();
    selected("dialog.cancel");
    back();
    selected("volume");
    settings_panel_request_close();
    idle();
    selected("dialog.cancel");
    assert(!requested);
    back();
    selected("volume");
    // Former save/discard shortcuts do nothing, including while held.
    io.AddKeyEvent(ImGuiKey_GamepadFaceLeft, true);
    idle(50);
    assert(!ImGui::GetCurrentContext()->NavWindowingTarget);
    io.AddKeyEvent(ImGuiKey_GamepadFaceLeft, false);
    idle();
    assert(settings_panel_dirty());
    press(ImGuiKey_GamepadFaceUp);  // (Y, the top face button, saves)
    assert(!settings_panel_dirty());
    assert(config_editable().volume == 99);
    selected("reset");  // (as after Save)
    press(ImGuiKey_Home);
    selected("volume");
    press(ImGuiKey_GamepadDpadRight);  // (100 again, not saved)
    assert(settings_panel_dirty());
    press(ImGuiKey_End);
    selected("reset");
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(!settings_panel_dirty());
    assert(config_editable().volume == 100);
    press(ImGuiKey_Home);
    selected("volume");
    press(ImGuiKey_GamepadDpadLeft);
    back();
    selected("dialog.cancel");
    down(2);
    confirm();
    assert(!opened);
    assert(config_editable().volume == 100);
    frame();
    opened = true;
    idle();
    selected("volume");
    tab();
    tab();
    selected("port");
    confirm();
    selected("port");
    press(ImGuiKey_GamepadDpadRight);
    assert(settings_panel_dirty());
#ifdef _WIN32
    _putenv_s("MHGU_CONFIG", "missing-settings-parent/panel.ini");
#else
    setenv("MHGU_CONFIG", "missing-settings-parent/panel.ini", 1);
#endif
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(settings_panel_dirty());
    assert(config_editable().ldn_port == 39500);
#ifdef _WIN32
    _putenv_s("MHGU_CONFIG", "obj/settings-test/panel-settings.ini");
#else
    setenv("MHGU_CONFIG", "obj/settings-test/panel-settings.ini", 1);
#endif
    back();
    selected("dialog.cancel");
    down(2);
    confirm();
    assert(!opened);
    frame();
    opened = true;
    idle();
    selected("port");
    down();
    selected("hosts");
    confirm();
    selected("key.0");
    io.AddInputCharactersUTF8("localhost:39500");
    idle();
    settings_panel_request_close();
    idle();
    selected("dialog.cancel");
    assert(settings_panel_dirty());
    back();
    selected("key.0");
    back();
    selected("hosts");
    assert(!settings_panel_dirty());
    settings_panel_request_close();
    idle();
    selected("dialog.cancel");
    down();
    confirm();
    assert(requested == 1);
    back();
    selected("hosts");
    requested = 0;
    tab();
    tab();
    tab();
    tab();  // (Misc, Mods, Cheats, Menu Options)
    selected("language");
    // The menu's confirm button (Menu controls): saved, it applies to the menu right away
    down(4);  // (theme, scale, detach, menu.confirm)
    selected("menu.confirm");
    press(ImGuiKey_GamepadDpadRight);
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(config_live_menu_confirm() == MENU_CONFIRM_SOUTH);
    assert(config_editable().face_buttons == FACE_POSITION);
    assert(!config_restart_required(&baseline));
    press(ImGuiKey_Home);
    down(4);
    selected("menu.confirm");
    press(ImGuiKey_GamepadDpadLeft);
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    confirm();
    assert(config_live_menu_confirm() == MENU_CONFIRM_ORIGINAL);
    press(ImGuiKey_Home);
    selected("language");
    // Save folder (PC): Choose folder opens the system's picker, whose folder lands in the draft; Save keeps it
    down(8);  // (theme, scale, detach, menu.confirm, icons, confirm.exit, updates, bonus)
    selected("bonus");
    down();
    selected("save.location");
    down();
    selected("save.location.pick");
    confirm();
    assert(import_requested == 4);
    picked_folder = "/games/MHGU saves";
    idle();
    picked_folder = "/bad;folder";  // (the settings file can't hold it: not taken)
    idle();
    down();
    selected("save.location.reset");  // (enabled now: a folder is set)
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(!strcmp(config_editable().save_location, "/games/MHGU saves"));
    { Config saved = config_editable(); assert(config_restart_required(&saved)); }
    press(ImGuiKey_Home);
    down(11);
    selected("save.location.reset");
    confirm();
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    confirm();
    assert(!config_editable().save_location[0]);
    press(ImGuiKey_Home);
    down(11);  // (Use the default folder: disabled again, skipped)
    selected("restart");
    confirm();
    selected("dialog.cancel");
    back();
    selected("restart");
    confirm();
    down();
    confirm();
    assert(requested == 2);
    back();
    requested = 0;
    opened = false;
    frame();
    baseline = config_editable();
    io.DisplaySize = ImVec2(640, 480);
    baseline.menu_scale = 200;
    baseline.language = 1;
    config_store_loaded(&baseline);
    opened = true;
    idle();
    auto *w = ImGui::FindWindowByName("Settings##main");
    assert(w->Size.x <= io.DisplaySize.x);
    assert(w->ContentSize.x <= w->InnerRect.GetWidth() + 1);
    float top = w->Pos.y;
    press(ImGuiKey_GamepadL1);
    press(ImGuiKey_GamepadL1);
    press(ImGuiKey_GamepadL1);  // (Cheats, Mods, Misc)
    selected("sync");  // (the Hub heading first)
    down(4);  // (lag compensation, village quests, urgent quests, then the HP heading is passed)
    selected("hp.0");
    down(5);
    confirm();
    idle();
    assert(w->Pos.y == top);
    press(ImGuiKey_End);
    selected("reset");
    idle(12);
    assert(w->Scroll.y > 0);
    press(ImGuiKey_GamepadDpadUp);
    selected("hp.add");
    confirm();
    assert(settings_panel_dirty());
    down(5);
    confirm();
    selected("hp.add");
    assert(!settings_panel_dirty());
    press(ImGuiKey_Home);
    press(ImGuiKey_GamepadDpadRight);
    press(ImGuiKey_End);
    selected("reset");
    confirm();
    selected("dialog.cancel");
    down();
    confirm();
    selected("reset");
    assert(!settings_panel_dirty());
    io.DisplaySize = ImVec2(640, 480);
    idle(12);
    assert(w->Size.x <= 640);
    assert(w->Size.y <= 480);
    assert(w->ContentSize.x <= w->InnerRect.GetWidth() + 1);
    press(ImGuiKey_GamepadL1);
    press(ImGuiKey_GamepadL1);
    press(ImGuiKey_GamepadL1);
    selected("volume");
    down(13);  // (mutebg, show.fps, fps, vsync, prewarm, msaa, fxaa, fxaamode, drawdist, smooth, kerning, boldtext, fsr)
    selected("fsr");
    confirm();
    assert(settings_panel_dirty());
    down();
    selected("fsr.quality");
    press(ImGuiKey_GamepadDpadRight);
    press(ImGuiKey_End);
    press(ImGuiKey_GamepadDpadUp);
    selected("save");
    confirm();
    assert(config_editable().fsr == 1);
    assert(config_editable().fsr_quality == FSR_QUALITY);
    Config fsr_saved = config_editable();
    assert(config_restart_required(&fsr_saved));
    opened = false;
    frame();
    g_config.fsr = 1;
    opened = true;
    idle();
    selected("volume");
    assert(!settings_panel_dirty()); // FSR-owned AA rows are disabled, not misleading live toggles.
    idle(20);
    float pinned_bottom = pinned_content_bottom();
    float pinned_top = pinned_content_top();
    press(ImGuiKey_End);
    idle(40);
    selected("reset");
    auto *root = ImGui::FindWindowByName("Settings##main");
    assert(root->Scroll.y > 0);
    assert(pinned_content_bottom() == pinned_bottom); // Guide position does not follow the scroll.
    assert(pinned_content_top() == pinned_top);
    assert(root->NavRectRel[ImGuiNavLayer_Main].Max.y + root->Pos.y <= pinned_bottom + 1);
    press(ImGuiKey_Home);
    idle(40);
    selected("volume");
    assert(pinned_content_bottom() == pinned_bottom);
    assert(pinned_content_top() == pinned_top);
    assert(root->NavRectRel[ImGuiNavLayer_Main].Min.y + root->Pos.y >= pinned_top - 1);
    press(ImGuiKey_End);
    idle(20);
    float font = root->FontRefSize;
    io.AddMousePosEvent(root->Pos.x + ImGui::GetStyle().WindowPadding.x + font * 2.6f,
                        root->Pos.y + ImGui::GetStyle().WindowPadding.y + font * .8f);
    idle();
    io.AddMouseButtonEvent(0, true);
    frame();
    io.AddMouseButtonEvent(0, false);
    idle(8);
    selected("display.mode"); // Pinned tabs remain clickable when the option list is scrolled.
    press(ImGuiKey_GamepadR1);
    selected("volume");
    opened = false;
    frame();
    assert(!settings_panel_dirty());
    ImGui::DestroyContext();
    remove("obj/settings-test/panel-settings.ini");
    puts("settings panel: inline numbers, explicit Save/Reset, Back guide, dirty discard, focus and layout "
         "OK");
}
