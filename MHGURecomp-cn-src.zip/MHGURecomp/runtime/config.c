// Player settings (config.h): mhgurecomp.ini in the game folder (next to the executable, or MHGU_HOME; with a game
// folder argument, the current folder). A missing file is written with the defaults, so
// deleting it resets everything; keys that are missing or not understood keep their defaults (the log says which).
//   MHGU_CONFIG=<path>   another settings file
//   MHGU_WINDOW=WxH      windowed at that size, MHGU_RENDER=WxH  3D resolution, MHGU_MSAA=1|2|4|8, MHGU_FXAA=0|1,
//                        MHGU_RT16=0|1 (SmoothGradients), MHGU_FIX_KERNING=0|1, MHGU_BOLD_TEXT=0|1, MHGU_HDR=0|1,
//                        MHGU_PAD_POSITIONAL=0|1 (test runs; override the file)
#include <ctype.h>
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include <SDL3/SDL.h>

#include "config.h"
#include "rt.h"

#include "keymap.h"

#define DEFAULT_BINDS {{SDL_SCANCODE_W}, {SDL_SCANCODE_S}, {SDL_SCANCODE_A}, {SDL_SCANCODE_D}, {SDL_SCANCODE_LSHIFT},     \
    {KEY_MOUSE + SDL_BUTTON_RIGHT}, {SDL_SCANCODE_SPACE}, {KEY_MOUSE + SDL_BUTTON_LEFT},                               \
    {SDL_SCANCODE_R, KEY_MOUSE + SDL_BUTTON_MIDDLE},                                                                   \
    {SDL_SCANCODE_Q}, {SDL_SCANCODE_E}, {SDL_SCANCODE_TAB}, {SDL_SCANCODE_T}, {SDL_SCANCODE_RETURN, SDL_SCANCODE_KP_ENTER}, \
    {SDL_SCANCODE_BACKSPACE}, {SDL_SCANCODE_UP}, {SDL_SCANCODE_DOWN}, {SDL_SCANCODE_LEFT}, {SDL_SCANCODE_RIGHT},          \
    {SDL_SCANCODE_LCTRL, SDL_SCANCODE_RCTRL}, {SDL_SCANCODE_LALT, SDL_SCANCODE_RALT}, {KEY_WHEEL_UP}, {KEY_WHEEL_DOWN}}
// [Graphics] BoldText: on by default on Android (a phone's small screen reads the bolder letters more easily)
#ifdef __ANDROID__
#define BOLD_TEXT_DEFAULT 1
#define BOLD_TEXT_DEFAULT_INI "On"
#else
#define BOLD_TEXT_DEFAULT 0
#define BOLD_TEXT_DEFAULT_INI "Off"
#endif
#define CONFIG_DEFAULT_VALUES                                                                       \
    /* [Display] */                                                                                 \
    .display_mode = DISPLAY_BORDERLESS,                                                             \
    .width = 1920,                                                                                  \
    .height = 1080,                                                                                 \
    .render_w = 0,                                                                                  \
    .render_h = 0,                                                                                  \
    .aspect_ratio = 0.0f,                                                                           \
    .fov = 1.0f,                                                                                    \
    .ui_anchor = UI_CENTER,                                                                         \
    /* [Anti-aliasing] */                                                                           \
    .msaa = 1,                                                                                      \
    .fxaa = 1,                                                                                      \
    .fxaa_mode = FXAA_ORIGINAL,                                                                     \
    /* [Upscaler] */                                                                                \
    .fsr = 0,                                                                                       \
    .fsr_quality = FSR_NATIVE,                                                                      \
    .fsr_sharpness = 0.8f,                                                                          \
    .fsr_objmotion = 1,                                                                             \
    .fsr_reactive = 0.9f,                                                                           \
    .fsr_animsurf = 1,                                                                              \
    /* [Graphics] */                                                                                \
    .draw_distance = 1.0f,                                                                          \
    .smooth_gradients = 0,                                                                          \
    .fix_kerning = 1,                                                                               \
    .bold_text = BOLD_TEXT_DEFAULT,                                                                 \
    /* [HDR] */                                                                                 \
    .hdr = 0,                                                                                   \
    .hdr_peak = 1000.0f,                                                                        \
    .hdr_game = 203.0f,                                                                         \
    .hdr_ui = 203.0f,                                                                           \
    .hdr_tonemap = HDR_TONEMAP_RENODRT,                                                         \
    .hdr_gamma = HDR_GAMMA_22,                                                                  \
    .hdr_exposure = 0.65f,                                                                      \
    .hdr_highlights = 60.0f,                                                                    \
    .hdr_shadows = 50.0f,                                                                       \
    .hdr_contrast = 50.0f,                                                                      \
    .hdr_saturation = 50.0f,                                                                    \
    .hdr_highlight_saturation = 82.0f,                                                          \
    .hdr_flare = 0.0f,                                                                          \
    .hdr_bloom = 100.0f,                                                                        \
    .hdr_scene = 1,                                                                             \
    .hdr_format = HDR_FORMAT_AUTO,                                                              \
    .hdr_analysis = 0,                                                                          \
    /* [Performance] */                                                                             \
    .show_fps = 0,                                                                                  \
    .show_battery = BATTERY_OFF,                                                                    \
    .fps = 60,                                                                                      \
    .vsync = 1,                                                                                     \
    .shader_prewarm = 1,                                                                            \
    .loading_indicator = 1,                                                                         \
    /* [Controls] */                                                                                \
    .face_buttons = FACE_POSITION,                                                                  \
    .menu_confirm = MENU_CONFIRM_ORIGINAL,                                                          \
    .background_input = 1,                                                                          \
    .kbm_prompts = 1,                                                                               \
    .combo_window = COMBO_LENIENT,                                                                  \
    .chat_key = "/",                                                                                \
    .menu_chord = 1,                                                                                \
    /* [Mouse] */                                                                                   \
    .mouse_sensitivity = 1.0f,                                                                      \
    .mouse_sensitivity_y = 1.0f,                                                                    \
    .mouse_invert_y = 0,                                                                            \
    .mouse_smoothing = 0.0f,                                                                        \
    .mouse_capture = MOUSE_CAPTURE_CLICK,                                                           \
    /* [Keybinds] */                                                                                \
    .binds = DEFAULT_BINDS,                                                                         \
    /* [Multiplayer] */                                                                             \
    .ldn_port = 39500,                                                                              \
    .ldn_join = "",                                                                                 \
    .ldn_server = "",                                                                               \
    .ldn_key = "",                                                                                  \
    .ldn_direct = 1,                                                                                \
    .sync_small_monsters = 1,                                                                       \
    .lag_compensation = 1,                                                                          \
    .share_urgent = 1,                                                                              \
    /* [Monster HP, Village Quests] */                                                              \
    .hp = {{1, 1, 1, 1}, 2},                                                                        \
    .village_in_hub = 1,                                                                            \
    /* [Discord] */                                                                                 \
    .discord = 1,                                                                                   \
    .discord_hunter = 1,                                                                            \
    /* [Bonus Content] */                                                                           \
    .bonus_content = 1,                                                                             \
    /* [Audio] */                                                                                   \
    .volume = 100,                                                                                  \
    .mute_in_background = 0,                                                                        \
    /* [Application] */                                                                             \
    .confirm_exit = 1,                                                                              \
    .language = 0,                                                                                  \
    .button_icons = 0,                                                                              \
    .menu_theme = THEME_HUNTER,                                                                     \
    .menu_scale = 100,                                                                              \
    .updates = UPDATES_ASK,                                                                         \
    .save_location = "",                                                                            \

Config g_config = {CONFIG_DEFAULT_VALUES};
Config config_defaults(void) { Config c = {CONFIG_DEFAULT_VALUES}; return c; }
uint32_t g_render_size[2] = {1920, 1080};
uint32_t g_render_host[2] = {1920, 1080};
float g_rscale[2] = {1.0f, 1.0f};
uint32_t g_gpu_pool_size = 0x35200000u;  // the game's GPU pool for render targets and textures (gen.py PATCHES)
float g_render_aspect = 16.0f / 9.0f;
float g_fov_scale = 1.0f;
uint32_t g_ui_size[2] = {1280, 720};
float g_ui_anchor_aspect = 16.0f / 9.0f;
uint32_t g_fsr_output[2];
float g_fsr_lod_bias;

static const char DEFAULT_INI[] =
    "; MHGU Recomp settings. Delete this file to reset to default settings, the file is regenerated.\n"
    "\n"
    "[Display]\n"
    "; Fullscreen, Windowed, Borderless\n"
    "Mode = Borderless\n"
    "\n"
    "; Resolution (WxH)\n"
    "Resolution = 1920x1080\n"
    "\n"
    "; Rendering resolution (WxH)\n"
    "; Higher = sharper (for supersampling)\n"
    "; Default: Auto\n"
    "RenderResolution = Auto\n"
    "\n"
    "; Set to 16:9 to preserve the game's native aspect ratio\n"
    "; Default: Auto\n"
    "AspectRatio = Auto\n"
    "\n"
    "; Field of view\n"
    "; Between 0.5 and 2\n"
    "; Default: 1.0\n"
    "FOV = 1.0\n"
    "\n"
    "; At resolutions wider than 16:9, determines where the HUD goes\n"
    "; Center, Edges\n"
    "; Default: Center\n"
    "UIAnchor = Center\n"
    "\n"
    "[Anti-aliasing]\n"
    "; Multi-Sample Anti Aliasing, cycle modes with F7 key\n"
    "; Off, 2x, 4x, 8x\n"
    "; Default: Off\n"
    "MSAA = Off\n"
    "\n"
    "; GU's default FXAA\n"
    "; Default: On\n"
    "FXAA = On\n"
    "\n"
    "; Which FXAA: Original is GU's own, 3_11 is FXAA 3.11, which keeps textures sharper\n"
    "; Original, 3_11\n"
    "; Default: Original\n"
    "FXAAMode = Original\n"
    "\n"
    "[Upscaler]\n"
    "; FSR temporal upscaling\n"
    "; Default: Off\n"
    "FSR = Off\n"
    "\n"
    "; FSR quality\n"
    "; NativeAA, Quality, Balanced, Performance, UltraPerformance\n"
    "; Default: NativeAA\n"
    "FSRQuality = NativeAA\n"
    "\n"
    "; FSR's sharpening filter strength\n"
    "; Between 0 to 1\n"
    "; Default: 0.8\n"
    "Sharpness = 0.8\n"
    "\n"
    "; FSR Object Motion, reduces smearing\n"
    "; Default: On\n"
    "ObjectMotion = On\n"
    "\n"
    "; Reactive anti-ghosting\n"
    "; Between 0 and 1\n"
    "; Default: 0.9\n"
    "Reactive = 0.9\n"
    "\n"
    "; Animated surface textures skip FSR's frame history to avoid smearing\n"
    "; Default: On\n"
    "AnimSurf = On\n"
    "\n"
    "[Graphics]\n"
    "; How far away people in the villages and the Hubs are still drawn: 1 is the game's distance, 2 twice as far,\n"
    "; 0.5 half as far, 0 no limit\n"
    "; Between 0 and 10\n"
    "; Default: 1.0\n"
    "DrawDistance = 1.0\n"
    "\n"
    "; Renders the picture with 16 bits per colour instead of 8, so dark skies and soft glows show no colour bands.\n"
    "; Costs GPU time: about 1 ms a frame at 1600x1000, more at higher resolutions\n"
    "; Default: Off\n"
    "SmoothGradients = Off\n"
    "\n"
    "; Evens out the spacing between letters in the game's text: exact placement, even margins and kerning\n"
    "; (closer pairs such as \"Va\" and \"To\"). Off: the text as the game sets it\n"
    "; Default: On\n"
    "FixKerning = On\n"
    "\n"
    "; Draws letters slightly thicker and wider, as the original game does. Some players, including players with\n"
    "; dyslexia, find this easier to read. Off: letters at their true size, thinner and crisper\n"
    "; Default: " BOLD_TEXT_DEFAULT_INI "\n"
    "BoldText = " BOLD_TEXT_DEFAULT_INI "\n"
    "\n"
    "[HDR]\n"
    "; 16-bit HDR output for HDR capable monitors/phones (NOT FOR HDR400 DISPLAYS). Smooth gradients and FSR do not work with HDR\n"
    "; Default: Off\n"
    "HDR = Off\n"
    "\n"
    "; The brightest your display can show, in nits (its specifications, or Windows HDR Calibration)\n"
    "; Between 80 and 10000\n"
    "; Default: 1000\n"
    "PeakBrightness = 1000\n"
    "\n"
    "; How bright the game's white is, in nits (203 is the HDR reference white)\n"
    "; Between 48 and 500\n"
    "; Default: 203\n"
    "GameBrightness = 203\n"
    "\n"
    "; How bright the HUD, menus, text and this settings menu are, in nits\n"
    "; Between 48 and 500\n"
    "; Default: 203\n"
    "UIBrightness = 203\n"
    "\n"
    "; Vanilla (the game's SDR picture, clipped), None (no tone mapping: clipped at the peak) or RenoDRT (highlights rolled\n"
    "; off smoothly towards the peak)\n"
    "; Default: RenoDRT\n"
    "ToneMapper = RenoDRT\n"
    "\n"
    "; Off (sRGB), 2.2 (what most SDR displays show: deeper shadows) or BT.1886 (2.4, a dark room)\n"
    "; Default: 2.2\n"
    "GammaCorrection = 2.2\n"
    "\n"
    "; Brightness of the whole picture before tone mapping, 1 = the game's\n"
    "; Between 0 and 2\n"
    "; Default: 0.65\n"
    "Exposure = 0.65\n"
    "\n"
    "; Colour grading, 50 = the game's: Highlights (brighter highlights above 50), Shadows (lighter shadows above 50),\n"
    "; Contrast, Saturation, HighlightSaturation (more colour in bright areas above 50, whiter below)\n"
    "; Between 0 and 100\n"
    "; Default: 50 (Highlights 60, HighlightSaturation 82)\n"
    "Highlights = 60\n"
    "Shadows = 50\n"
    "Contrast = 50\n"
    "Saturation = 50\n"
    "HighlightSaturation = 82\n"
    "\n"
    "; Lifts the darkest parts of the picture (a hazy, filmic look), 0 = none\n"
    "; Between 0 and 100\n"
    "; Default: 0\n"
    "Flare = 0\n"
    "\n"
    "; Strength of the game's bloom (the glow around bright lights), 100 = the game's\n"
    "; Between 0 and 100\n"
    "; Default: 100\n"
    "Bloom = 100\n"
    "\n"
    "; Everything the game renders (the 3D scene, depth of field, bloom) is 16-bit float, not only the post-processing,\n"
    "; so the sun, fire and sparks keep their brightness and glow. Turn it off if anything looks wrong with HDR. Not in\n"
    "; the settings menu\n"
    "; Default: On\n"
    "UnclampedScene = On\n"
    "\n"
    "; The HDR signal: Auto (HDR10 where the display offers it, else scRGB), HDR10 (10-bit PQ) or scRGB (16-bit linear).\n"
    "; Not in the settings menu\n"
    "; Default: Auto\n"
    "HDRFormat = Auto\n"
    "\n"
    "; Shows an HDR analysis over the game: the picture's brightness in nits (maximum, average, minimum, the middle of\n"
    "; the screen), the colour gamut it uses and a waveform of its brightness across the screen, as the display gets it\n"
    "; Default: Off\n"
    "Analysis = Off\n"
    "\n"
    "[Performance]\n"
    "; Show the frame rate (FPS) in a small box on the screen. Drag it with the mouse while the settings menu is open\n"
    "; Default: Off\n"
    "ShowFPS = Off\n"
    "\n"
    "; Android only: show the battery's charge (in percent) in the same box as the frame rate, or in a box of its own\n"
    "; Off, WithFPS, ByItself\n"
    "; Default: Off\n"
    "ShowBattery = Off\n"
    "\n"
    "; Framerate cap\n"
    "; Between 30 and 240\n"
    "; Default: 60\n"
    "FPS = 60\n"
    "\n"
    "; VSync\n"
    "VSync = On\n"
    "\n"
    "; Translate all of the game's shaders in the background at startup, so fewer things are drawn black the first time\n"
    "; they appear. The first start does this in about 20 seconds while the logos play; it needs about 340 MB in the cache folder.\n"
    "; Default: On\n"
    "ShaderPrewarm = On\n"
    "\n"
    "; A \"Loading\" box in the bottom right corner while the game starts up and prepares its shaders. Not in the\n"
    "; settings menu: turn it off here if it stays on screen or gets in the way.\n"
    "; Default: On\n"
    "LoadingIndicator = On\n"
    "\n"
    "[Controls]\n"
    "; Controller face button layout. Set to \"Label\" to reverse A/B and X/Y on XBox controllers to match the button prompts (not recommended)\n"
    "; Position, Label\n"
    "; Default: Position\n"
    "FaceButtons = Position\n"
    "\n"
    "; Confirm button in the settings menu (F1, or Minus + Plus on a controller). The game's own menus are unchanged.\n"
    "; Original, South (bottom button), East (right button)\n"
    "; Default: Original\n"
    "MenuConfirm = Original\n"
    "\n"
    "; Controller input is also registered if the window is out of focus\n"
    "; Default: On\n"
    "BackgroundInput = On\n"
    "\n"
    "; While you play with the keyboard and mouse, the game's button prompts, such as (A) or (ZL), show the key or mouse\n"
    "; button that does it instead. A controller always gets the game's own prompts\n"
    "; Default: On\n"
    "KeyboardPrompts = On\n"
    "\n"
    "; How long the game waits for a second button after the first, for inputs like X+A. Lenient: as long as at 30 fps\n"
    "; (on the Switch) at any frame rate. Strict: a fixed number of frames, so the higher the frame rate, the closer\n"
    "; together both buttons have to be pressed\n"
    "; Lenient, Strict\n"
    "; Default: Lenient\n"
    "ComboInputWindow = Lenient\n"
    "\n"
    "; Plus and Minus pressed together (Start + Back on a controller, Enter + Backspace on a keyboard by default) open\n"
    "; the settings menu. Turn it off to keep that combination for the game or a cheat: F1 still opens the menu\n"
    "; Default: On\n"
    "MenuChord = On\n"
    "\n"
    "; The key that opens a line of chat, anywhere (in a quest too): a key's name as the settings menu shows it, or\n"
    "; nothing for none\n"
    "; Default: /\n"
    "ChatKey = /\n"
    "\n"
    "[Mouse]\n"
    "; Mouse sensitivity\n"
    "; Default: 1.0\n"
    "MouseSensitivity = 1.0\n"
    "\n"
    "; Vertical sensitivity: times the mouse sensitivity for looking up and down\n"
    "; Default: 1.0\n"
    "MouseSensitivityY = 1.0\n"
    "\n"
    "; Invert the mouse's up and down (on top of the game's own invert option)\n"
    "; Default: Off\n"
    "MouseInvertY = Off\n"
    "\n"
    "; Mouse smoothing for the camera in a hunt: 0 turns exactly with the mouse, higher values let the turn trail it\n"
    "; Default: 0.0\n"
    "MouseSmoothing = 0.0\n"
    "\n"
    "; Click: a click in the window captures the mouse (Esc lets it go). Hunt: it is also captured by itself while the\n"
    "; hunt camera is yours, and free in menus and cutscenes\n"
    "; Default: Click\n"
    "MouseCapture = Click\n"
    "\n"
    "[Keybinds]\n"
    "; The keys or mouse buttons for each Switch button, for moving (the left stick) and for turning the item bar\n"
    "; (ItemLeft / ItemRight: one item per press, in a hunt, without holding L).\n"
    "; Up to two each, separated by a comma, or None.\n"
    "; Mouse buttons: Mouse Left, Mouse Right, Mouse Middle, Mouse 4, Mouse 5, Wheel Up, Wheel Down.\n"
    "; Esc, Insert, F1 and F7 to F12 are the recomp's own keys.\n"
    "MoveUp = W\n"
    "MoveDown = S\n"
    "MoveLeft = A\n"
    "MoveRight = D\n"
    "Walk = Left Shift\n"
    "A = Mouse Right\n"
    "B = Space\n"
    "X = Mouse Left\n"
    "Y = R, Mouse Middle\n"
    "L = Q\n"
    "R = E\n"
    "ZL = Tab\n"
    "ZR = T\n"
    "Plus = Return, Keypad Enter\n"
    "Minus = Backspace\n"
    "DpadUp = Up\n"
    "DpadDown = Down\n"
    "DpadLeft = Left\n"
    "DpadRight = Right\n"
    "LeftStickClick = Left Ctrl, Right Ctrl\n"
    "RightStickClick = Left Alt, Right Alt\n"
    "ItemLeft = Wheel Up\n"
    "ItemRight = Wheel Down\n"
    "\n"
    "[Multiplayer]\n"
    "; Which port to host/join hubs on (TCP and UDP). A change counts from the next hub you host or search for\n"
    "; Default: 39500\n"
    "Port = 39500\n"
    "\n"
    "; IP Address of the host to join. Use IP:Port if it doesn't match the port above.\n"
    "; Can be multiple IP addresses, comma-separated\n"
    "; Default:\n"
    "Join =\n"
    "\n"
    "; Hub server for playing over the internet without port forwarding: hubs you create are listed there, and\n"
    "; Search Hubs shows its hubs next to the LAN's. host or host:port (default port 39510).\n"
    "; Empty: the default server. Off: no internet hubs.\n"
    "; Default:\n"
    "Server =\n"
    "\n"
    "; Matchmaking key: hubs are only seen by players with the same key, so friends who all enter the same key\n"
    "; only see each other's hubs. Empty: public, your hubs are seen by (and you see) everyone without a key.\n"
    "; On Android, empty means public among Android players only: to play with friends on PC, all enter the same key.\n"
    "; Default:\n"
    "Key =\n"
    "\n"
    "; Direct = On: in an internet hub, your game and the host's send their packets straight to each other when both\n"
    "; routers let them (the hub server helps them find each other), for a lower ping; else they go through the hub\n"
    "; server. Direct means the other player's game sees your IP address (as on the Switch). Off: always through the hub\n"
    "; server, nobody sees your address. Both ends need it On for a direct connection.\n"
    "; Default: On\n"
    "Direct = On\n"
    "\n"
    "; Sync small monsters between players in multiplayer. Everyone in the hunt should use the same setting.\n"
    "; Default: On\n"
    "SyncSmallMonsters = On\n"
    "\n"
    "; Experimental. Your hits on large monsters (melee, bows and bowguns) count as you saw them land, even if your hunter\n"
    "; missed on the screen of the player running the monster. Works when that player has it on too, and has no effect\n"
    "; otherwise. Emulator players in a crossplay hub need the Lag Compensation Forge plugin for it.\n"
    "; Default: On\n"
    "LagCompensation = On\n"
    "\n"
    "; Clearing an Urgent quest posted by someone else also counts for you, if you have unlocked it yourself. The\n"
    "; original game only counts it for the hunter who posted it. This only changes your own save, the others in the\n"
    "; quest have their own setting.\n"
    "; Default: On\n"
    "ShareUrgentCredit = On\n"
    "; Crossplay with Ryujinx players. RyuServers: Ryujinx LDN servers whose lobbies show up in Search Hubs next to\n"
    "; the others (host or host:port, comma separated; default port 30456). Empty: no crossplay. RyuHost: the server a\n"
    "; hub you create is made on, so Ryujinx players can join it (their LDN server = the same address); empty: a\n"
    "; normal hub. RyuPassphrase: empty = public lobbies, or Ryujinx- and 8 hex digits for a private group (Ryujinx\n"
    "; players enter the same). Everyone needs game version 1.4.0. The port's extras (small monster sync, HP scaling)\n"
    "; are off in a hub with Ryujinx players. Ryujinx's public server is for Ryujinx users: use your own LdnServer.\n"
    "; Default:\n"
    "RyuServers =\n"
    "RyuHost =\n"
    "RyuPassphrase =\n"
    "; RyuServe = On: this game runs the Ryujinx LDN server itself while local play is open, so nobody needs a separate\n"
    "; LdnServer: Ryujinx players set their LDN server to this PC's address (port RyuServePort, default 30456; forward\n"
    "; it or use a VPN such as Radmin), and hubs you create are made on it (RyuHost can stay empty).\n"
    "; Default: Off\n"
    "RyuServe = Off\n"
    "RyuServePort = 30456\n"
    "\n"
    "; RoomServe = On: this game also runs a small suyu-style room itself while local play is open, so suyu, yuzu, Eden and\n"
    "; Citron players join it (their multiplayer room address = this PC, port RoomServePort, default 24872; forward it\n"
    "; for the internet) and play in the same hubs as Ryujinx players. Hubs you create are shared with the room. The room\n"
    "; password is RoomPassword.\n"
    "RoomServe = Off\n"
    "RoomServePort = 24872\n"
    "\n"
    "; Crossplay with suyu, yuzu and the forks that kept their multiplayer rooms (Eden, Citron, ...). RoomServer: the\n"
    "; room's address (host or host:port, default port 24872); this game joins it while local play is open, and the\n"
    "; emulators' hubs show up in Search Hubs. RoomHost = On: a hub you create lives in the room, so their players can\n"
    "; search and join it. RoomName: your name in the room. The same game version (1.4.0) is needed, and the port's extras\n"
    "; (small monster sync, HP scaling) are off in such a hub. With RyuHost set as well the hub stays on that server and\n"
    "; the room's players join it there: Ryujinx and suyu players share one hub.\n"
    "; Default: Off\n"
    "RoomServer =\n"
    "RoomPassword =\n"
    "RoomName =\n"
    "RoomHost = Off\n"
    "\n"
    "\n"
    "[Monster HP]\n"
    "; Playercount-specific HP multipliers for monsters in Hub quests.\n"
    "; Only affects large monster health.\n"
    "; When joining a hub, the host's scaling settings are always used.\n"
    "; Default: 1.0\n"
    "1Player = 1.0\n"
    "2Players = 1.0\n"
    "3Players = 1.0\n"
    "4Players = 1.0\n"
    "\n"
    "; (Optional: quest-specific HP multipliers go here. Comma-separated per playercount, 1 line per quest. Example:)\n"
    "; Quest10107 = 1.0, 1.0, 1.0, 1.0\n"
    "\n"
    "[Village Quests]\n"
    "; Press L/R in the Hub while selecting a quest to swap to the Village Quest list instead, letting you play Village quests in multiplayer.\n"
    "; Default: On\n"
    "VillageQuestsInHub = On\n"
    "\n"
    "; When playing a Village Quest from the Hub, first multiply the monster HP by this amount.\n"
    "; This amount is then scaled again by the [Monster HP] settings.\n"
    "; Default: 2.0\n"
    "HubHP = 2.0\n"
    "\n"
    "[Discord]\n"
    "; Show what you're doing in the game on your Discord profile (Discord must be running on this computer):\n"
    "; where you are, the quest's monsters and how many hunters are with you\n"
    "; Default: On\n"
    "RichPresence = On\n"
    "\n"
    "; Show your hunter's name and Hunter Rank there too\n"
    "; Default: On\n"
    "ShowHunter = On\n"
    "\n"
    "[Bonus Content]\n"
    "; If enabled, the free online downloadable content (Event Quests, item packs, Palicoes) are automatically copied from the provided savegame inside the `bonus/` folder into your own savegame.\n"
    "; This only happens if your savegame hasn't received any downloadable content yet. A change counts the next time\n"
    "; the game opens the save file.\n"
    "; Default: On\n"
    "BonusContent = On\n"
    "\n"
    "[Audio]\n"
    "; Volume of the whole game\n"
    "; Between 0 (mute) and 100\n"
    "; Default: 100\n"
    "Volume = 100\n"
    "\n"
    "; Mute the game while its window is in the background (not focused)\n"
    "; Default: Off\n"
    "MuteInBackground = Off\n"
    "\n"
    "[Application]\n"
    "; Ask before the game window closes (closing does not save the game)\n"
    "; Default: On\n"
    "ConfirmExit = On\n"
    "\n"
    "; Language of the settings menu (F1, or Minus + Plus on a controller)\n"
    "; English, Spanish, Chinese\n"
    "; Default: English\n"
    "Language = English\n"
    "\n"
    "; Button icons in the settings menu\n"
    "; Xbox, Switch, PlayStation\n"
    "; Default: Xbox\n"
    "ButtonIcons = Xbox\n"
    "\n"
    "; Colours of the settings menu\n"
    "; Gold, Blue, Hunter\n"
    "; Default: Hunter\n"
    "Theme = Hunter\n"
    "\n"
    "; Size of the settings menu, in percent\n"
    "; Between 50 and 200\n"
    "; Default: 100\n"
    "MenuScale = 100\n"
    "\n"
    "; What mhgurecomp-updater does when it is started: check GitHub for a newer release and ask before installing it,\n"
    "; install it without asking, or only start the game. Starting mhgurecomp itself never checks or updates.\n"
    "; Ask, Auto, Off\n"
    "; Default: Ask\n"
    "Updates = Ask\n"
    "\n"
    "; PC only. The folder the save is kept in (the one that holds save_0), for example on another drive or in a synced\n"
    "; folder. Empty: the default (%APPDATA%\\MHGURecomp\\save on Windows, ~/.local/share/MHGURecomp/save on Linux).\n"
    "; Your save is not moved: copy save_0 there yourself. Takes effect at the next start\n"
    "SaveLocation =\n"
    "\n"
    "[Android]\n"
    "; Android only. The folder the save is kept in, so syncing software can keep it in step: the one that holds save_0. Empty: the app's own\n"
    "; folder. Set it with Save folder in the settings menu (Android tab): the app needs Android's \"All files access\"\n"
    "; to use a folder outside its own. Takes effect at the next start\n"
    "SaveFolder =\n"
    "\n"
    "; Android only. The folder holding the game's exefs and romfs folders, used where it is (for example on a USB drive or SD\n"
    "; card), so they don't have to fit in the app's own folder. Empty: the data folder in the app's own folder. Set it with\n"
    "; Game files folder in the settings menu (Android tab): the app needs Android's \"All files access\". Takes effect at the next start\n"
    "GameFolder =\n";

void config_path(char *buf, size_t size) {
    const char *e = getenv("MHGU_CONFIG");
    if (e && *e) { snprintf(buf, size, "%s", e); return; }
    snprintf(buf, size, "mhgurecomp.ini");  // (started on its own the game runs in its folder, or MHGU_HOME: main.c)
}

// lower case, spaces and '_' / '-' removed: "Borderless Window" == "borderlesswindow"
static void squash(char *s) {
    char *d = s;
    for (; *s; s++) if (!isspace((unsigned char)*s) && *s != '_' && *s != '-') *d++ = (char)tolower((unsigned char)*s);
    *d = 0;
}

static bool parse_size(const char *v, int *w, int *h) {
    int a, b;
    char x;
    if (sscanf(v, "%d %c %d", &a, &x, &b) != 3 || (x != 'x' && x != 'X' && x != '*')) return false;
    if (a < 320 || b < 180 || a > 16384 || b > 16384) return false;
    *w = a, *h = b;
    return true;
}

// [Monster HP] factors: "0.6", "0.6x", or a comma separated list of up to four (squashed: no spaces). The count read,
// 0 when one is not a number in HP_SCALE_MIN..HP_SCALE_MAX.
static int parse_factors(const char *v, float f[4]) {
    int n = 0;
    while (*v && n < 4) {
        char *end;
        float x = strtof(v, &end);
        if (end == v || !(x >= HP_SCALE_MIN && x <= HP_SCALE_MAX)) return 0;
        f[n++] = x;
        v = end + (*end == 'x');
        if (*v == ',') v++;
        else if (*v) return 0;
    }
    return *v ? 0 : n;
}

// A 3D camera's aspect (tools/gen.py PATCHES: the three callers of the perspective matrix that load a camera's). One
// made for the screen (16:9) gets the picture's shape. On a picture narrower than 16:9 (16:10), a model preview's camera
// (the Smithy's, made for its box in the HUD) has the shape of that box stretched to the taller picture: the renderer
// (nvn/vulkan/exec.c ui_preview_map) records the shapes of the preview boxes it drew, and a camera of one of those shapes
// gets the box's 16:9 shape instead, so the model is as big and as wide as at 16:9 (the renderer draws it in a box of
// that shape, g_preview_cam_present says it can). Any other camera keeps its aspect.
volatile float g_preview_box_aspect[4];
volatile uint64_t g_preview_box_present[4], g_preview_cam_present;
float camera_aspect(float a) {
    if (a > 1.77f && a < 1.786f) return g_render_aspect;
    if (g_render_aspect >= 16.0f / 9.0f - 0.01f) return a;
    for (int i = 0; i < 4; i++)
        if (g_preview_box_present[i] + 30 >= g_present_count && fabsf(a / g_preview_box_aspect[i] - 1.0f) < 0.001f) {
            g_preview_cam_present = g_present_count;
            return a * (16.0f / 9.0f) / g_render_aspect;
        }
    return a;
}

// The vertical field of view (radians) a camera of this aspect gets (tools/gen.py PATCHES: the three callers of the
// perspective matrix that load a camera's). One made for the screen (its 16:9 aspect replaced with g_render_aspect)
// gets the FOV factor and, on a picture narrower than 16:9 (16:10), the height that keeps 16:9's width (Vert+): more
// above and below instead of less to the sides. Other cameras keep their own. (A picture is a whole number of pixels:
// a camera made from its size has an aspect within rounding of g_render_aspect, 1918x1050 for 1.828, not equal to it;
// a small picture, 426x118 for 3.578 with FSR Ultra Performance at 1280x720, is further off, so its size counts too.)
float camera_fovy(float fovy, float aspect) {
    if (fabsf(aspect / g_render_aspect - 1.0f) > 0.005f && aspect != (float)g_render_size[0] / (float)g_render_size[1])
        return fovy;
    fovy *= config_live_fov();
    if (aspect < 16.0f / 9.0f) fovy = 2.0f * atanf(tanf(fovy * 0.5f) * (16.0f / 9.0f) / aspect);
    return fovy;
}

// Town NPCs (uLobbyNpc: villages, Hubs) fade in within a distance from the game's table (2500 units, 1800 for some)
// and out beyond it; tools/gen.py PATCHES hands its square here. [Graphics] DrawDistance scales it, 0 is no limit.
float npc_fade_dist2(float d2) {
    float m = config_live_draw_distance();
    return m > 0 ? d2 * m * m : FLT_MAX;
}

// A picture shape: "Auto" (0), "21:9" / "21/9", or a number (0.5 .. 10).
static bool parse_aspect(const char *v, float *out) {
    float n, d, a;
    char sep, *end;
    if (!strcasecmp(v, "auto")) { *out = 0; return true; }
    if (sscanf(v, "%f %c %f", &n, &sep, &d) == 3 && (sep == ':' || sep == '/') && n > 0 && d > 0) {
        a = n / d;
    } else {
        a = strtof(v, &end);
        if (end == v || *end) return false;
    }
    if (a < 0.5f || a > 10.0f) return false;
    *out = a;
    return true;
}

// ---- the settings of the file (config.h ConfigSetting): one row each, in the file's order
// config_validate's messages (settings_locale.h has them in Spanish; tests/test_settings_locale.py checks)
#define ERR_SIZE "Resolution must be Desktop/Auto or 320x180 to 16384x16384."
#define ERR_ASPECT "Aspect ratio must be Auto or between 0.5 and 10."
#define ERR_VIEW "FOV must be 0.5-2.0 and mouse sensitivity 0.1-10."
#define ERR_MISC "Invalid frame cap, anti-aliasing, controller, HUD or volume setting."
#define ERR_TOGGLE "Invalid On/Off value."
#define ERR_FSR "Invalid FSR quality, sharpness or reactive mask."
#define ERR_NET "Invalid port or Join address list (no newlines, ';' or '#')."
#define ERR_SERVER "Invalid hub server or matchmaking key (no newlines, ';' or '#')."
#define ERR_FOLDER "Invalid save folder (one line, no ';' or '#')."
#define ERR_GAME_FOLDER "Invalid game files folder (one line, no ';' or '#')."
#define ERR_HP "HP factors must be 0.05-20."
#define ERR_VILLAGE "Invalid village HP or quest override count."
#define ERR_MOUSE "Mouse sensitivity must be 0.1-10 and smoothing 0-0.9."
#define ERR_CONFIRM "Invalid menu confirmation policy."
#define ERR_SCALE "Invalid interface scale."
#define ERR_ICONS "Invalid button icon layout."
#define ERR_LANGUAGE "Invalid menu language."
#define ERR_UPDATES "Invalid update setting."
#define ERR_DRAW "Draw distance must be 0-10 (0: no limit)."
#define ERR_KEYS "Invalid keybind."
#define ERR_HDR "Invalid HDR setting."
#define F(x) offsetof(Config, x)
#define ON_OFF(section, key, field, restart) {section, key, SET_BOOL, F(field), 0, 0, 0, NULL, NULL, restart, ERR_TOGGLE}
#define KEYS(key, bind) {"Keybinds", key, SET_KEYS, F(binds[bind]), 0, 0, 0, NULL, NULL, false, ERR_KEYS}
static const int anchor_values[] = {UI_CENTER, UI_21_9, UI_32_9, UI_EDGES}, msaa_values[] = {1, 2, 4, 8};
const ConfigSetting g_settings[] = {
    {"Display", "Mode", SET_CHOICE, F(display_mode), 0, 0, 0,
     "Windowed|window,Fullscreen|exclusive|exclusivefullscreen,Borderless|borderless*", NULL, true, ERR_SIZE},
    {"Display", "Resolution", SET_SIZE, F(width), F(height), 0, 0, "Desktop|auto", NULL, true, ERR_SIZE},
    {"Display", "RenderResolution", SET_SIZE, F(render_w), F(render_h), 0, 0, "Auto", NULL, true, ERR_SIZE},
    {"Display", "AspectRatio", SET_ASPECT, F(aspect_ratio), 0, 0.5f, 10.0f, NULL, NULL, true, ERR_ASPECT},
    {"Display", "FOV", SET_FLOAT, F(fov), 0, 0.5f, 2.0f, NULL, NULL, false, ERR_VIEW},
    {"Display", "UIAnchor", SET_CHOICE, F(ui_anchor), 0, 0, 0, "Center|1|16:9,21:9|2,32:9|3,Edges", anchor_values, true,
     ERR_MISC},
    {"Anti-aliasing", "MSAA", SET_CHOICE, F(msaa), 0, 0, 0, "Off|none|0|1|1x,2x|2,4x|4,8x|8", msaa_values, false, ERR_MISC},
    ON_OFF("Anti-aliasing", "FXAA", fxaa, false),
    {"Anti-aliasing", "FXAAMode", SET_CHOICE, F(fxaa_mode), 0, 0, 0, "Original,3_11", NULL, false, ERR_MISC},
    ON_OFF("Upscaler", "FSR", fsr, true),
    {"Upscaler", "FSRQuality", SET_CHOICE, F(fsr_quality), 0, 0, 0,
     "NativeAA|native|aa,Quality,Balanced,Performance,UltraPerformance|ultraperf", NULL, true, ERR_FSR},
    {"Upscaler", "Sharpness", SET_FLOAT, F(fsr_sharpness), 0, 0.0f, 1.0f, NULL, NULL, false, ERR_FSR},
    ON_OFF("Upscaler", "ObjectMotion", fsr_objmotion, true),
    {"Upscaler", "Reactive", SET_FLOAT, F(fsr_reactive), 0, 0.0f, 1.0f, NULL, NULL, false, ERR_FSR},
    ON_OFF("Upscaler", "AnimSurf", fsr_animsurf, true),
    {"Graphics", "DrawDistance", SET_FLOAT, F(draw_distance), 0, 0.0f, 10.0f, NULL, NULL, false, ERR_DRAW},
    ON_OFF("Graphics", "SmoothGradients", smooth_gradients, false),
    ON_OFF("Graphics", "FixKerning", fix_kerning, false),
    ON_OFF("Graphics", "BoldText", bold_text, false),
    ON_OFF("HDR", "HDR", hdr, false),
    {"HDR", "PeakBrightness", SET_FLOAT, F(hdr_peak), 0, 80.0f, 10000.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "GameBrightness", SET_FLOAT, F(hdr_game), 0, 48.0f, 500.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "UIBrightness", SET_FLOAT, F(hdr_ui), 0, 48.0f, 500.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "ToneMapper", SET_CHOICE, F(hdr_tonemap), 0, 0, 0, "Vanilla|sdr,None|off|untonemapped,RenoDRT|reno|neutwo", NULL, false, ERR_HDR},
    {"HDR", "GammaCorrection", SET_CHOICE, F(hdr_gamma), 0, 0, 0, "Off|srgb,2.2|22|gamma22,BT.1886|bt1886|2.4|24", NULL, false, ERR_HDR},
    {"HDR", "Exposure", SET_FLOAT, F(hdr_exposure), 0, 0.0f, 2.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "Highlights", SET_FLOAT, F(hdr_highlights), 0, 0.0f, 100.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "Shadows", SET_FLOAT, F(hdr_shadows), 0, 0.0f, 100.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "Contrast", SET_FLOAT, F(hdr_contrast), 0, 0.0f, 100.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "Saturation", SET_FLOAT, F(hdr_saturation), 0, 0.0f, 100.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "HighlightSaturation", SET_FLOAT, F(hdr_highlight_saturation), 0, 0.0f, 100.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "Flare", SET_FLOAT, F(hdr_flare), 0, 0.0f, 100.0f, NULL, NULL, false, ERR_HDR},
    {"HDR", "Bloom", SET_FLOAT, F(hdr_bloom), 0, 0.0f, 100.0f, NULL, NULL, false, ERR_HDR},
    ON_OFF("HDR", "UnclampedScene", hdr_scene, false),
    ON_OFF("HDR", "Analysis", hdr_analysis, false),
    {"HDR", "HDRFormat", SET_CHOICE, F(hdr_format), 0, 0, 0, "Auto,HDR10|pq,scRGB|fp16", NULL, false, ERR_HDR},
    ON_OFF("Performance", "ShowFPS", show_fps, false),
    {"Performance", "ShowBattery", SET_CHOICE, F(show_battery), 0, 0, 0, "Off,WithFPS,ByItself", NULL, false, ERR_MISC},
    {"Performance", "FPS|FrameRate", SET_INT, F(fps), 0, 30, 240, NULL, NULL, false, ERR_MISC},
    ON_OFF("Performance", "VSync", vsync, false),
    ON_OFF("Performance", "ShaderPrewarm", shader_prewarm, true),
    ON_OFF("Performance", "LoadingIndicator", loading_indicator, true),  // (ini only: not in the settings menu)
    {"Controls", "FaceButtons", SET_CHOICE, F(face_buttons), 0, 0, 0, "Position|positional|nintendo,Label|labels|xbox",
     NULL, false, ERR_MISC},
    {"Controls", "MenuConfirm", SET_CHOICE, F(menu_confirm), 0, 0, 0, "Original,South,East", NULL, false, ERR_CONFIRM},
    ON_OFF("Controls", "BackgroundInput", background_input, false),
    ON_OFF("Controls", "KeyboardPrompts", kbm_prompts, false),
    ON_OFF("Controls", "MenuChord", menu_chord, false),
    {"Controls", "ComboInputWindow", SET_CHOICE, F(combo_window), 0, 0, 0, "Lenient,Strict", NULL, false, ERR_MISC},
    {"Controls", "ChatKey", SET_TEXT, F(chat_key), sizeof g_config.chat_key, 0, 0, NULL, NULL, false, ERR_MISC},
    {"Mouse", "MouseSensitivity", SET_FLOAT, F(mouse_sensitivity), 0, 0.1f, 10.0f, NULL, NULL, false, ERR_VIEW},
    {"Mouse", "MouseSensitivityY", SET_FLOAT, F(mouse_sensitivity_y), 0, 0.1f, 10.0f, NULL, NULL, false, ERR_MOUSE},
    ON_OFF("Mouse", "MouseInvertY", mouse_invert_y, false),
    {"Mouse", "MouseSmoothing", SET_FLOAT, F(mouse_smoothing), 0, 0.0f, 0.9f, NULL, NULL, false, ERR_MOUSE},
    {"Mouse", "MouseCapture", SET_CHOICE, F(mouse_capture), 0, 0, 0, "Click,Hunt", NULL, false, ERR_MISC},
    KEYS("MoveUp", BIND_MOVE_UP), KEYS("MoveDown", BIND_MOVE_DOWN), KEYS("MoveLeft", BIND_MOVE_LEFT),
    KEYS("MoveRight", BIND_MOVE_RIGHT), KEYS("Walk", BIND_WALK), KEYS("A", BIND_A), KEYS("B", BIND_B), KEYS("X", BIND_X),
    KEYS("Y", BIND_Y), KEYS("L", BIND_L), KEYS("R", BIND_R), KEYS("ZL", BIND_ZL), KEYS("ZR", BIND_ZR),
    KEYS("Plus", BIND_PLUS), KEYS("Minus", BIND_MINUS), KEYS("DpadUp", BIND_DPAD_UP), KEYS("DpadDown", BIND_DPAD_DOWN),
    KEYS("DpadLeft", BIND_DPAD_LEFT), KEYS("DpadRight", BIND_DPAD_RIGHT), KEYS("LeftStickClick", BIND_LSTICK),
    KEYS("RightStickClick", BIND_RSTICK), KEYS("ItemLeft", BIND_ITEM_LEFT), KEYS("ItemRight", BIND_ITEM_RIGHT),
    {"Multiplayer", "Port", SET_INT, F(ldn_port), 0, 1, 65535, NULL, NULL, false, ERR_NET},
    {"Android", "SaveFolder", SET_TEXT, F(save_dir), sizeof g_config.save_dir, 0, 0, NULL, NULL, true, ERR_FOLDER},
    {"Android", "GameFolder", SET_TEXT, F(game_dir), sizeof g_config.game_dir, 0, 0, NULL, NULL, true, ERR_GAME_FOLDER},
    {"Multiplayer", "Join", SET_TEXT, F(ldn_join), sizeof g_config.ldn_join, 0, 0, NULL, NULL, false, ERR_NET},
    {"Multiplayer", "Server", SET_TEXT, F(ldn_server), sizeof g_config.ldn_server, 0, 0, NULL, NULL, false, ERR_SERVER},
    {"Multiplayer", "Key", SET_TEXT, F(ldn_key), sizeof g_config.ldn_key, 0, 0, NULL, NULL, false, ERR_SERVER},
    ON_OFF("Multiplayer", "Direct", ldn_direct, false),
    ON_OFF("Multiplayer", "SyncSmallMonsters", sync_small_monsters, false),
    ON_OFF("Multiplayer", "LagCompensation", lag_compensation, false),
    ON_OFF("Multiplayer", "ShareUrgentCredit", share_urgent, false),
    {"Monster HP", "1Player|1Players", SET_FACTOR, F(hp.scale[0]), 0, HP_SCALE_MIN, HP_SCALE_MAX, NULL, NULL, false, ERR_HP},
    {"Monster HP", "2Players|2Player", SET_FACTOR, F(hp.scale[1]), 0, HP_SCALE_MIN, HP_SCALE_MAX, NULL, NULL, false, ERR_HP},
    {"Monster HP", "3Players|3Player", SET_FACTOR, F(hp.scale[2]), 0, HP_SCALE_MIN, HP_SCALE_MAX, NULL, NULL, false, ERR_HP},
    {"Monster HP", "4Players|4Player", SET_FACTOR, F(hp.scale[3]), 0, HP_SCALE_MIN, HP_SCALE_MAX, NULL, NULL, false, ERR_HP},
    ON_OFF("Village Quests", "VillageQuestsInHub", village_in_hub, false),
    {"Village Quests", "HubHP", SET_FACTOR, F(hp.village), 0, HP_SCALE_MIN, HP_SCALE_MAX, NULL, NULL, false, ERR_VILLAGE},
    {"Multiplayer", "RyuServers", SET_TEXT, F(ldn_ryu_servers), sizeof g_config.ldn_ryu_servers, 0, 0, NULL, NULL, false, ERR_SERVER},
    {"Multiplayer", "RyuHost", SET_TEXT, F(ldn_ryu_host), sizeof g_config.ldn_ryu_host, 0, 0, NULL, NULL, false, ERR_SERVER},
    {"Multiplayer", "RyuPassphrase", SET_TEXT, F(ldn_ryu_pass), sizeof g_config.ldn_ryu_pass, 0, 0, NULL, NULL, false, ERR_SERVER},
    {"Multiplayer", "RoomServer", SET_TEXT, F(ldn_room_server), sizeof g_config.ldn_room_server, 0, 0, NULL, NULL, false, ERR_SERVER},
    {"Multiplayer", "RoomPassword", SET_TEXT, F(ldn_room_pass), sizeof g_config.ldn_room_pass, 0, 0, NULL, NULL, false, ERR_SERVER},
    {"Multiplayer", "RoomName", SET_TEXT, F(ldn_room_nick), sizeof g_config.ldn_room_nick, 0, 0, NULL, NULL, false, ERR_SERVER},
    ON_OFF("Multiplayer", "RoomHost", ldn_room_host, false),
    ON_OFF("Multiplayer", "RyuServe", ldn_ryu_serve, false),
    {"Multiplayer", "RyuServePort", SET_INT, F(ldn_ryu_serve_port), 0, 0, 65535, NULL, NULL, false, ERR_NET},
    ON_OFF("Multiplayer", "RoomServe", ldn_room_serve, false),
    {"Multiplayer", "RoomServePort", SET_INT, F(ldn_room_serve_port), 0, 0, 65535, NULL, NULL, false, ERR_NET},
    ON_OFF("Discord", "RichPresence", discord, false),
    ON_OFF("Discord", "ShowHunter", discord_hunter, false),
    ON_OFF("Bonus Content", "BonusContent", bonus_content, false),
    {"Audio", "Volume", SET_INT, F(volume), 0, 0, 100, NULL, NULL, false, ERR_MISC},
    ON_OFF("Audio", "MuteInBackground", mute_in_background, false),
    ON_OFF("Application", "ConfirmExit", confirm_exit, false),
    {"Application", "Language", SET_CHOICE, F(language), 0, 0, 0, "English|en,Spanish|es,Chinese|zh|cn|chinese", NULL, false, ERR_LANGUAGE},
    {"Application", "ButtonIcons", SET_CHOICE, F(button_icons), 0, 0, 0, "Xbox,Switch,PlayStation", NULL, false, ERR_ICONS},
    {"Application", "Theme", SET_CHOICE, F(menu_theme), 0, 0, 0, "Gold,Blue,Hunter", NULL, false, ERR_MISC},
    {"Application", "MenuScale", SET_INT, F(menu_scale), 0, 50, 200, NULL, NULL, false, ERR_SCALE},
    {"Application", "Updates", SET_CHOICE, F(updates), 0, 0, 0, "Ask,Auto|automatic,Off|never", NULL, false, ERR_UPDATES},
    {"Application", "SaveLocation", SET_TEXT, F(save_location), sizeof g_config.save_location, 0, 0, NULL, NULL, true, ERR_FOLDER},
};
#undef ON_OFF
#undef KEYS
const int g_nsettings = (int)(sizeof g_settings / sizeof g_settings[0]);

const ConfigSetting *config_bind_setting(int bind) {
    for (int i = 0; i < g_nsettings; i++)
        if (g_settings[i].kind == SET_KEYS && g_settings[i].field == F(binds[bind])) return &g_settings[i];
    return NULL;
}
#undef F

// [Keybinds] names: SDL's for a key, but its own for the ones whose name has a ',' (the list's separator) or a
// ';' / '#' (a comment in the file), and for the mouse buttons and wheel
static const struct { int code; const char *name; } key_names[] = {
    {SDL_SCANCODE_COMMA, "Comma"}, {SDL_SCANCODE_KP_COMMA, "Keypad Comma"}, {SDL_SCANCODE_SEMICOLON, "Semicolon"},
    {SDL_SCANCODE_KP_HASH, "Keypad Hash"}, {KEY_MOUSE + SDL_BUTTON_LEFT, "Mouse Left"},
    {KEY_MOUSE + SDL_BUTTON_RIGHT, "Mouse Right"}, {KEY_MOUSE + SDL_BUTTON_MIDDLE, "Mouse Middle"},
    {KEY_MOUSE + SDL_BUTTON_X1, "Mouse 4"}, {KEY_MOUSE + SDL_BUTTON_X2, "Mouse 5"}, {KEY_WHEEL_UP, "Wheel Up"},
    {KEY_WHEEL_DOWN, "Wheel Down"},
};
const char *config_key_name(int code) {
    for (size_t i = 0; i < sizeof key_names / sizeof *key_names; i++)
        if (key_names[i].code == code) return key_names[i].name;
    const char *n = code > 0 && code < SDL_SCANCODE_COUNT ? SDL_GetScancodeName((SDL_Scancode)code) : "";
    return n && !strpbrk(n, ",;#") ? n : "";
}
int config_key_code(const char *name) {
    if (!*name) return 0;
    for (size_t i = 0; i < sizeof key_names / sizeof *key_names; i++)
        if (!strcasecmp(key_names[i].name, name)) return key_names[i].code;
    SDL_Scancode sc = SDL_GetScancodeFromName(name);
    return sc != SDL_SCANCODE_UNKNOWN && *config_key_name((int)sc) ? (int)sc : 0;
}
// One of a [Keybinds] row's keys: a key or button with a name, not one the recomp keeps for itself (keymap.h)
static bool bind_key_valid(int code) { return !code || (*config_key_name(code) && !key_reserved(code)); }

// Is name (squashed) one of the '|'-separated spellings in list (from list, up to its end or a ',')? With *index, the
// number of the ','-separated item it matched.
static bool spelled(const char *list, const char *name, int *index) {
    int item = 0;
    for (const char *p = list; *p;) {
        size_t n = strcspn(p, "|,");
        char one[64];
        snprintf(one, sizeof one, "%.*s", (int)n, p);
        squash(one);
        size_t len = strlen(one);
        bool prefix = len && one[len - 1] == '*';
        if (prefix ? !strncmp(name, one, len - 1) : !strcmp(name, one)) {
            if (index) *index = item;
            return true;
        }
        p += n;
        if (*p == ',') item++;
        if (*p) p++;
    }
    return false;
}

const ConfigSetting *config_setting(const char *key) {
    char k[64];
    snprintf(k, sizeof k, "%s", key);
    squash(k);
    for (int i = 0; i < g_nsettings; i++)
        if (spelled(g_settings[i].key, k, NULL)) return &g_settings[i];
    return NULL;
}

// The first spelling of a choice (as the file writes it)
static void choice_name(const char *list, int index, char *buf, size_t size) {
    const char *p = list;
    for (int i = 0; i < index && p; i++) if ((p = strchr(p, ','))) p++;
    if (!p) p = list;
    snprintf(buf, size, "%.*s", (int)strcspn(p, "|,"), p);
}

static int *field_int(const Config *c, size_t at) { return (int *)((char *)c + at); }
static float *field_float(const ConfigSetting *s, const Config *c) { return (float *)((char *)c + s->field); }
static int choice_value(const ConfigSetting *s, int index) { return s->values ? s->values[index] : index; }
static int nchoices(const ConfigSetting *s) {
    int n = 1;
    for (const char *p = s->choices; *p; p++) n += *p == ',';
    return n;
}

static bool parse_bool(const char *v, int *out) {
    if (!strcmp(v, "on") || !strcmp(v, "1") || !strcmp(v, "true") || !strcmp(v, "yes")) *out = 1;
    else if (!strcmp(v, "off") || !strcmp(v, "0") || !strcmp(v, "false") || !strcmp(v, "no")) *out = 0;
    else return false;
    return true;
}

bool config_parse_keys(const char *value, int keys[BIND_KEYS]) {  // names separated by ',' ("Return, Keypad Enter"), or None
    char v[256];
    snprintf(v, sizeof v, "%s", value);
    squash(v);
    int got[BIND_KEYS] = {0}, n = 0;
    if (strcmp(v, "none") && *v)
        for (const char *p = value;; p++) {
            size_t len = strcspn(p, ",");
            char one[64];
            snprintf(one, sizeof one, "%.*s", (int)len, p);
            char *a = one, *b = one + strlen(one);
            while (isspace((unsigned char)*a)) a++;
            while (b > a && isspace((unsigned char)b[-1])) *--b = 0;
            int code = config_key_code(a);
            if (!code || !bind_key_valid(code) || n == BIND_KEYS) return false;
            if (!n || got[0] != code) got[n++] = code;
            p += len;
            if (!*p) break;
        }
    memcpy(keys, got, sizeof got);
    return true;
}

bool config_parse(const ConfigSetting *s, const char *value, Config *c) {
    char v[256], *end;
    snprintf(v, sizeof v, "%s", value);
    squash(v);
    int index;
    float f[4];
    switch (s->kind) {
    case SET_BOOL: return parse_bool(v, field_int(c, s->field));
    case SET_INT: {
        double d = strtod(v, &end);
        if (end == v || *end || !(d >= s->min && d <= s->max)) return false;
        *field_int(c, s->field) = (int)d;
        return true;
    }
    case SET_FLOAT: {
        float x = strtof(v, &end);
        if (end == v || *end || !(x >= s->min && x <= s->max)) return false;
        *field_float(s, c) = x;
        return true;
    }
    case SET_FACTOR:
        if (parse_factors(v, f) != 1) return false;
        *field_float(s, c) = f[0];
        return true;
    case SET_CHOICE:
        if (!spelled(s->choices, v, &index)) return false;
        *field_int(c, s->field) = choice_value(s, index);
        return true;
    case SET_SIZE:
        if (spelled(s->choices, v, NULL)) {
            *field_int(c, s->field) = *field_int(c, s->field2) = 0;
            return true;
        }
        return parse_size(v, field_int(c, s->field), field_int(c, s->field2));
    case SET_ASPECT: return parse_aspect(v, field_float(s, c));
    case SET_TEXT:  // (as written: host names keep their dashes)
        snprintf((char *)c + s->field, s->field2, "%s", value);
        return true;
    case SET_KEYS: return config_parse_keys(value, field_int(c, s->field));
    }
    return false;
}

void config_format_keys(const int keys[BIND_KEYS], char *buf, size_t size) {
    size_t n = 0;
    if (size) *buf = 0;
    for (int i = 0; i < BIND_KEYS; i++)
        if (keys[i] && n < size) n += (size_t)snprintf(buf + n, size - n, "%s%s", n ? ", " : "", config_key_name(keys[i]));
    if (!n) snprintf(buf, size, "None");
}

void config_format(const ConfigSetting *s, const Config *c, char *buf, size_t size) {
    int iv = s->kind == SET_FLOAT || s->kind == SET_FACTOR || s->kind == SET_ASPECT || s->kind == SET_TEXT
                 ? 0 : *field_int(c, s->field);
    float fv = s->kind == SET_FLOAT || s->kind == SET_FACTOR || s->kind == SET_ASPECT ? *field_float(s, c) : 0;
    switch (s->kind) {
    case SET_BOOL: snprintf(buf, size, "%s", iv ? "On" : "Off"); break;
    case SET_INT: snprintf(buf, size, "%d", iv); break;
    case SET_FLOAT:
    case SET_FACTOR: snprintf(buf, size, "%g", (double)fv); break;
    case SET_CHOICE:
        for (int i = 0, n = nchoices(s); i < n; i++)
            if (choice_value(s, i) == iv) { choice_name(s->choices, i, buf, size); return; }
        choice_name(s->choices, 0, buf, size);
        break;
    case SET_SIZE:
        if (iv) snprintf(buf, size, "%dx%d", iv, *field_int(c, s->field2));
        else choice_name(s->choices, 0, buf, size);
        break;
    case SET_ASPECT:
        if (fv == 0) snprintf(buf, size, "Auto");
        else snprintf(buf, size, "%g", (double)fv);
        break;
    case SET_TEXT: snprintf(buf, size, "%s", (const char *)c + s->field); break;
    case SET_KEYS: config_format_keys(field_int(c, s->field), buf, size); break;
    }
}

bool config_valid(const ConfigSetting *s, const Config *c) {
    switch (s->kind) {
    case SET_BOOL: {
        int v = *field_int(c, s->field);
        return v == 0 || v == 1;
    }
    case SET_INT: {
        int v = *field_int(c, s->field);
        return v >= s->min && v <= s->max;
    }
    case SET_FLOAT:
    case SET_FACTOR: {
        float v = *field_float(s, c);
        return isfinite(v) && v >= s->min && v <= s->max;
    }
    case SET_CHOICE:
        for (int i = 0, n = nchoices(s); i < n; i++)
            if (choice_value(s, i) == *field_int(c, s->field)) return true;
        return false;
    case SET_SIZE: {
        int w = *field_int(c, s->field), h = *field_int(c, s->field2);
        return (!w && !h) || (w >= 320 && w <= 16384 && h >= 180 && h <= 16384);
    }
    case SET_ASPECT: {
        float v = *field_float(s, c);
        return isfinite(v) && (v == 0 || (v >= s->min && v <= s->max));
    }
    case SET_TEXT: {  // (one line, and no comment character: the file would read it back cut short)
        const char *t = (const char *)c + s->field;
        return memchr(t, 0, s->field2) && !strpbrk(t, "\r\n;#");
    }
    case SET_KEYS: {
        const int *k = field_int(c, s->field);
        for (int i = 0; i < BIND_KEYS; i++)
            if (!bind_key_valid(k[i])) return false;
        return true;
    }
    }
    return false;
}

bool config_equal(const ConfigSetting *s, const Config *a, const Config *b) {
    switch (s->kind) {
    case SET_FLOAT:
    case SET_FACTOR:
    case SET_ASPECT: return *field_float(s, a) == *field_float(s, b);
    case SET_SIZE:
        return *field_int(a, s->field) == *field_int(b, s->field) &&
               *field_int(a, s->field2) == *field_int(b, s->field2);
    case SET_TEXT: return !strcmp((const char *)a + s->field, (const char *)b + s->field);
    case SET_KEYS: return !memcmp(field_int(a, s->field), field_int(b, s->field), sizeof(int) * BIND_KEYS);
    default: return *field_int(a, s->field) == *field_int(b, s->field);
    }
}

bool config_restart_key(const char *key) {
    const ConfigSetting *s = config_setting(key);
    return s && s->restart;
}

bool config_range(const char *key, float *min, float *max) {
    const ConfigSetting *s = config_setting(key);
    if (!s || (s->kind != SET_INT && s->kind != SET_FLOAT && s->kind != SET_FACTOR && s->kind != SET_ASPECT)) return false;
    *min = s->min, *max = s->max;
    return true;
}

// What DEFAULT_INI says of a setting: the comment lines above its key (keys right below one another, 1Player..4Players,
// share them). A line wrapped in the file is joined to the one before (that one long, not ending a sentence);
// "Default: x" goes last, left out when x is empty.
bool config_help(const char *key, char *buf, size_t size) {
    const char *p = DEFAULT_INI, *block = NULL;  // block: the comment lines that go with the next key
    bool after_key = false;
    size_t klen = strlen(key);
    while (*p) {
        const char *end = strchr(p, '\n');
        if (!end) end = p + strlen(p);
        if (*p == ';') {
            if (!block || after_key) block = p;
            after_key = false;
        } else if (p == end || *p == '[') {
            block = NULL, after_key = false;
        } else {
            after_key = true;
            if (block && (size_t)(end - p) > klen && !strncmp(p, key, klen) && (p[klen] == ' ' || p[klen] == '=')) break;
        }
        p = *end ? end + 1 : end;
    }
    if (!*p || !block || !size) return false;
    size_t n = 0;
    char dflt[128] = "", prev[256] = "";
    *buf = 0;
    for (const char *l = block; *l == ';';) {
        const char *end = strchr(l, '\n');
        char line[256];
        snprintf(line, sizeof line, "%.*s", (int)(end - l - 1), l + 1);
        const char *t = line + (*line == ' ');
        if (!strncmp(t, "Default:", 8)) {
            snprintf(dflt, sizeof dflt, "%s", t + 8 + (t[8] == ' '));
        } else {
            size_t pl = strlen(prev);
            bool list = strchr(t, ',') != NULL;  // (the values it takes, "Off, 2x, 4x": a line of its own)
            for (const char *c = t; *c && list; c++) list = *c != ' ' || c[-1] == ',';
            bool join = pl >= 80 && !strchr(".!?:)", prev[pl - 1]) && strncmp(t, "Between ", 8) && !list;
            if (n) n += (size_t)snprintf(buf + n, n < size ? size - n : 0, "%s", join ? " " : "\n");
            n += (size_t)snprintf(buf + n, n < size ? size - n : 0, "%s", t);
            snprintf(prev, sizeof prev, "%s", line);
        }
        l = end + 1;
    }
    if (*dflt) n += (size_t)snprintf(buf + n, n < size ? size - n : 0, "%sDefault: %s", n ? "\n" : "", dflt);
    return n > 0;
}

static int desktop_w, desktop_h;
static bool render_auto = true;

static void set_key(const char *key, char *val, int line) {
    char k[64], v[256];
    snprintf(k, sizeof k, "%s", key);
    snprintf(v, sizeof v, "%s", val);
    squash(k);
    squash(v);
    if (!strncmp(k, "quest", 5) && isdigit((unsigned char)k[5])) {  // [Monster HP] Quest<number> = factors
        HpScale *h = &g_config.hp;
        char *end;
        unsigned long q = strtoul(k + 5, &end, 10);
        float f[4];
        int n = parse_factors(v, f);
        if (*end || !q || (n != 1 && n != 4)) {
            LOG("[config] line %d: \"%s\" is not a value %s takes; using the default\n", line, val, key);
            return;
        }
        int i = 0;
        while (i < h->quests && h->quest[i].quest != q) i++;
        if (i == HP_QUESTS_MAX) { LOG("[config] line %d: more than %d quests set apart\n", line, HP_QUESTS_MAX); return; }
        h->quest[i].quest = (uint32_t)q;
        for (int j = 0; j < 4; j++) h->quest[i].scale[j] = f[n == 4 ? j : 0];
        if (i == h->quests) h->quests++;
        return;
    }
    const ConfigSetting *s = config_setting(key);
    if (!s) { LOG("[config] line %d: unknown setting \"%s\" (ignored)\n", line, key); return; }
    if (!config_parse(s, val, &g_config))
        LOG("[config] line %d: \"%s\" is not a value %s takes; using the default\n", line, val, key);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

// The largest size inside w x h matching the given aspect ratio, even numbers.
static void fit_aspect(int w, int h, float aspect, int *rw, int *rh) {
    if (aspect <= 0.0f) aspect = 16.0f / 9.0f;
    if ((float)w / (float)h > aspect)
        w = (int)((float)h * aspect + 0.5f);
    else
        h = (int)((float)w / aspect + 0.5f);
    *rw = w & ~1, *rh = h & ~1;
}

// Sections of DEFAULT_INI the file lacks (written by an older build) are added with their defaults at its end; the
// player's own settings stay as they are.
static void append_missing_sections(const char *path, const char *seen) {
    FILE *o = NULL;
    for (const char *p = strstr(DEFAULT_INI, "\n["); p;) {
        const char *start = p + 1, *end = strstr(start, "\n["), *close = strchr(start, ']');
        p = end;
        char name[64], key[70];
        snprintf(name, sizeof name, "%.*s", (int)(close - start - 1), start + 1);
        for (char *q = name; *q; q++) *q = (char)tolower((unsigned char)*q);
        snprintf(key, sizeof key, "|%s|", name);
        if (strstr(seen, key)) continue;
        if (!o && !(o = fopen(path, "a"))) return;
        fprintf(o, "\n%.*s", (int)(end ? end - start : (long)strlen(start)), start);
        LOG("[config] added the [%s] section to %s\n", name, path);
    }
    if (o) fclose(o);
}

void config_load(void) {
    char path[1100];
    config_path(path, sizeof path);
    FILE *f = fopen(path, "r");
    if (!f) {
        FILE *o = fopen(path, "w");
        if (o) { fputs(DEFAULT_INI, o); fclose(o); LOG("[config] wrote the default settings to %s\n", path); }
        else LOG("[config] %s is missing and could not be written; using the defaults\n", path);
    } else {
        char buf[512], seen[512] = "|";
        int line = 0;
        bool own = false;  // in a section another module reads itself ([Actions*], runtime/actions.c)
        while (fgets(buf, sizeof buf, f)) {
            line++;
            char *s = trim(buf);
            if (*s == '[') own = !strncasecmp(s + 1, "Actions", 7) && (s[8] == ']' || s[8] == '.');
            if (own) continue;
            if (*s == '[' && strchr(s, ']') && strlen(seen) + strlen(s) + 2 < sizeof seen) {
                for (char *q = s + 1; *q != ']'; q++) {
                    size_t n = strlen(seen);
                    seen[n] = (char)tolower((unsigned char)*q), seen[n + 1] = 0;
                }
                strcat(seen, "|");
            }
            if (!*s || *s == ';' || *s == '#' || *s == '[') continue;
            char *eq = strchr(s, '=');
            if (!eq) { LOG("[config] line %d: no '=' (ignored)\n", line); continue; }
            *eq = 0;
            char *val = trim(eq + 1), *cmt = strpbrk(val, ";#");
            if (cmt) *cmt = 0;
            set_key(trim(s), trim(val), line);
        }
        fclose(f);
        append_missing_sections(path, seen);
    }

    // Keep Auto/Desktop and file values, rather than persisting temporary environment overrides.
    render_auto = !g_config.render_w;
    config_store_loaded(&g_config);
    const SDL_DisplayMode *dm = SDL_GetDesktopDisplayMode(SDL_GetPrimaryDisplay());
    // (in pixels: on a scaled Wayland desktop, SDL's size is the logical one, 1280x800 at density 2 on a 2560x1600 screen)
    desktop_w = dm ? (int)lround(dm->w * dm->pixel_density) : 1920, desktop_h = dm ? (int)lround(dm->h * dm->pixel_density) : 1080;
    if (!g_config.width) g_config.width = desktop_w, g_config.height = desktop_h;

    const char *e = getenv("MHGU_WINDOW");
    int w, h;
    if (e && parse_size(e, &w, &h)) g_config.display_mode = DISPLAY_WINDOWED, g_config.width = w, g_config.height = h;
    if (getenv("MHGU_HIDDEN")) g_config.display_mode = DISPLAY_WINDOWED;
    if ((e = getenv("MHGU_MSAA"))) g_config.msaa = atoi(e) >= 8 ? 8 : atoi(e) >= 4 ? 4 : atoi(e) >= 2 ? 2 : 1;
    if ((e = getenv("MHGU_FXAA"))) g_config.fxaa = atoi(e) != 0;
    if ((e = getenv("MHGU_RT16"))) g_config.smooth_gradients = atoi(e) != 0;
    if ((e = getenv("MHGU_FIX_KERNING"))) g_config.fix_kerning = atoi(e) != 0;
    if ((e = getenv("MHGU_BOLD_TEXT"))) g_config.bold_text = atoi(e) != 0;
    if ((e = getenv("MHGU_HDR"))) g_config.hdr = atoi(e) != 0;
    if ((e = getenv("MHGU_BACKGROUND_INPUT"))) g_config.background_input = atoi(e) != 0;
    if ((e = getenv("MHGU_PAD_POSITIONAL"))) g_config.face_buttons = atoi(e) ? FACE_POSITION : FACE_LABEL;
    if ((e = getenv("MHGU_LDN_PORT")) && atoi(e) > 0) g_config.ldn_port = atoi(e);
    if ((e = getenv("MHGU_SYNC_ZAKO"))) g_config.sync_small_monsters = atoi(e) != 0;
    if ((e = getenv("MHGU_LAGCOMP"))) g_config.lag_compensation = atoi(e) != 0;
    if ((e = getenv("MHGU_LDN_JOIN"))) snprintf(g_config.ldn_join, sizeof g_config.ldn_join, "%s", e);
    if ((e = getenv("MHGU_LDN_SERVER"))) snprintf(g_config.ldn_server, sizeof g_config.ldn_server, "%s", e);
    if ((e = getenv("MHGU_LDN_KEY"))) snprintf(g_config.ldn_key, sizeof g_config.ldn_key, "%s", e);
    if ((e = getenv("MHGU_LDN_DIRECT"))) g_config.ldn_direct = atoi(e) != 0;
    if ((e = getenv("MHGU_LDN_RYU"))) snprintf(g_config.ldn_ryu_servers, sizeof g_config.ldn_ryu_servers, "%s", e);
    if ((e = getenv("MHGU_LDN_RYU_HOST"))) snprintf(g_config.ldn_ryu_host, sizeof g_config.ldn_ryu_host, "%s", e);
    if ((e = getenv("MHGU_LDN_ROOM"))) snprintf(g_config.ldn_room_server, sizeof g_config.ldn_room_server, "%s", e);
    if ((e = getenv("MHGU_ASPECT"))) parse_aspect(e, &g_config.aspect_ratio);
    if ((e = getenv("MHGU_FOV")) && strtof(e, NULL) >= 0.5f && strtof(e, NULL) <= 2.0f) g_config.fov = strtof(e, NULL);
    if ((e = getenv("MHGU_UI_ANCHOR"))) config_parse(config_setting("UIAnchor"), e, &g_config);
    e = getenv("MHGU_RENDER");
    if (e && parse_size(e, &w, &h)) render_auto = false, g_config.render_w = w, g_config.render_h = h;
    if ((e = getenv("MHGU_FSR"))) g_config.fsr = atoi(e) != 0;  // (test runs: MHGU_FSR=0|1, MHGU_FSR_QUALITY=quality...)
    if ((e = getenv("MHGU_FSR_QUALITY"))) config_parse(config_setting("FSRQuality"), e, &g_config);
    if ((e = getenv("MHGU_FSR_OBJMOTION"))) g_config.fsr_objmotion = atoi(e) != 0;
    if ((e = getenv("MHGU_FSR_ANIMSURF"))) g_config.fsr_animsurf = atoi(e) != 0;
    if ((e = getenv("MHGU_FSR_SHARPNESS")) && strtof(e, NULL) >= 0.0f && strtof(e, NULL) <= 1.0f) g_config.fsr_sharpness = strtof(e, NULL);
    if ((e = getenv("MHGU_FSR_REACTIVE")) && strtof(e, NULL) >= 0.0f && strtof(e, NULL) <= 1.0f) g_config.fsr_reactive = strtof(e, NULL);
    if (g_config.hdr && g_config.fsr) {  // (FSR's input stays 8-bit: the picture would be SDR-bright, nvn/vulkan/hdr.c)
        LOG("[config] HDR is on: FSR off\n");
        g_config.fsr = 0;
    }

    int tw = g_config.width, th = g_config.height;  // (Borderless shows the image at the desktop size)
    if (g_config.display_mode == DISPLAY_BORDERLESS) tw = tw < desktop_w ? tw : desktop_w, th = th < desktop_h ? th : desktop_h;
    // The picture's shape: the window's or AspectRatio's, at least 16:10. The game lays its HUD out for 16:9, which
    // still fits down to 16:10 (a little flatter, nvn/vulkan/exec.c), so a narrower window (4:3) shows 16:10 with bars.
    // Wider than 16:9 shows more to the sides, 16:9 to 16:10 more above and below (camera_fovy, gen.py PATCHES).
    float aspect = g_config.aspect_ratio > 0 ? g_config.aspect_ratio : (float)tw / (float)th;
    if (aspect < 1.6f - 0.005f) {
        if (g_config.aspect_ratio > 0)
            LOG("[config] AspectRatio %.3f is narrower than 16:10, which the HUD needs: using 16:10\n", aspect);
        aspect = 1.6f;
    }
    if (fabsf(aspect - 16.0f / 9.0f) < 0.01f) aspect = 16.0f / 9.0f;  // (1366x768 and the like)
    if (render_auto && g_config.fsr && g_config.display_mode == DISPLAY_BORDERLESS && (tw < desktop_w || th < desktop_h)) {
        // FSR, Borderless: it upscales straight to the size the picture is shown at (the screen, in the picture's shape)
        // instead of to Resolution, which the window would then stretch again (blurring what FSR rebuilt)
        fit_aspect(desktop_w, desktop_h, aspect, &w, &h);
        LOG("[config] FSR, Borderless: upscaling to %dx%d (the screen, in the picture's shape) instead of Resolution %dx%d\n",
            w, h, tw, th);
    } else if (render_auto) {
        fit_aspect(tw, th, aspect, &w, &h);
    } else {
        fit_aspect(g_config.render_w, g_config.render_h, aspect, &w, &h);
        if (w != g_config.render_w || h != g_config.render_h)
            LOG("[config] RenderResolution %dx%d is not the picture's shape (%.3f): using %dx%d\n", g_config.render_w,
                g_config.render_h, aspect, w, h);
    }
    if (g_config.fsr) {  // FSR: that size is its output; the game renders smaller (runtime/nvn/vulkan/fsr.c)
        static const float ratio[] = {1.0f, 1.5f, 1.7f, 2.0f, 3.0f};
        static const char *const names[] = {"NativeAA", "Quality", "Balanced", "Performance", "UltraPerformance"};
        g_fsr_output[0] = (uint32_t)w, g_fsr_output[1] = (uint32_t)h;
        float r = ratio[g_config.fsr_quality];
        fit_aspect((int)(w / r + 0.5f), (int)(h / r + 0.5f), aspect, &w, &h);
        if (g_config.msaa > 1) LOG("[config] FSR is on: MSAA off (FSR does the anti-aliasing)\n");
        if (g_config.fxaa) LOG("[config] FSR is on: FXAA off (FSR does the anti-aliasing)\n");
        g_config.msaa = 1, g_config.fxaa = 0;
        // textures are sampled for the output size (AMD's recommendation: log2(render / output)); MHGU_FSR_LODBIAS
        // overrides (A/B)
        g_fsr_lod_bias = log2f((float)w / (float)g_fsr_output[0]);
        if ((e = getenv("MHGU_FSR_LODBIAS"))) g_fsr_lod_bias = strtof(e, NULL);
        LOG("[config] FSR 3.1 %s (x%.1f): the 3D picture at %dx%d, upscaled to %ux%u, sharpness %.2f, texture LOD bias "
            "%.2f\n", names[g_config.fsr_quality], r, w, h, g_fsr_output[0], g_fsr_output[1], g_config.fsr_sharpness,
            g_fsr_lod_bias);
    }
    // Resolution scaling: a 3D picture more than 1080 lines high (the Switch's docked picture) is rendered by the game
    // 1080 lines high, in the same shape (g_render_size: what its code, its cameras and its memory see), and the
    // renderer makes its screen-sized render targets that much larger (textures.c tex_scalable; exec.c scales
    // viewports, scissors, copies and shader texel coordinates). The game's GPU pool then holds what it holds on the
    // Switch at any size: rendering at the size itself, its targets took ~59 bytes a pixel of it, which capped the size.
    // Not with FSR (its stand-ins and inputs are made for the game rendering at its input size: that keeps the old way)
    // nor with MHGU_NO_RSCALE=1 (A/B tests).
    bool rscale = !g_config.fsr && h > 1080 && !getenv("MHGU_NO_RSCALE");
    if (!rscale) {  // The game's 2.5 GB heap fits its GPU pool (below) grown by ~665 MB at most (4800x2700 played;
        // 5120x2880, +774: "out of command memory" before the town). Larger render sizes never worked: their targets
        // alone are more than the pool. Keep the shape, lower the size to what fits with 640 MB.
        const uint64_t max_px = 1920ull * 1080ull + (640ull << 20) / 64;
        uint64_t px = (uint64_t)w * (uint64_t)h;
        if (px > max_px) {
            double s = sqrt((double)max_px / (double)px);
            int ow = w, oh = h;
            fit_aspect((int)(w * s), (int)(h * s), aspect, &w, &h);
            while ((uint64_t)w * (uint64_t)h > max_px) fit_aspect(w - 8, h - 8, aspect, &w, &h);
            LOG("[config] 3D resolution %dx%d is more than the game's memory holds: using %dx%d\n", ow, oh, w, h);
            if (g_config.fsr && !getenv("MHGU_FSR_LODBIAS")) g_fsr_lod_bias = log2f((float)w / (float)g_fsr_output[0]);
        }
    } else if (w > 16384 || h > 16384) {  // (the largest image GPUs make)
        int ow = w, oh = h;
        fit_aspect(w < 16384 ? w : 16384, h < 16384 ? h : 16384, aspect, &w, &h);
        LOG("[config] 3D resolution %dx%d is larger than the GPU's images: using %dx%d\n", ow, oh, w, h);
    }
    int gw = w, gh = h;
    if (rscale) fit_aspect(w, 1080, aspect, &gw, &gh);
    g_config.render_w = w, g_config.render_h = h;
    g_render_host[0] = (uint32_t)w, g_render_host[1] = (uint32_t)h;
    g_render_size[0] = (uint32_t)gw;
    g_render_size[1] = (uint32_t)gh;
    g_rscale[0] = (float)w / (float)gw, g_rscale[1] = (float)h / (float)gh;
    if (rscale) LOG("[config] resolution scaling: the game renders %dx%d, its picture is made %dx%d (x%.3f)\n", gw, gh, w, h,
                    g_rscale[1]);
    {   // The game's screen-sized targets come out of its 848 MB GPU pool: ~59 bytes a pixel (measured at 720p to
        // 4320x2430). Above the Switch's 1920x1080 the pool grows by that much (64 a pixel), so what's left for
        // textures stays as on the Switch; at 4320x2430 the pool was otherwise too full for a boss demo's 5.6 MB
        // texture, and the game copied it to address 0 over its own code. (With resolution scaling only a picture wider
        // than 16:9 is more pixels than that.)
        uint64_t px = (uint64_t)gw * (uint64_t)gh, base = 1920ull * 1080ull;
        uint64_t size = 0x35200000ull + (px > base ? ((px - base) * 64 + 0xfffff) & ~0xfffffull : 0);
        g_gpu_pool_size = (uint32_t)size;
        if (px > base) LOG("[config] GPU memory pool %u MB (848 + %u for the render size)\n", (unsigned)(size >> 20),
                           (unsigned)((size - 0x35200000ull) >> 20));
    }
    g_render_aspect = aspect;
    g_fov_scale = g_config.fov;

    // The HUD's width: 16:9 (Center), 21:9, 32:9 or the picture's (Edges), at most the picture's; the game's 2D canvas
    // gets that width (gen.py PATCHES), exec.c places the HUD's parts in it.
    float ui = g_config.ui_anchor == UI_EDGES  ? aspect
             : g_config.ui_anchor == UI_32_9 ? 32.0f / 9.0f
             : g_config.ui_anchor == UI_21_9 ? 21.0f / 9.0f
                                             : 16.0f / 9.0f;
    g_ui_anchor_aspect = ui < aspect ? ui : aspect;
    g_ui_size[1] = 720;
    g_ui_size[0] = (uint32_t)(720.0f * g_ui_anchor_aspect + 0.5f) & ~1u;
    if (g_ui_size[0] < 1280) g_ui_size[0] = 1280;

    config_runtime_init(&g_config);

    static const char *const modes[] = {"windowed", "fullscreen", "borderless"};
    LOG("[config] %s: %s %dx%d, 3D %dx%d (shape %.3f, FOV x%.2f, HUD %.3f wide), %d fps, vsync %s, MSAA %dx, FXAA %s, "
        "face buttons by %s, controller %s in the background\n", path, modes[g_config.display_mode], g_config.width,
        g_config.height, g_config.render_w, g_config.render_h, g_render_aspect, g_fov_scale, g_ui_anchor_aspect,
        g_config.fps, g_config.vsync ? "on" : "off",
        g_config.msaa, g_config.fxaa ? "on" : "off", g_config.face_buttons == FACE_LABEL ? "label" : "position",
        g_config.background_input ? "on" : "off");
    const HpScale *hp = &g_config.hp;
    LOG("[config] monster HP in Hub quests: x%.2f / %.2f / %.2f / %.2f for 1-4 hunters, %d quest(s) set apart\n",
        hp->scale[0], hp->scale[1], hp->scale[2], hp->scale[3], hp->quests);
    LOG("[config] Village quests at the Hub counter: %s (their HP x%.2f first)\n", g_config.village_in_hub ? "on" : "off",
        hp->village);
}
