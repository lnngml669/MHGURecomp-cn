# MHGU Recomp: status and working notes

Static recompilation of *Monster Hunter Generations Ultimate* (Switch, v1.4.0, build id `FB08F1D2...`) to a native
Windows executable, modeled on LAS Recomp (`../LASRecomp`). Goal: easy modding of game data (weapon / monster
values etc.). No game files or generated code are ever committed (see `.gitignore`).

## Key facts

- The game is **32-bit ARM** (AArch32, ARM mode only, `NX-NXFP2-a32`, NintendoSDK 4.4.2), not AArch64 like LAS.
  Modules: `main` (~4.9M reachable instructions), `sdk` (nnSdk, fully symbolized), `subsdk0` (Android Stagefright
  movie player: **not recompiled**; `movie::` API to be implemented on the host with FFmpeg, as LAS does).
- Guest memory: a 4 GB window at `GUEST_BASE` (0x10000000000); guest address `a` = host `GUEST_BASE + a`
  (`G2H` / `H2G` in `runtime/cpu.h`; the name `GPTR` clashes with windows.h). Pages are committed on first touch.
- Layout (`runtime/rt.h`): main @0x200000, sdk @0x2400000, HLE fake functions @0x3000000, TLS @0x3100000,
  HLE heap @0x4000000, heap @0x8000000 (SetHeapSize gets 2.5 GB: GetInfo total memory is reported so),
  alias @0xA8000000, stacks @0xD0000000.
- 32-bit SVC ABI derived from the SDK's svc stubs (see `runtime/kernel.c` comments): 64-bit values in register
  pairs, 5th argument in r4.
- Target hardware of the owner: i7-4770K, 8 GB RAM, AMD R9 200 series (GCN, driver 2020, **Vulkan 1.2.133**,
  1.8 GB VRAM). `build/vkprobe.exe` (tools/vkprobe.c) output, 2026-10-20:
  - missing: dynamic_rendering, synchronization2, extended_dynamic_state 1/2/3, push_descriptor,
    custom_border_color, maintenance4, index_type_uint8, robustness2, provoking_vertex, ASTC, ETC2, shaderFloat16;
  - present: imageless_framebuffer, create_renderpass2, separate_depth_stencil_layouts, timeline semaphores,
    shader_demote_to_helper_invocation, scalarBlockLayout, shaderInt8 + 8/16-bit storage, samplerMirrorClampToEdge,
    vertex_attribute_divisor, external_memory_host, line_rasterization, depth_clip_enable, BC textures,
    descriptor_indexing, inline_uniform_block, shaderInt64, robustBufferAccess, dualSrcBlend, logicOp.
  The renderer must be Vulkan 1.2 baseline (works on GTX 1080 too). LAS's Vulkan backend is 1.3: reuse its pieces,
  not wholesale.

## Recompiler (tools/)

- `nso.py` ELF32/REL loader; `lifter.py` A32 + VFP; `neon.py` Advanced SIMD (+ AES, CRC32 via helpers);
  `gen.py` function discovery (.ARM.exidx, symbols, relocs, call targets, fixpoint), recursive descent (literal pools
  never lifted; pc-relative literal loads folded to constants), jump tables (`add rB, pc, #imm / ldr rT, [rI, rB] /
  add pc, rT, rB`, with scheduled instructions in between), computed gotos ("all labels" switch fallback).
- `test_lift.py` + `test_harness.c`: differential test against Unicorn (UC_CPU_ARM_MAX). 0 mismatches over tens of
  thousands of sampled instructions (incl. all reachable VFP / NEON). Run after every lifter change:
  `make test-lift`.
- `hle_list.py` writes `runtime/hle/hle_symbols.txt` from `HLE_SDK(...)` uses (SDK functions replaced on the host:
  division helpers, memcpy & co).
- `mtarc.py`: MT Framework ARC v17 list / extract / pack / index.

## Runtime (runtime/)

Ported from LAS, adapted to 32-bit: `kernel.c` (SVCs), `ipc.c`, `loader.c` (REL relocations), `dispatch.c`,
`romfs.c` (**virtual RomFS** built in memory from the loose `romfs/` folder; mod folders `mods/<name>/romfs/`
layer on top: `mods.c`), services (`fs`, `am`, `misc` (acc, set, pctl, aoc, hid service), `time`, `audio` (LAS's
audren mixer; REV4 output layout fixed)), HLE: `vi.c`, `nvn_boot.c`, `ngc.c` (no profanity filter), `input.c`
(nn::hid at API level), `offline.c` (bcat / friends / applets as an offline console), `libc.c`.
NVN layer: `nvn/nvn.h` (argument adapter `nvn_args.c`: signature strings, 'l' = 64-bit, 'f' = float),
`objects.c`, `cmdbuf.c` ported from LAS. Renderer: `nvn/vulkan/` (Vulkan 1.2, see `vk.h`): render pass objects +
framebuffers cached by view, every image in GENERAL layout with full barriers between passes, all fixed-function
state in the pipeline key, descriptor sets from per-submission pools, guest vertex / index / uniform ranges copied
per submission (the 2.5 GB heap is not imported), textures change-detected with page write tracking
(MEM_WRITE_WATCH). `NULL_GPU=1 make` builds the null renderer instead. Shader global memory (LDG/STG) reads zeros
(logged if a shader uses it). Window and controls: `ui.c`, `host_input.c`.

## Progress (2026-10-20)

Plays: health & safety -> opening movie (FFmpeg) -> title -> character creation (name typed: see "Text entry") ->
style / arts -> save slot (save written to run/save/) -> Bherna village intro cutscene -> village with player
control, ~30 fps on the R9 (the game's own rate). Everything seen so far renders correctly.

Fixed on the way (2026-10-20):
- jump tables: the longer of bound-based and heuristic lengths; backward entries; scheduled instructions (VFP
  `vmov`, up to ~20 constant loads) between `add rB, pc` and `add pc`. `generated/*/undetected_tables.txt` lists
  `add pc, rX, rY` jumps not understood as tables (currently none).
- `movie::` HLE (`runtime/hle/movie.c`): deep decoded-frame queues (video held until its time on the audio clock),
  the output-format-changed event before the first frame, and GetOutputBuffer copies into the game's own Buffer.
- InlineKeyboard: DecidedEnterArgUtf8 = text inline at +0, length at +0x7d4; Calc returns the state (0 none,
  1 ready / hidden, 3 shown) - the game waits for 1 after a text entry.
- NVN fixed-function alpha test (ColorState alpha func + SetAlphaRef) in the translator (foliage, impostors).
- Vulkan loader: System32\vulkan-1.dll of older drivers has no 1.3 entry points (VMA_VULKAN_VERSION 1.2).
- Audio: MHGU sends every voice through a splitter (now implemented, plus the BufferMixer effect) - silence before.
- Movies: tight NV12 (the game copies Y then UV right after it) into the game's own Buffer memory.
- Performance: device-local vertex cache refreshed per written page (page write tracking): guest copies went from
  ~880 MB/s to ~8 MB/s; mailbox presentation (FIFO with 2 images held the game at ~26 fps).
- Settings: mhgurecomp.ini in the game folder (runtime/config.c; written with the defaults when missing): Mode = Fullscreen /
  Windowed / Borderless, Resolution = WxH or Desktop (the screen's real pixels: on a scaled Wayland desktop, SDL's desktop
  size x its pixel density), RenderResolution = Auto or WxH, FPS = 30..240, VSync. Alt+Enter
  toggles windowed / full screen. The 3D resolution is the game's own docked render size (main 0xdbcd34 / 0xdbcd38,
  `mov` 1920 / 1080, the constants the 4K-2K mod patches): tools/gen.py PATCHES makes those two instructions read
  g_render_size. Overrides for test runs: MHGU_CONFIG=<file>, MHGU_WINDOW=WxH (windowed), MHGU_RENDER=WxH,
  MHGU_MSAA=1|2|4|8, MHGU_FXAA=0|1, MHGU_PAD_POSITIONAL=0|1. [Controls] FaceButtons = Position (default: the Switch
  layout, right button A) or Label (the letter on the button, via SDL_GetGamepadButtonLabel).
- MSAA (settings MSAA = Off / 2x / 4x / 8x, F7 or MHGU_CONTROL "msaa <n>" switches it live; exec.c "MSAA"): passes
  whose depth target has the 3D resolution render into multisampled companions (TexBackend.ms) while those hold the
  target's contents or are cleared at the pass start (a look-ahead over the command list: leading_clears); a target
  is resolved only when something reads it (lazy: vk_ms_resolve). Colour: vkCmdResolveImage; depth / stencil: a copy
  into a sampleable multisampled image + a shader writing sample 0 (stencil via VK_EXT_shader_stencil_export). NVN
  alpha tests (> >= < <=) become sample coverage (gl_SampleMask, ShaderKey.alpha_coverage). Cut-outs the game does
  with its own discard stay hard-edged. R9 270X, village, 1080p: 56 fps off, 35 at 2x, 28 at 4x, 18 at 8x. Measured
  with MHGU_CONTROL "gpuprof" (GPU timestamps per pass): the multisampled passes cost ~3 ms more at 4x, a colour
  resolve ~1.6 ms, the depth / stencil resolve ~9 ms (the driver decompressing it; Vulkan 1.2 render pass resolves
  were as slow, and a sampleable multisampled image loses its compression: passes several times slower).
  Menus that show 3D models (Character Select, Guild Card, the smithy and item box equipment previews) draw them
  straight into the finished picture, after the game's FXAA pass, in the same pass as the menu's 2D draws, so they had
  no anti-aliasing whatever the settings. A full-size colour target that gets depth-writing draws without MSAA past
  the game's FXAA pass is marked (TexBackend.ms_models, exec.c full_picture), and from the next frame on its models
  get the player's anti-aliasing (models_aa):
  - MSAA: the first depth-testing draw (or depth clear) into it copies the picture, and the depth the models test
    against unless cleared, into every sample of the multisampled companions (ms_expand; without
    VK_EXT_shader_stencil_export the stencil starts at 0, as vk_ms_resolve drops it). The 2D draws around the models
    stay without MSAA. Only a frame that alternates models and 2D keeps its 2D after the first model in the samples,
    from the frame after one (models_2d_in_samples), shaded per sample (else the seams between their quads show), so
    it costs one copy and one resolve a frame. Needs sampleRateShading. Measured on a Radeon iGPU, MSAA 4x, FXAA on,
    1920x1080, Forge Armor: 33 -> 64 FPS without per-sample 2D (the Smithy room behind it: 67).
  - FXAA: the picture is copied before each run of model draws and after it, and FXAA 3.11 ("fxaa.frag.models", luma
    from the colour) is drawn over it only where the models changed it and next to that (models_fxaa_end), so the 2D
    around them stays sharp, and only in the area the run's draws could reach (a preview's panel, 551x590 at 1080p:
    the test reads 18 texels per pixel; on that iGPU, MSAA off, 78 -> 90 FPS). Both FXAA modes: the game's own FXAA
    shader only runs in its pass.
  - FSR, or anti-aliasing off: none. FSR runs at its start of the HUD, before them, and never sees them.
  The 3D scene's passes (before the FXAA pass) keep their rules.
- FXAA (settings FXAA = On / Off): the game's FXAA pass is recognised by its fragment shader's code hash
  (FXAA_FS_HASH, exec.c) and becomes a copy of its input when off.
  FXAAMode = 3_11 draws FXAA 3.11 Quality there instead (exec.c fxaa_311, shaders.c "fxaa.frag": preset 39, no
  sub-pixel blur, edge thresholds 0.063 / 0.0312, so textures stay sharp).
  FXAAMode = Original draws shaders.c "fxaa.frag.game", the game's shader written out by hand (exec.c compile_program;
  there and not at the translation, so sources already in programs.src get it too). The translation runs a loop over a
  switch with 24 registers and a stack for every pixel. MHGU_CONTROL "gpuprof" now names the FXAA pass. The town at
  1080p (MHGU_QUICKHUNT=town, about 25 s a run), the pass's GPU time, then the frame's and the frame rate:
  - Radeon iGPU, Original: 2.97 -> 1.54 ms, 12.7 -> 11.3 ms, 71 -> 79 FPS (FXAA off: 0.26 ms, 10.0 ms, 88 FPS).
  - Radeon iGPU, 3_11: 3.42 -> 2.75 ms, 13.2 -> 12.4 ms, 68 -> 72 FPS (two gathers, and no constant array read by index).
  - RTX 5070 Ti, Original: 0.052 -> 0.035 ms of a 0.55 ms frame, too little to notice.
  Two gathers replace five reads for the pixels that end at the range test: that path costs 0.45 ms on the iGPU. The
  rest is edge pixels (31% of this town) searching along the edge. Original's picture is bit-identical: the old and new
  code ran on the same frame with the output set to their difference x255 (MHGU_GLSL_OVERRIDE), all zero on both GPUs,
  in the town, at a 1280x720 render size and in quest 101. The same test for 3_11 (town, both GPUs): also all zero. The
  game's fma()s and the order of its sums had to stay: without them 0.15% of pixels differed, as exact ties go by rounding.
  Not looking again at a search side that hasn't moved gives the same picture, but took 1.75 ms instead of 1.54 on the iGPU.
- Frame rate: the settings' FPS or MHGU_FRAMERATE (default 60, 30..240) writes the engine's target fps (float at +0x3c of the object in
  global 0x2326764, the field theboy181's 60fps patch sets) each frame. Above the monitor's refresh rate it needs
  VSync = Off: see "Frame rates above 60". MHGU_VSYNC=0/1 overrides the setting: no vsync / classic vsync.
- Open: a white flashing bar the user saw in pause menu > Status (not found yet: need a screenshot); lens flare
  blocks when first entering an area (draws skipped while shaders compile: much reduced, see "Fidelity audit").

## Fixed (2026-10-20): shimmer / light-shaft "triangle" / blocky bloom (pending the user's in-game check)

Symptom: flickering 16x8 blocks in bright areas, a wedge from the sun in hunts (light shafts), sparkle on sunlit stone.
Cause: AMD's 2020 Windows driver for GCN1 (R9 200) does not flush the colour-attachment cache for a barrier that only
says ALL_COMMANDS / MEMORY_WRITE (what vk_full_barrier and the render-pass dependencies used). The next pass sampling
the image just rendered read stale 8x8 tiles, mostly of the last-drawn triangle of a full-screen quad; lockstep dumps
hid it. Fix: barriers and dependencies name every stage and access type (vk.h VK_STAGES_ALL / VK_ACCESS_ALL*).
How it was found: F10 dumps in the hunt (light-shaft chain: pass 023 extract 960x540 -> 240x135, 024-026 radial blur
fs 7a142300 with sun position in cb4[0].xy and length cb4[2].z, offsets / weights in cb5, 027 upscale, 029 composite);
a CPU emulation of the blur matched the GPU except in those tiles; a standalone Vulkan replay (tools/vkreplay.c:
shaders from run/build/glsl, dumped input, the copy + blur ping-pong) reproduced the tiles on this GPU and
showed explicit barrier flags remove them. Ruled out on the way: clears (MHGU_CLEAR_DRAW / F9), depth / stencil,
alpha test / alpha-to-coverage, primitive restart, vertex buffer size, mip data, samplers, the 60 fps patch.
- The user's Game Bar videos are much brighter than the real image (capture encoding); on-screen pixels == "shot".
- Debug aids: F10 / "dump [n]" (all passes of n frames, depth-only passes as grey + raw float32), run-debug.bat,
  MHGU_DUMP_VERBOSE=1 (targets, pipeline state, sampler, 16 floats of the first fragment uniform buffers per pass),
  MHGU_CB_WATCH=<fs addr>, MHGU_SAMPLER_LOG=1, MHGU_TEX_LOD=n, MHGU_CLEAR_DRAW=1 / F9 (clears as draws).

## Fixed (2026-10-20): holes in dynamic shadows (pending the user's in-game check)

Hard shadows had straight-edged, camera-dependent gaps next to the sharp near cascade (a dinosaur in a hunt; villagers
in Bherna). Cause: the translator ignored condition codes. The receivers' shadow lookup (e.g. fs 7abfef00, the
ground, in the screen-space shadow-mask pass) picks a cascade with `FSET.CC RZ, |x - 0.5| < c[1][1]` then
`@P1 BRA NEU`: branch when cascade 0's y range (P1) AND its x range (CC) hold. Without the CC test, pixels inside
cascade 0's y range but outside its x range jumped with an unset depth reference -> no shadow. Now FSET .CC sets the
zero / sign flags, and BRA / EXIT / KIL / SYNC / BRK / CONT test them (translate.c cc_test; 26 village shaders use it).
Also fixed on the way: nvnCommandBufferSetDepthClamp was a no-op; the game enables depth clamp for the shadow-map pass
(now PipeKey.depth_clamp -> depthClampEnable).
Debug aids added: MHGU_GLSL_OVERRIDE=1 (run/glsl_override/<addr>_fs.glsl replaces a translated fragment shader),
MHGU_FORCE_WMASK=<fs addr> (all channels written), MHGU_DUMP_DRAWS=1 (every colour draw's program in a dump),
MHGU_SAVE_MSL=1 (instruction words as comments in saved GLSL), F8 (shadow-pass scissor: as set / none / mirrored).

## Local Play over IP (2026-10-20)

The game's Local Play (Switch local wireless: Multiplayer -> Play with People Nearby) works between PCs. The game
uses nn::ldn for the wireless network and plain nn::socket for its own traffic (one UDP socket, port 12345, with
broadcasts); MT Framework's nNetwork session layer sits on top (NEX is linked too, for online play only). Both
APIs are HLE'd at the function level, so no Switch service (ldn:u, bsd:u) is involved:
- runtime/net/ldn.c: nn::ldn. Create Hub -> the host listens on ini [Multiplayer] Port (default 39500, TCP) and
  answers LAN search probes on the same UDP port. Search Hubs -> Scan asks the LAN (broadcast + this computer) and
  every ini Join address (host[:port], comma separated) for the host's NetworkInfo. Joining keeps one TCP connection
  to the host: it assigns node numbers / addresses (169.254.x.n, the host n = 1), pushes NetworkInfo on every change
  (joins, leaves, advertise data) with the state change event signalled, and relays packets between players. The
  game's packets themselves go by UDP to/from the same port when that gets through ("MHGD" datagrams with a per-
  station token; station hello every 2 s keeps NAT mappings open), else - and after 15 s without UDP - through the
  TCP link. Only the host needs a reachable port (forwarded TCP + UDP; TCP alone works). Host gone -> the stations go to state Error (reason SignalLost / DestroyedByUser):
  the game says "Connection lost." and returns to offline.
- runtime/net/vsock.c: nn::socket on that virtual network (UDP datagrams, TCP emulated with SYN/SYNACK/data/FIN/RST
  messages - the link is reliable and ordered). The Switch's values: BSD socket options, Linux errno numbers,
  O_NONBLOCK 0x800. Nothing reaches the host's real network.
- Tested on one PC with two instances (run/ hosts, run2/ joins, 640x360, MHGU_LDN_PORT / MHGU_LDN_JOIN env
  overrides): hub created, found by LAN search and by Join address, joined, both see each other walk in the hub,
  Disconnect and a killed host handled. Not tested yet: two PCs, quests together, more than 2 players.
- The game's network library is Nintendo's Pia (statically linked; RTTI names nn::pia::local / inet / session /
  transport). Local and Online play share Pia's transport (stations, ReliableSlidingWindow, RttProtocol, keep-alive /
  life check); only the session layer differs (pia::local on LDN vs pia::inet on NEX). So Local Play already adapts
  to the measured round trip like Online does - there is nothing low-ping-only to swap out. What did matter: Pia
  expects lossy datagrams, and carrying them over TCP turns a lost packet into a stall of everything behind it,
  hence the UDP path. Tested with MHGU_LDN_LAG=<ms> (received packets held back; on both ends: round trip +2x) and
  MHGU_LDN_LOSS=<percent> (received packets dropped): 300 ms, and 800 ms with 5 % loss: join, both see each other
  move, still connected after a minute idle.
- Online Play entries: nn::nifm is HLE'd as "no internet connection" (runtime/hle/offline.c); Create Hub / Search
  Hubs / Search by ID go back to the menu (the system's error popup is not shown), Friend List is empty. Before,
  nifm's SDK code called a null function (crash).
- MHGU_LOG_NET=1 logs socket setup, =2 every nn::ldn / nn::socket call.
- Kernel fix found on the way: svcWaitProcessWideKeyAtomic re-took the mutex on timeout; Horizon returns without it
  and nn::os takes it itself, so every timed-out condition variable wait (TimedWaitEvent...) left the thread waiting
  on a mutex it owned - forever. Single player rarely times out (a thread or two hung unnoticed); the network
  threads do it constantly. MHGU_DUMP_THREADS dumps now show mutex owners and a heuristic list of callers.

## Internet hubs through a hub server (2026-10-29, branch feat/ldn-server)

Local Play over the internet without port forwarding, for friends (matchmaking key) and strangers (public), through
our own lobby / relay server (server/, Go, stdlib only; server/README.md: build, run, self-host, Docker, systemd).
Plan and security notes: docs/research/internet-hubs.md.
- ini [Multiplayer] Server (empty: LDN_DEFAULT_SERVER in config.h, the public server below;
  Off: none; host[:port], default port 39510) and Key (matchmaking key; empty: public). Both in the settings menu
  (Multiplayer page) and live (config_live_ldn; until 2026-10-29 the menu saved them but the game kept the start-up
  values): Scan / Join read them each time, a hub at each (re)connection to the server. MHGU_LDN_SERVER /
  MHGU_LDN_KEY env overrides for tests.
- What the player sees of the server (ldn.c hub_report): a notice at the top of the screen for 7 s (overlay_notice,
  drawn on ImGui's foreground draw list, so it shows with or without a menu open and takes no input) when the server
  is not found / unreachable / lost / busy / another version / refuses: hosting ("your hub is not listed online",
  once per failure, and "listed online again" when it comes back), searching ("only hubs on your local network",
  every search, but not twice within 10 s), joining (every failure; "the host did not answer" too). Texts are in
  settings_locale.h (UI_TEXT in ldn.c; tests/test_settings_locale.py checks them). The Multiplayer page has a
  "Check hub server" row: LIST with the server / key being edited (ldn_hub_check, a thread), showing "Online, N ms,
  N hub(s)" or the failure; before a check it shows the last state the game's own searches / hub saw for that server.
- Key -> room: first 16 bytes of SHA-256("MHGURecomp matchmaking key:" + key, spaces around it trimmed), all zero
  without a key (updater/sha256.c is linked into the game for it). Android without a key: the room of the key
  `public-phone`, so phones don't meet PCs in public, and no key reaches the all-zero room; PCs can still enter that
  key by hand, and the check is only in the client. The server lists a hub only for requests with the
  same room and link PROTO_VERSION; JOIN with another room answers "not found".
- Host (ldn.c lobby_thread): Create Hub also lists the hub (HOST with its NetworkInfo; UPDATE on every
  push_info_locked change; PING every 15 s; reconnects after 10 / 30 s). For each INCOMING ticket it opens a second
  connection (ATTACH), and the spliced socket goes to the same station_thread as a LAN connection. If the ini Port is
  taken, hosting with a hub server falls back to a system-chosen port (online only).
- Station: Scan asks the server (in a thread while the LAN is searched); a hub found both ways is joined directly.
  Connect to a listed hub = JOIN, then the usual F_HELLO handshake over the spliced connection.
- UDP through the server: datagrams prefixed "MHGR" + pair id + own secret (Link relay_pair / relay_secret); the
  server passes the rest to the other end. The host sends a bare prefix every second until the station's hellos come
  through, so the server knows where its end is. TCP fallback as before.
- Direct UDP by hole punching (2026-11-08, research/internet-hubs.md step 4): ini [Multiplayer] Direct (default On,
  live, settings menu "Direct connections"; MHGU_LDN_DIRECT env). The user decided (2026-11-08) that direct may be
  the default in public hubs too; Off stays as the relay-only option. Each end of a relayed link sends the server a
  32-byte "MHGQ" query over its relay socket; the server answers "MHGP" (same size: no amplification) with the other
  end's public UDP address and the pair's direct key, only once BOTH ends asked (Direct = Off on either end: no
  address is ever given out) and never relays a query. Direct datagrams start "MHGR" + pair + direct key (like
  relayed ones with the sender's secret) and must come from the address the server named: anything else reaching
  the port straight from the internet is dropped. Then the host sends U_PUNCH and the station direct U_HELLOs (200 ms
  for 15 s, then 2 s); the station's direct path is up when a direct hello is answered, and its hellos then carry
  UF_DIRECT_OK, which brings the host's up. Game packets go direct while it is up, each packet by one path only (no
  duplicates); the relay stays up beside it (relay hellos every 2 s, direct hellos every 1 s also keep the routers'
  mappings open). Liveness counts only two-way proof (station: answers to its own hellos; host: the station's hellos /
  packets, whose UF_DIRECT_OK says ours arrive): 3.5 s without and that end goes back to the relay, asks the server
  again at once (an address change after a Wi-Fi / mobile switch) and punches fast again; coming back to direct after
  a fall takes 3 answers (no flapping). The log says why there is no direct path: the other end never offers one
  (Direct Off, older game or server) after 30 s, or 15 s of punching got nothing (symmetric / CGNAT, firewall). The
  station's UDP socket is no longer connected (it hears the server and the host); SIO_UDP_CONNRESET off on Windows.
  Old servers forward the query as data and the other end ignores it; old peers never ask: both stay on the relay.
  No on-screen indicator yet (logs only).
- Debug: MHGU_LDN_RTT=1 (both ends): hellos every 250 ms carry the station's clock and the answer echoes it; every
  10 s the station logs the round trip per path (relay / direct) and both ends log their game packets sent /
  received per path (direct, UDP via server or LAN, TCP). MHGU_LDN_BLOCK_DIRECT=<s>[-<t>]: direct datagrams ignored
  from s s after a link starts (0: always, a symmetric-NAT stand-in), until t s if given (a passing outage).
- Measured (2026-11-08, two instances on this PC, ~10 game packets/s each way): through a local server, relay round
  trip 0.22-0.28 ms vs direct 0.13-0.16 ms, and after punching every game packet went direct (0 through the
  server). Through the public server (Direct Off, test key): relay round trip 10.5-12.8 ms avg, 9.2 ms min, which is
  what the relay adds over a direct path between two players on this PC's line; across a country / ocean it adds the
  players' two legs to the server. Fallback tested: punching blocked from the start (stays on the relay), direct
  broken mid-session either way (both ends back on the relay within ~4 s, packets kept flowing), the player with
  Direct Off (the host never got its address). Not tested yet: two PCs behind real NATs, a hunt over the direct path.
  Scripts: session f782a77e scratchpad (start.ps1, route.ps1, scenario.ps1 -hblock / -jblock / -hdirect / -jdirect).
- Hardening on the way: every NetworkInfo from the network goes through info_sane (counts / sizes in range, strings
  terminated, node ids = index) before the game sees it; a WELCOME's node number is range-checked (was an out-of-
  bounds read); F_REFUSE results other than nn::ldn's become ConnectionRejected.
- Tested on one PC (server on 127.0.0.1, run/ hosts on port 39500, run2/ on 39600 so LAN search can't find it, key
  "friends"): hub listed, found by Search Hubs only through the server, joined (game packets by UDP through the
  relay), both see each other in the Hub, the listing follows the player count (1/4 -> 2/4 -> 1/4), a killed station
  is seen leaving, Disconnect delists the hub, other keys / no key see nothing. Server: `go test ./...` (keys,
  versions, splice, UDP relay incl. a forged secret, rate and per-IP limits, a host that never attaches). Not tested
  yet: two PCs / real NAT, a hunt through the relay, more than 2 players. Note the joiner needs the host's hub type
  unlocked (Hunters' Pub = G Rank).
- Public server (2026-10-29): (server address was here). If you are making a publicly distributed fork, please ensure that you change the default server address *if* your fork isn't network-compatible. If it is network-compatible, then feel free to use it. If it's not network-compatible, please use a different (or empty) default server.
    - Additionally, if you are also building for Android or iOS (mobile), please ensure that *if* you use the default `morerokk` server: "no matchmaking key" on mobile always instead passes `public-phone` as a matchmaking key. This is to ensure gameplay remains stable on PC, while still allowing players to opt into crossplay by specifying a matchmaking key themselves.
- Two-instance test: scratchpad mp_start.ps1 (-port / -server / -key), hub_route.ps1 (loads the save; -mode host
  stops at Create Hub settings: A on "Hunters Hub", LEFT to "Wycademy Hub", A, X; -mode join opens Search Hubs),
  hublist.py <key> (what the server lists). The run\ save starts on the airship: ZL = Multiplayer menu.
- How many hubs Search Hubs shows (2026-10-30): the game asks Scan for up to 24 (the scan log line says "room for
  N") but its Join Hub list shows at most 18: 6 a page, 3 pages, RIGHT past the last wraps to the first; the 19th
  on are never seen. Measured with a stand-in server (scratchpad mp/fakehub.py: HOST / LIST on 127.0.0.1, LIST
  answers 20 copies of a real hosted hub, each with its own session id, bssid and hunter name "Hunter NN") and two
  instances on copies of testsave\save_0 (ports 39500 / 39600, test key): pages 1-3 held Hunter 01-18. So the order
  matters: LAN / Join hubs first (ldn_scan), then the server's (server.go list: hubs with a free slot first, then
  the fuller, then the newest). Since then (server.go list) the server's ListMax is 18 and, with more hubs than
  that, each LIST is a random 18 (shuffled, hubs with a free place kept before full ones), then sorted as before: a
  Retry shows others.
- Passcoded hubs last (2026-11-08): MHGU's advertise data (NetworkInfo +0x26C, 200 bytes) has a u16 passcode at
  +0xC0: 0xFFFF = none, else the 4-digit code in bits 0-14 (1234 = 0x04D2), bit 15 set for "Everyone", clear for
  "Exclude Friends" (measured: open 0xFFFF, Everyone 1234 = 0x84D2, Exclude Friends 0000 = 0x0000). server.go list
  ranks hubs: room and no passcode, room and a passcode, full, full with a passcode; both the random choice and the
  sort go by rank, so passcoded hubs only show when open hubs with room leave places (user's call: private groups
  should use a matchmaking key). Hosting asks the code by text entry (control "type 1234" + "textkey enter").

## Event camera pans skippable with A (2026-10-21)

Entering a village / hub area when something is new plays an event (rScheduler, arc/ev/*.arc, path
event\village\event_vNNN...) that pans the camera past the NPCs; the original can't skip it. runtime/hle/evskip.c,
hooked at uScheduler's update (gen.py PATCHES 0xb66164): A sets a playing event scheduler's speed to 30 (uScheduler:
+0x34 frame, +0x3c speed, +0x40 paused, +0x41 loop, +0x54 rScheduler, path at +0x08), so it plays out in a moment
and what it does at the end still happens (log: "[evskip] skipping <path>"). Looping stage schedulers and paused
ones are left alone. Tested with a new character's arrival in Bherna (event_v002): A during the pan -> the chief's
greeting about a second later, the dialogue then advances normally. Other events (new facility / NPC pans, story
scenes with dialogue in the middle) not tested.

## Small monsters synced in multiplayer (2026-10-21)

The original game syncs small monsters' HP / deaths only; each player's game runs their AI, so players see them in
different places. runtime/net/emsync.c makes the first player in a zone their owner (the game's own large-monster
mechanism: flag 8 sends netEmAction, monster +0x7420 says who runs it, the others replay); ini [Multiplayer] SyncSmallMonsters (default On; Off from 2026-10-27 to 2026-11-03, after
reports of synced small monsters that stop attacking and of players dropping: see "Monsters' attention scores" and below).
Tested with two instances: positions agree within centimetres, hand-over when the owner leaves works. 3-4 players and two PCs
not tested yet. Research, data layout and test details: docs/research/small-monster-sync.md.
Fixed 2026-11-04: small monsters ignored players with sync on: it forced flag 0x80 (species data, no attention scores) on all of
them and left followers running their own AI. Jaggi and Rhenoplos now target and attack both hunters, the same on both games.
Fixed 2026-11-03: players dropping in some zones (Volcanic Hollow zone 7): uEms100 restarts its first action every update,
and a master's copy would send each restart. Such a monster is now left out of the sync.

## Text entry (2026-10-21)

Text entries use the inline keyboard (nn::swkbd::InlineKeyboard: the only one seen called; the game draws its own box
and shows the text it gets through the changed-string callback). runtime/hle/swkbd.c + runtime/textinput.c: while
it is shown, the physical keyboard types (SDL text input: any layout, accents; Backspace, Ctrl+V paste), Enter
confirms (decided-enter callback), Escape cancels; the keys don't act as controller buttons meanwhile, and the
controller can confirm with Plus or cancel with B. AppearArg +0x20 = max length (names: 10); SetInputText gives the
current text as UTF-16 inline (re-editing starts from it). Callback argument: UTF-8 text at +0, length +0x7d4, cursor
+0x7d8. Invalid UTF-8 handed to the game hangs it (seen: its decoder loops), so only valid UTF-8 goes there. Tested
on character creation: typing, Backspace over an accent, the 10-character limit, re-editing, Escape; the Palico
name entry (same calls) and chat not tested. The full-screen keyboard applet (ShowKeyboard) is not used by the game
as far as seen; it still answers "Hunter". MHGU_CONTROL "type <text>" / "textkey enter|escape|backspace" for tests.

User words (fixed 2026-10-24): the game hands the keyboard the character's earlier entries as suggestions
(InlineKeyboard::SetUserWordInfo; its keyboard manager, state machine f_a62570, state 8) and waits in state 5 for the
released-user-word-info callback before Appear, giving up after 0x38e frames (~15 s: a dimmed screen, no box, and
Edit Name dead until a restart). The callback was never called, so item set names (and any entry with user words)
failed for characters with entries typed on a Switch; characters made in the port have none and went straight to
Appear. Now Calc calls it right after SetUserWordInfo. Red herrings on the way: the same dialog loads
nativeNX/arc/swkbd_eu.arc (not in the game's RomFS on a Switch either: "path not found", harmless), and the bug
looked Linux-only (it is per character: the Linux tester and the test save had Switch-made characters).

Hidden entry lock-up (fixed 2026-10-26): the 10-24 fix also called the released callback after UnsetUserWordInfo,
which the game's keyboard manager calls after every entry (state 9). The callback (f_a63d00) sets state 6, "words
back: show the keyboard", so every entry reopened 4 frames after it closed, with nothing on screen: the keys typed
into it instead of moving the menu (character creation right after the name), the manager stayed busy, and Escape
only closed it for it to reopen (the players' logs: "inline keyboard shown" again right after each "entered" /
"cancelled"). Unset releases nothing now (the words went back right after Set). Manager states (+0x2ec8 of the
keyboard object, f_a62570): 2/4 open (4: Set the user words -> 5 waits for the callback), 6 show (f_a62d88: input
text, cursor, Appear) -> 7 -> 8 shown until Calc returns 1 -> 9 (Unset) -> 3 ready; 10-12 finalize and re-initialize.

## Monster HP by the number of hunters (2026-10-21)

ini [Monster HP]: factors on large monsters' HP in Hub-type quests for 1-4 hunters (default 1 = original), plus
`Quest<number> = f1, f2, f3, f4` to set one quest apart. Only HP and part HP change (part HP: see the end of this section). A quest gives each large monster a row
of the difficulty table (resident.arc enemy\resident\em_nando_tbl, "NAN": u32 magic, version, row count, then rows
of 8 floats: HP, attack, defense...; cQuestData mVitalTblNo_N / mAttackTblNo_N / mOtherTblNo_N pick rows, and the
game moves the HP row a little per quest, e.g. 17 -> 16..19, with the size). Max HP = base HP (dtbase) x row[0], set in 0x2c04a0 /
0x2c04d8, both through the row getter 0x2baaac (monster, column 0 HP / 1 attack / 2 other), which is hooked
(runtime/hle/hpscale.c, fnhook): for column 0 it returns a copy of the row with only the HP float scaled. Village
quests are left alone by number (below 10000, Village Prowler 100000-109999); hunters = sQuestSelector's join count
(+0xd750). Multiplayer: each game computes HP itself, so the hub's host sends its settings (F_AUX, magic 0xE6) and
clients use them while in that hub. Data: sQuest *0x1a8ad90 (+0xa4 cQuestData, +8 quest number), sQuestSelector
*0x1a8ae38. Tested (two instances, Tackling the Tetsucabra, quest 10107, base HP 4000): solo x0.6 -> max HP 1392
(= 4000 x 0.58 x 0.6); two hunters, host 0.5 / client's own 3.0 -> both 1340 (= 4000 x 0.67 x 0.5). Village quest
exclusion and 3-4 hunters not tested in game. MHGU_LOG_HPSCALE=1 also logs the resulting max HP and each part's HP.
Part HP (2026-11-08): row +0xc (4th float, read through column 2) is the quest's multiplier on part HP: flinch HP
(0x299db8, rec+0x3be), sever HP (0x29d1a8, rec+0x3c0) and the monster classes' own part code; a part breaks after a
number of flinches. The hook scales it with the HP factor (HubHP included), capped at x16: the values are 16-bit, read
signed, and the largest base in the game is 1600 flinch / 1500 sever. Monsters so flinch as often per HP lost as in the
original game. Tested (quest 206, Great Maccao, hook forced to the from-Hub case because the test save starts in the
Village): flinch HP 114 / 171 / 123 / 95 at x1, 57 / 85 / 61 / 47 at x0.5, 1920 / 2880 / 2080 / 1600 at x40 (the
cap, row x16 of bases 120 / 180 / 130 / 100). Not tested: cutting a tail in play, multiplayer.

## Village quests in the Hub (2026-10-22)

ini [Village Quests] VillageQuestsInHub = On (default): at the Hub's or the Hunters' Pub's quest counter, L / R in
the rank menu or the star menu switch to the Village quests (the village counter's own menus: Training, Low 1-6,
High 7-10 stars, Urgent; what the save's village progress has unlocked) and back. runtime/hle/villagehub.c has the
mechanism: the counter's quests are sQuestSelector's list, built by a job from quest\quest_group through the filter
0x5b8090 with the area type (sGameControl +0x4c: 0 Hub, 1-6 villages - all Village quests are pooled -, 7 Pub) as
the counter type; categories and the counter UI's layout also go by the area type, so in Village mode those
functions run with it reading a village. A switch runs the list job again (0x5b7fd8 / 0x5b8070), builds the
categories anew (0x5ba8fc: they hold quest numbers, made from quest_group and the area type, not from the list) and
puts the UI back to its first state (+0x3c = 0). The counter UI sees a village only in its menus (states 0-2): with
the whole UI flipped, a Local Play hub's list came out empty (and the rows held the old categories' Hub quests).
Joining a posted quest looks its data up in the list (0x5ba50c): a quest from the other list is loaded on demand
(rQuestData loc\quest\questData\questData_<n>, resource manager *0x2326a64 vtable +0x30, mode 2) and appended -
before that the joiner had to switch to the same list ("You do not meet the requirements"). Quest numbers: group *
10000 + star * 100 + index (0 Village, 1 Hub, 2 Arena, 3 Village training, 4 Special Permit). HP: a Village quest
started from the Hub or Pub gets [Village Quests] HubHP (2.0) first, then the [Monster HP] factor for the number of
hunters (runtime/hle/hpscale.c; the host's values in a hub, sent with the others). Tested (2026-10-22, two
instances, the user driving): the switch both ways in the Pub and a Local Play Hub, the Village ★1 list in an online
hub, a village quest (101) posted by the host, joined by the client from the Quest Board, both departed together;
then (HR72 saves, both in the Pub) Vaulting Outlaw (206) posted from the Village list and joined by a client in Hub
mode (loaded on demand): Great Maccao max HP 860 in both games (row x0.43, x2.0 HubHP, x0.5 the host's 2-hunter
factor). Not checked yet: that clearing such a quest counts in the village (the clear is kept per quest number, so
it should), finishing a quest together, 3-4 hunters. Unlocks: a village's counter lists all Village quests of its
star ranges and only hides the locked ones in its menus (0x74af8c(quest, 0xff, 0) = unlocked in this save), and
the board's join only asks the list, so (a village never being online) nothing stopped joining a locked one. In
the Hub / Pub, locked Village quests (groups 0, 3, 10) are kept out of the list and out of the on-demand load: the
board then says "You don't meet the requirements to join this Quest" and shows it greyed. Tested (2026-10-23, host
HR72 hosting a Wycademy Hub, client a new HR1 save with only Village 1 star): Defiant Maccao (728, 7 stars) and A
Fungal Hunt (105, a 1-star quest the client hadn't unlocked) refused; Find the Ferns (101) joined. A Forge plugin
could do the same (same hooks), but the HP part is the port's own.

Chinese text (2026-11-09): Village quest names and descriptions came up in English in the Hub and Pub when the save's
language is Simplified or Traditional Chinese. A quest's rQuestData holds its text in 7 languages (mMessage_eng ...
_chS); the list job loads it from the loose files, but chS and chT were added by a title update and have no loose
files. Their text is only in the bundles an area keeps loaded (loc\arc\quest\vq for area types 1-4 and 6, gq and gq2
for 0 and 7: the picker 0x35339c), and the Hub never loads vq. villagehub.c now holds vq (rArchive DTI 0x2324df0,
getResource, then wait for bit 0 of +0x50: the call only starts the load) from the list job's start 0x5b7fd8 while a
Hub / Pub counter is in Village mode, and for an on-demand load of a posted Village quest; released with 0xa87660.
Only for language 7 (chT) and 8 (chS): for the other five, vq's text and rQuestData are byte-identical to the loose
files (checked for all of vq, gq, gq2). Not in vq, so still English in Chinese: quests 712, 819, 827, 1008, 1014-1016,
1043 (their text is only in their own q arc; a village has the same limit). The language is sGameControl +0xa5 (table
0xd359a8: 1 eng, 7 chT, 8 chS), saved with the game and taken from the system language only when 0; no menu changes it.
To test: control "poke" the byte to 8 (keep the word's other bytes), Quit Game and save, restart. Tested (HR72 test
save, Pub): before, English names at the Village list; after, Chinese names, objectives and locale, also after Village
-> Hub -> Village; departing on a Village quest and abandoning it works with the bundle held; English run unchanged.

Empty Village list after an area load (2026-11-09): coming back from a quest with the Village list still selected, the
counter's star rows were empty until L / R was pressed twice (in every language). The list job an area load starts
(0x20fdc4) listed 8 quests instead of 402 (selector +0x28; the job had finished its scan, so the filter refused them;
the filter's locked-quest test is the likely reason, not proven). Building the categories as a village at the stage's
start (0x5ba8fc, hooked as a test) changed nothing. villagehub.c now marks a list made by an area load in Village mode
as stale, and ui_update makes it again, as a switch does, the first time the counter's rank or star menu is up: 69 ms
once. The reload log prints the number listed. Tested (same save, Pub): Village list, departure on quest 702, abandon,
back to the counter: 402 listed, star rows there, names in Chinese.

Maps (2026-11-05): a Village quest's supply box has one Map (0x6b3), a Hub quest's four. Started from the Hub or
Pub (hpscale's test, `hpscale_village_from_hub`), it gets 3 more in the box's last empty slots. Supply data: the
quest arc's quest\supp\supp_<n> (rSupplyList, DTI 0x1a8acf0): f32 1.0, u32 count, then entries of 40 slots
{u16 item, u8 count, u8 group} (in memory 0xa4 B: +4 items, +0x54 counts, +0x7c groups; a nonzero group starts a
delivery's items, 0 continues the previous). The box is sQuest +0x1a54: +4 cQuestData, +0xc 40 x {u16 item, u16
count}, +0xac next slot, +0xc0 a bit per slot that is in the box now. 0x5abc00 (quest start) clears it, 0x5accbc
copies group 0's non-empty items from slot 0 (bits set), and 0x5ace14 the deliveries' after them (bits clear until
they arrive; delivery kind 4 from slot 32 on: Find the Ferns, 101, fills 32-39 so). Hooked after 0x5ace14: the maps
go in the last empty slots (101: 29-31), so they never take a delivery's place. Tested with the hub test forced in
101 (MHGU_VQ_TRACE=1 logs the box): maps in 29-31, bits set; not yet seen in the box's menu, nor in multiplayer.

## Urgent quests count for everyone (2026-11-01)

ini [Multiplayer] ShareUrgentCredit = On (default, applies at Save): an Urgent quest someone else posted counts for you
when you clear it, if you have unlocked it yourself. runtime/hle/urgentcredit.c has the mechanism. A clear sets the quest's bit in the save's clear flags
(the object behind the GOT slot 0x1a38d88, +0x42c; 0x723da4 tests, 0x723f30 sets) in 0x588d40, called once at the quest's end.
If the game isn't the poster's (0x5ae3b4: online, and sQuestSelector +0xd788 != +0xd789), three checks can skip it:
0x5ae75c Urgent (sQuest +0xb8 bit 12, from cQuestData mFlag +0x10c bit 0), 0x5ae768 Special Permit (group 4, bit 19),
0x5a3424 a quest of requesters 5-8 and 12 (mRequestVillage +0xd) that the save hasn't unlocked. The hook makes the first
say no if 0x74af8c(quest, 0xff, 0) says the quest is unlocked, the counters' own check for showing a quest. It runs the
quest's unlock script (0x5b2174). That script reads no clear flags: for an Urgent one progress flag decides (found by
zeroing each byte in turn: +0x501 of the object at GOT 0x1a390e0 for 206 and 303, +0x50c 10216, +0x50d 10307, +0x5af
11204), and clearing every quest's flag on a new hunter unlocks nothing. Which code sets those flags isn't known; 10216's appeared after a new hunter's 1-star key quests were cleared. The
script module (vm +0x8d0) is not loaded during a hunt, when the script always says no; it is again on the result
screen, where 0x588d40 runs. 0x74af8c also goes by a table of quest variants (0x182cde4, bits at +0x35d4): Sky Render
11401 and 1005 read locked after their clear, when their replay versions take their place. In the quest files mFlag is the file's last u16 (the language references before it have variable length): bit 0
is on 28 quests: 206, 303, 402, 501, 601, 620, 713, 806, 906, 1005, 1017, 1018, 1019, 1026, 1039, 10216, 10307, 10335,
10531, 10606, 10608, 10710, 10722, 10768, 11204, 11319, 11401, 11432. Special Permit quests stay the poster's. Other
things only the poster gets, unchanged: the contract fee back (0x5c7274) and the cutscene-seen flags (0x34e4d8,
0x34fb60). Each game decides for its own save: nothing is sent, and the host's setting doesn't matter.

Tested (2026-11-01) with a temporary harness, not committed: a quest loaded by MHGU_QUICKHUNT on a scratch save, sQuest
+0x50 set to 3 in the hunt (the game's own clear and result flow then runs), the bit forced to 0 at the start of 0x588d40,
0x5ae3b4 made to answer "not the poster". Quest 206: testsave/save_0 On (key absent from the ini) -> set; the same with
the progress byte +0x501 zeroed -> not set; a new hunter (testsave/newsave) -> not set; save_0 Off -> not set, as in the
original; the new hunter as the poster -> set. Quest 101 (not Urgent), the new hunter -> set. 
Tested in a Local Play hub (2026-11-01, two instances on one PC, the user driving): host John Rise (HR83) posted The New
Tenant (10216), joined by a new hunter whose 1-star Hub key quests were cleared solo, so that it had appeared at their
counter. An insta-clear cheat (sQuest +0xec = 0x29) on the host ended the quest for both. The joiner's log: "[urgent]
quest 0010216 cleared, posted by someone else: it counts here too"; back in the Hub "Hunter Rank 2 unlocked!", the 2-star
quests unlocked, and new NPC dialogue. Not checked yet: a joiner who hasn't unlocked the Urgent, in a real hub (only
through the harness above; the board may refuse them first).

## Quest 713 "Research Team's First Rodeo": black screen after the clear (2026-11-07, not a port bug)

A player's log: black screen right after "quest photo requested", seconds into the quest, with an instant-clear cheat on.
After the clear, 713's script (sQuest spawn manager 0x5a08e8, +0x55 = post-clear step) spawns Valstrax (em086) only once
no monster is alive (spawn condition type 6 at 0x5a153c: live count 0 and step 4), then plays its demo event082 (event
table entry 105, 0x34cad8 / 0x5a8c44: step > 4) and ends the quest. An insta-clear (sQuest +0xec = 0x29) leaves the
Congalala alive, so step 4 waits forever: the same would happen on a Switch with the cheat. Played through at 60 fps with
MHGU_KILL_AFTER (carcass gone after ~1 min, "???" Valstrax demo, Quest complete, rewards) and with A skipping the demo
(evskip): no hang. The emulators' "set 30 fps for the Valstrax quest" issue did not show here; 30 and 120+ fps untested.

## Village quest demos in a session (2026-11-07)

Report: "A Forest Fracas" (329) from the Hub in multiplayer: the Mizutsune cutscene is skipped, the Bulldrome (the
target) never appears. A quest's monster demos are the event table's type 1 entries (0x17a06fc; 329: entry 49 = event049,
area 5); the area's update looks one up (0x34cad8) when a hunter enters, and the demo's end calls 0x5a3ecc(sQuest, 1),
which readies the spawn slots waiting for it (condition type 4, parameter 0). In a session the lookup answers "none"
(sNetwork +0x63e), so those slots wait forever; Hub quests have none. runtime/hle/villagehub.c (spawn_update, on the
spawn manager 0x5a08e8) makes that call for a Village quest in a session once any hunter is in a demo's area, on every
game. Tested alone with MHGU_VQ_DEMO_TEST=1 (skips the session check) and the hunter's zone poked to 5: "[vqhub] ...
releasing", slot 0 spawned, live monster id 1 = em 0x1e. Two games in a Local Play hub (HR72 test saves, 2026-11-07):
both read sNetwork +0x63e = 1 in the quest and take it as a Village quest from the Hub, but those saves have cleared
329, so the counter offers its replay 330 (Bulldrome in slot 0 with condition type 0, no Mizutsune: not affected).
Forcing 329 (selector +0xd68 on both, depart bit +0xd65) crashed the host at the departure (empty vtable slot, main
0x2125b8, as MHGU_QUICKHUNT across town types). 329 itself still needs a two-player run from a save that hasn't cleared
it (and has the Hub counter: run3\st hasn't met the Guild Manager). Possibly the same
kind of problem: 713 / 906 end with a type 1 Valstrax demo after the clear (see the 713 section); in a session it won't
play, and whether the quest still ends is untested.

## Resolution scaling: the game renders 1080 lines, the port renders larger (2026-11-12)

Follows the GPU pool fix below: with it, the game's own render targets still took ~59 bytes a pixel of its fixed GPU pool
in the 32-bit guest, so the render size was capped (~4724x2656 at 16:9). Now a 3D picture more than 1080 lines high
(config.c) has the game render 1080 lines in the picture's shape (g_render_size: what gen.py's 0xdbcd34 patch, the
cameras and the GPU pool see; 2520x1080 at 21:9) while the renderer makes its screen-sized targets larger
(g_render_host, g_rscale = host / guest), the way emulators scale resolution. The game's GPU heap is then byte for byte
what it is at 1920x1080 (town: 280 MB used, 35 MB largest free block in 848 MB) at 4320x2430 and at 7680x4320, so the
size has no memory cap left (only the 16384 image limit). Off with FSR (its stand-ins are built for the game rendering
at its input size: the old way, pool growth and cap) and with MHGU_NO_RSCALE=1 (A/B).
- Which textures (textures.c tex_scalable): 2D, single-sample, NVN COMPRESSIBLE flag (every target the game makes; no
  loaded texture has it), size = the guest render size or a halving of it, rounded down or up (the bloom chain down to
  60x33). Not shadow maps (1024x3072), not the 1280x720 handheld twins the game makes at the same storage. TexBackend
  sx / sy hold the image's scale; logged "[vk] render target WxH ... made WxH (resolution scaling)".
- exec.c: begin_pass takes pass_sx / pass_sy from the targets (the FSR stand-in mechanism already scaled viewports and
  scissors by them; FSR now flagged separately, fsr_standin); MSAA / model-AA size tests use g_render_host,
  leading_clears the guest size; the HUD's screen-pass test is in guest units. The shaders' rscale table (binding 18,
  translate.c) is filled: [0] the pass's scale (FragCoord in guest pixels: 62 of the game's fragment shaders read it),
  [1 + i] each sampled texture's (texel fetches / size queries: none of the 6311 cached programs has any). Copies
  scale their regions (a scale mismatch blits, filtered); copies between guest memory and a scaled target go through a
  guest-size image (scale_temp / scale_blit; no such copy seen in play).
- Tested (2026-11-12, quest 206, one-frame dumps compared with MHGU_NO_RSCALE=1 at the same size): 4320x2430,
  2560x1440 with MSAA 4x, FXAA, SmoothGradients, HDR10, 21:9 3440x1440: every pass within run-to-run noise (measured with
  two native runs: 0.3-16% of pixels > 8 codes apart by option, moving Palicos and smoke); 4320 crops match in
  detail. A real clear (MHGU_KILL_AFTER) shows the quest photo at full detail (its buffer is a render-size target). No
  fps cost on the RTX 5070 Ti (240 cap either way). Not tested: menus with 3D model previews, title / movies, the Hubs
  and multiplayer, 16:10 above 1080 lines, weaker GPUs, the validation layer (not installed here).

## GPU pool at large render sizes: the Great Maccao demo crash (2026-11-11)

Report (0.16.1, RenderResolution 4320x2430): Vaulting Outlaw (206) crashed as the hunter entered Jurassic Frontier area 5,
four threads at once on wild jumps. That is the quest's monster demo (event table entry 54: event054, stage 1, area 5),
played only until the save has seen it: the demo's end sets bit n (entry n) of the event manager's seen flags (0x34e4d8,
manager at *0x1a570d0, flags at +0x64; entry 54 = +0x68 bit 22), and the lookup 0x34cad8 skips a set bit. To replay one
on a save that has seen it: `poke` that bit clear once in the quest (testsave/maccao/clearseen.sh).
Cause: the game keeps render targets and textures in one GPU heap (game heap 6, *0x1aa62e8 [6] = 0x08026010, on the
first NVN pool, 0x36400000) of a fixed 848 MB (`movt #0x3520` at 0x351e40 / 0x351fa4). The port has the game render at
RenderResolution itself (0xdbcd34), and its screen-sized targets take ~59 bytes a pixel of that heap: used / largest free
block in the town 209 / 41 MB at 1280x720, 280 / 35 at 1920x1080, 633 / 13 at 3840x2160, 791 / 5.59 MB at 4320x2430
(heap object +0x4 used, +0x7c largest free). The demo's name card texture (boss_demo, 0x555a00 bytes, loaded by
0xd084a4 on the loading thread through 0xa6a4c4) needs 2.5 KB more than that block: the allocation answers 0 and the
game copies the 5.6 MB to address 0, over its own code from 0x200000 (a Switch would fault; here code is writable and
the threads crash on what's left). Found with `protect 200000 172f000`: the memcpy faulted, called from 0xd08b40.
Fix: gen.py PATCHES at 0x351e40 / 0x351fa4 take the size from g_gpu_pool_size (runtime/config.c): 848 MB + 64 bytes a
pixel above 1920x1080, so the free part stays as on the Switch (4320x2430: 1365 MB, 37 MB largest free; the other two
pools move up, the last ending at 0x9e600000). The heap fits ~665 MB more (4800x2700 played quest 1005; 5120x2880, +774:
"out of command memory" before the town, 5760x3240: crash), and those sizes never worked before either (their targets
alone are more than 848 MB): a 3D resolution above 1920x1080 + 640 MB / 64 is lowered to it in its shape and logged
("is more than the game's memory holds": 7680x4320 -> 4724x2656, 1490 MB). Tested (2026-11-11, the user walking): 206's
demo at 4320x2430 crashed at 30 and 120 fps and played at 1280x720 at 30 and 120 fps; with the fix it plays at
4320x2430. Not tested: multiplayer at a large render size (four hunters, more of the heap in use), FSR with a large output.

## Save data safety (2026-10-22)

Reported: saves in a folder symlinked to a NAS (Linux, Proton) were lost. The game saves by DeleteFile(system),
CreateFile(system, 0x4eb8bc), one 0x24 + one 0x4eb898 write, Commit, then the same for system_backup (MHGU_LOG_FILES=1
now logs every IFileSystem call). On the Switch nothing is real before Commit; the port deleted and created the
host files at once, and the SDK aborts the game on an unexpected fs result (nn::diag Abort, svcBreak: seen by making
the create fail). So any failed call between the delete and the commit (a share hiccup, a permission, a short write
that wasn't retried) killed the game with `system` already gone; at the next start the game finds no `system`,
makes a new empty save, and that also replaces system_backup. Fix (runtime/services/fs.c): save mounts are
transactional (new content in <name>.mhgu-tmp, deletes only marked; Commit renames to .mhgu-commit, then copies it
over the real file in place, so symlinked files stay symlinks; first mount finishes a .mhgu-commit and drops a
.mhgu-tmp; an unmount without commit drops the changes), reads and writes loop until complete, and failures are
logged. Tested: new save flow (4 commits, save loads again), leftover .mhgu-commit applied / .mhgu-tmp removed, a
create made to fail after the delete (game aborts as on the Switch, `system` keeps its committed content). Not
tested: a real NAS, Linux, Proton.

## Frame rates above 60 (2026-10-21)

ini [Performance] FPS = 30..240 (default 60), VSync = On / Off (default On). The engine's own limiter (main
0xda5d00) sleeps to the target in its system object (+0x3c; the 90 / 120 fps cheat codes, `[main+0x18A6210]+0x243C`,
are this same float) and gives game logic the measured frame time as a step in 60 fps frames (+0x68: 1.0 at 60, 2.0
at 30, ~0.42 at 144; capped at +0x70 = 16). There is no fixed timestep: one game update per presented frame.
The old "cap at 60 somewhere in the engine" was the presentation: the R9's driver has no mailbox mode, so VSync
falls back to FIFO and waits for the 60 Hz monitor. With VSync = Off (immediate present, tearing possible) the
village at 640x360 runs ~138 fps at a 144 target on the R9 (CPU-bound there). Walking speed checked at 30, 60 and
~133 fps (player position 2 s apart: ~355 units each time): normal game speed.

Theory, not tested: Pierce ammo hitting more often at high frame rates. Anything the game counts per update rather
than by the step behaves differently above 60 (and at 30 the other way). Two likely ways for a piercing shot: (1) a
per-target hit cooldown counted in updates: at 144 fps it would run out 2.4x sooner in real time, so the shot can
hit the same hit zones again as it passes through; (2) collision is tested once per update at the shot's new
position: smaller steps sample its path more finely, so fewer hits are skipped on thin parts. Both mean more hits per
shot, but only up to the ammo's hit count, so damage would rise towards the most a shot can do rather than without
bound. Other per-update counters (multi-hit attacks, status ticks) could act the same way. To check later: a save
with a bowgun and Pierce ammo, the same shots into a still monster at 60 and at 144 fps, and count hits (a hook on
the damage function, or the damage numbers); the shell data (shell\pl\pl_w<weapon>_<n>\..._hit<n> files,
rBowgunShellData) would show which field holds the interval. A fix would scale that counter by the step.

Monster AI and the frame rate (2026-10-25): measured, no difference. f_276154(monster, group, index, flag) starts an
enemy's new action (stores it at monster +0x73e0, sends it to the other players) for small and large monsters alike;
testsave/ai_rate.sh counts its calls per monster with MHGU_FNTRACE over 120 s of the hunter standing still. Quest 201
zone 1 (three Larinoth): 52 / 52 / 51 actions at 30 / 60 / 120 fps, 17 / 18 / 17 per monster each time (the AI's
timers run on the step, not per update). Quest 305 (two Great Maccao plus small monsters, all over the map): 340 and
311 at 30 fps, 270 and 313 at 120 fps (the Maccao 70-87 each in every run): noise, nothing rising with the frame
rate. Not measured: what happens inside an action (turning toward a target, collision, hit cooldowns per update).

Monsters' attention scores and the frame rate (2026-11-03): fixed. Each monster keeps a score per hunter, Palico and enemy
(status block +0x254, +0x264, +0x274) and the target pickers (0x2c5b14) take the highest. Every update 0x2bbf98 does
`score += (int)(rate * step)` with a small rate from the species' table (0x2bb828; monster +0x75ec -> +0x88), tuned for
the step of 2.0 at 30 fps. Above that the cast loses the rate: at 240 fps (step 0.25) -3..3 add nothing, so closeness
stops earning attention and raised scores stay. Measured at 240 fps, change per half second (30 x rate at 30 fps): rate 4
120, rate 5 120 (should be 150). Fix (runtime/hle/hatestep.c): the monster's time is cut into 30 fps updates and 0x2bbf98
runs once for each with the step 2.0. Checked: rates 3 / 4 / 5 give 90 / 120 / 150 at 60 and at 240 fps; a hunt played by
the user at 240 fps felt normal. MHGU_NO_HATESTEP=1 turns it off (for comparing). The update ran on one thread in the 600
calls traced, so hatestep.c's table needs no lock. Not measured: large monsters (same code).
This is not why Maccao prefer Palicoes: Maccao's table (limits 1000 2000 3000 5000, rates 5 3 1 -2 -2, then -5 for a flag
that was set in these tests, set by 0x2b73c8) nets at most 0 for a hunter who only stands near, measured at 30 fps too, while the
default Palico table climbs. Without Palicoes they attack the hunter, score 0. Most likely the original game's behaviour
(game data, not compared with the original yet).

Monsters' stall timers and the frame rate (2026-11-05): fixed. Reported: above 30 fps large monsters "forget" how to close the gap,
circle the hunter and run diagonally (Rathian). While a monster hunts a target it can see, 0x2c3d08 counts how long it has gone
without settling that: monster +0x1414 (past 300: bit 0x10 of +0x1408) and +0x1418 (past 1800: bit 0x20; only while it moves slowly,
+0x140c at most step x 15; 60x as fast in some map cells). They rise by a fixed amount per update (sEnemy +0x2a30 + 1, 2 here), not
by the step, tuned for 30 updates a second: 8x as fast at 240 fps. Past them the monster repositions: 0x2c46c8 picks a point 60
degrees off its target (+0xba60). Fix (runtime/hle/emstall.c, tools/gen.py PATCHES 0x2c4058 and 0x2c4150): what they add is scaled by
step / 2; the same at 30 fps. MHGU_NO_EMSTALL=1 turns it off (for comparing). Measured, +0x1418 per second: 40 at 30 fps, 38 at 240 fps
with the fix, about 265 at 240 fps without (from one pair of samples).
Rathian (quest 405), action 2:20, the diagonal run (about 2300 units, 57 degrees off the hunter): 9 in 10 min at 240 fps without the fix.
With it: 0 in 15 min with the hunter pinned; 8 in 20 min with the hunter free, none while in the hunter's zone (the same action is also how
a monster moves when apart from the hunter). At 30 fps: 0 in 10 min and 0 in 15 min pinned. Mean distance to the hunter 1002 without, 814 with, 822 at 30 fps. Not explained: with the hunter pinned, 7:0
(a close bite) 15 at 30 fps and 31 at 240 fps in 15 min. 7:45, likely the reported side bite (not checked by eye): 6 and 3 in 15 min, by the
same script path; with the hunter free to move, none in 30 min at 240 fps, unexplained. Rajang (quest 405 with em023, 5 min each): no clear
difference between 30 fps and 240 fps, fixed or not; 2:6 (a long run away from the hunter) 3 times without the fix and never in the two others,
too few to mean much. The timers are shared monster code (not for two monster numbers, en +0xb5f4 = 3 and 0x53, and stops on some stages by
0x2c457c), but each species' script decides what repositioning looks like. Not measured: other species, 60 and 144 fps.
"Monsters change areas too often at high frame rates": not reproduced. In all these runs (standing hunter, about 2 h) a monster
changed zones only to follow the test's summon. The hunter did no damage, though, and hits may well be what makes monsters leave.
Tools: MHGU_SUMMON=<cm> (hle/dummy.c: the zone's large monster placed in front of the hunter outside the camp, again after 15 s apart;
hunter's HP +0x13d6, red part +0x13da held high, position pinned, or a knockback out of the area puts it back in the camp),
MHGU_EMTRACE_POS=1 (10 times a second: position, yaw, target), MHGU_EMTRACE_CMD=1 (each step of the AI script: interpreter 0x282f80,
rEnemyCmd, enemy\cmd_tbl\emNNN_00_cmdtbl in the monster's arc). A monster's species is en +0xb5f0. Swapping a quest's monster for a test: byte
+0x7e of questData_0000405 and a b_m01emNNN_00 set file (mtarc, from a quest with it on that map), in a mod.

Monster jumps and the frame rate (2026-10-27): fixed. Reported: Volvidon's body press (it leaps at the hunter and
lands on its back) far too fast, faster the higher the frame rate. Some actions move the monster with the velocity and
acceleration in its status block (*(monster + 0x1428) = monster + 0x1440: +0x40 position, +0x10 velocity, +0x20
acceleration) and integrate them once per update with no step: `pos += vel; vel += acc; acc.y += -0.2`, tuned for the
Switch's 30 updates a second. Measured (Volvidon, actions forced with emact, MHGU_EMTRACE=2): body press 7:92 / 7:93 at
30 fps in the air 1.0-2.2 s, 900 up; at 120 fps the same 900 in 1.0-1.4 s; everything step-driven around it
(wind-up, lying on its back) the same, so the whole action lasts as long - only the jump itself plays 4x fast. All
121 group 7 actions were timed at 30 and 120 fps: the rest last the same. The writer was found with interpwatch
(below): 0x1122e98 / 0x1122f34 (rising / falling), called with r0 = the status block. The same inlined integrator
(searched for: vel += acc stores on a status block) is in four blocks: 0x1122b40 / 0x1122b90 (Arzuros / Lagombi /
Volvidon hops, vertical only), 0x1122e3c / 0x1122ed8 (body press), 0x10f6ea8 (Zinogre, no jerk term). Fix
(runtime/hle/emjump.c, tools/gen.py EMJUMP): their 26 stores advance the sequence by s = step / 2 updates (1 at 30 fps;
at most 1) with Newton's forward differences, exact for that cubic sequence, so the monster is where the 30 fps game
has it at every 30 fps frame. Checked: 7:92 / 7:93 at 120 fps now in the air 1.05-2.2 s, apex ~900 at 1.7 s, as at 30
fps. MHGU_NO_EMJUMP=1 turns it off (for comparing). Tested by the user at 120 fps: the body press looks right now.
Volvidon's 7:98 (a hop, then a drop of ~5000) is the same code: at 120 fps it now follows the 30 fps curve within a
few units (before: fell 3-4x fast). Other position updates, read (2026-10-27): a looser search (a store to [rX,
#0x44] with a load of [rX, #0x14] and an add within 8 instructions before it) also finds 0x27b39c, 0x27b624,
0x27c754 (shared monster code), 0x10f740c, 0x10fa484, 0x11002dc, 0x129de8c: `pos += vel * step`, the step being the
monster's own +0x1c (2.0 at 30 fps, 0.5 at 120: the engine step); 0x1242e5c, 0x12fbb68, 0x1313c50, 0x11d1354: also
scaled; 0x11bcd84 / 0x11bd044 set the height from a curve function (not accumulated); 0x21a554 is stack temporaries.
None unscaled. Duramboros (suspected by the user: a jump like Zinogre's): quest 404 moved to the Arena with em055
(test mod DuramborosArena, the spawn from q0010749's b_m09em055_00), all group 7 actions (0-51; its AI only uses
groups 1, 2, 7) swept at 30 and 120 fps with positions every update: every action lasts the same, and none rises or
falls fast at either rate (fastest ~800 units/s; Volvidon's body press: 2900 at 30 fps, 7600 at 120 before the fix).
Not covered by the search: gravity added per update to a velocity whose position use is scaled (jumps would come out
lower and shorter at high frame rates rather than faster) - the vertical speed comparison would show that too.
Tools for the next suspect: scratchpad-style test mods (quest 404 in the Arena with another em), MHGU_EMTRACE=2 sweeps
at 30 and 120 fps, then compare the fastest vertical speed per action.
Test setup (scratchpad, not in the repo): quest 404 (Hunt a Volvidon) moved to the Arena by a test mod (stage byte
+0x14 of questData_0000404 = 9 in its arc and in loc\arc\quest\vq.arc, the Village list's copy the counter takes the
stage from; the Arena's b_m09em062_00 spawn), MHGU_QUICKHUNT=404, then the hunter walks from the waiting room (north
2 s, east 2.7 s, north through the gate: an area change, so the hunter can't be placed there by poking its position).

Training dummy (2026-11-02, debug, runtime/hle/dummy.c): MHGU_DUMMY=1 holds the zone's first large monster in front of the hunter (240 cm, or MHGU_DUMMY=<cm>), in the hunter's area, its motion stopped, outside the camp: nothing can be hit in the camp. Every hit on it takes 1 HP and logs the damage it would have done, so attacks can be tested without chasing a monster; GU has no training area. Tested hidden on the unmodded game, quest 404 (Volvidon), Charge Blade: walk out of camp, hits logged per part. What it rests on: a player's weapon attack is one object at player+0x3020 (+0xc owner, +0x34 u16 its number, +0x38 s16 its motion value: damage is proportional to it, +0x5c / +0x60 frames until its hitbox opens and how long it stays open). A monster remembers the numbers that hit it (status +0x448, a fixed list; 0x36ba4c checks it in the collision update 0x36b15c): one hit per number, so a new number makes a new hit while the hitbox is open.

Buff icons and the frame rate (2026-10-28): fixed. Reported: with two or more buffs the icon beside a name on the HUD's status plates (yours, the other hunters', the Palicoes') takes turns far too fast at 240 fps. The plates (cUIOStatusPlate / cUIOStatusPlateGuests, update 0x834314) call 0x834d00 once per update for each of their two icon slots ({index, countdown, shown} at plate +0xf0 / +0xfc; tables of 54 and 36 icons at image 0x1839250 / 0x18395b0, tested against the player's buff flags +0x2840..+0x2864, rebuilt from the buff timers each update at 0x49f0xx): the countdown drops by 1 per update and is reloaded with 20, 0.67 s at 30 fps, 0.08 s at 240. Fix (runtime/hle/buffcycle.c, tools/gen.py PATCHES): the decrement (0x834d20) takes step / 2 updates (at most 1) in 1/65536 units and the reload (0x834ef4) is 20 of those. Checked at 240 fps (test save, quest 101, two buffs from their timers: player +0x287c and +0x2880 poked to 3000): the two icons change every 0.667 s, 12 times in 8 s.

Oversized decorations crash the equipment view (2026-11-10): fixed, not tested in game. Reported from emulators: a hunter whose armor is modded for more slots slots a decoration bigger than the unmodded piece allows (a 3-slot decoration in a 2-slot piece); other hunters crash when they view that hunter's equipment in the UI (confirmed by the user on emulators; the console runs the same code). Cause, in the game's code: 0x2db66c gives a piece's free slots, its slot count (from your own unmodded data) minus each decoration's size (`subne r8, r1, r0` at 0x2db770), returned as a u8, so 2 - 3 = 255. The slot icons (0x750570) keep the piece's three slot widgets in an array on the stack (sp+0x10) and draw `free` empty slots after the decorations (loop 0x750680): 255 reads past the array, each word handed to the UI calls (0x76e6a8 / 0x76e6fc) as a widget. Nothing checks another hunter's decorations on arrival. Fix (tools/gen.py PATCHES): the free count is clamped at 0 at 0x2db778 (`ldrh r1, [r4, #0xa]`, which every subtraction reaches), so all of 0x2db66c's callers (0x750570, 0x780a60's slot widget, 0x5c1be0...) see 0. Such a piece then shows its decorations' icons without an empty slot; skills are unaffected (0x2ddd48 reads all three decoration ids without the slot count). Also covers your own save after a slot mod is removed. To test: two instances, one save with a 3-slot decoration in a 2-slot piece (decoration ids at the piece's entry +6/+8/+0xa), view that hunter's equipment from the other.

KO (stun) and the frame rate (2026-10-29): not found yet. Reported: KO from head hits with blunt weapons much harder at
high frame rates (a 240 fps player: Alatreon hammer solo, horns broken early, 0-1 KOs). Suspected status decay counted
per update: it isn't. Status data (dt_tune, rEnemyDtTune; monster +0x75ec -> the resource, entry pointers at +0x98:
poison, sleep, paralysis, stun, exhaust, mount, blast, ...): per status s16 initial threshold, decay interval (60 fps
frames), decay amount, duration, increase per KO, max (poison two more). The status block *(monster + 0x1428): stun
buildup +0x5d76, threshold +0x5d78, decay timer f32 +0x5d7c, KO count +0x5d80, stunned bit 0x10 of +0x5e08, time left
f32 +0x5e0c. A head hit adds KO x part multiplier / 100 (at least 1) to +0x4d2 (0x29db54); the monster's update applies
it (0x29a34c -> 0x2a2e18: buildup += it, decay timer reloaded; at the threshold the KO starts, 0x2a2f0c, unless one of
the u8 counters +0x3a2..+0x3a4 (set to 2 by 0x2c0410 / 0x2c0438 / 0x2c044c, -1 per update at 0x2c957c) or vtable
+0x39c (overridden by 3 monsters: 0x110d8f4, 0x11c266c, 0x11e3298) holds it back at threshold - 1); after a KO the
threshold rises (0x2a2f80). Decay (0x2a398c, all statuses) and the KO's duration (0x2c9254) count down by the
monster's step (+0x1c, via 0x272128 / 0x73aa84). Measured (Arena Volvidon, buildup poked to 90): 5 every 10 s at 30 and
at 120 fps; a KO (pending KO poked) lasts 10.0 s at 30 and 60 fps. Next: MHGU_KOTRACE=1 (runtime/hle/kotrace.c) logs
every hit's KO, the buildup / threshold, KOs held back at the threshold, KO start / end and decay, for a player's
30 vs 60 fps hammer session. Debug aid added: the control file's "interpread <lo>:<hi> <file of entries>" (interp.c:
logs the instructions of the listed functions and their callees that read a guest range).

KO in multiplayer (2026-11-07/08): the monster's owner decides, no frame-rate cause found. Theory tested: KOs harder only
online. How hits work: every game computes hits for every hunter's melee attacks against its own copy of the monster
(hit dispatch 0x370968 sends a player's hit to 0x376ad0 whether the attacker is local or not; attack types 8 / 9 / 0x45,
likely shots, only on the owner: 0x36b4e0 / 0x3709a0 test +0x7420). Only the owner applies a KO (0x29a34c -> 0x2a2e18):
its buildup (+0x5d76, with the other statuses +0x5c94..+0x5daa) goes out in netEmAction (send 0x2cbb74, at each new
monster action) and overwrites the others' copies (receive 0x2cca0c). So a client's head blow counts only if the
host's copy of the client (built from its network updates) also lands it on the head. Measured (two instances, two
copies of a hammer save, Tackling the Tetsucabra, MHGU_DUMMY_SLOT=1 + MHGU_DUMMY_FACE=1 on both, the client pinned):
the host registered every client head blow at 60/60 (26 of 26), 30/30 (24 of 26) and host 240 / client 60 (27 of 27);
host 240 / client 30 once 2 of 26, but this PC can't run both games at those rates (median real rate during hits ~10
fps on the host), so that is overload, not a frame-rate result. Single player at 30 and 240 fps: same KO per blow.
Network sends are paced by game time, not frames (MHGU_NETRATE, real 30 / 60 / ~130 fps): ~12 UDP datagrams/s,
~1.2 KB/s per game; netPlPositionQuest (send 0x400438, from 0x49ca48) ~7.5/s, netPlAction (0x3ffbf8) on new actions,
netEmAction (0x3eb868) on monster actions. The remote hunter: a position update (apply 0x3ffff4: target +0x1480, facing
+0x14a0) starts a 20-frame glide (0x480548: counter +0x147c, velocity +0x1490; each update 0x4806e0 moves it by
velocity x step and counts down by the step, so it takes the same time at any frame rate; 800+ units off, or every 40th
update, it snaps); an action (netPlAction apply 0x3ff308) snaps the copy to where and how the attacker started it, then
plays the move from its first frame. So the host checks a client's swing about one network delay after it was made,
against a monster the client saw about one delay late: misses grow with the round trip and with how fast the head
moves (the frozen dummy hides this). Internet hubs added the server's legs to that delay until direct UDP (above).
Debug aids: MHGU_DUMMY_SLOT=<0..3> (the dummy in front of that player on every game), MHGU_DUMMY_FACE=1 (it faces the
hunter: heading status +0x54, 65536 = a full turn, rebuilt into the rotation each update), control file "dummy <cm>
<degrees>" (distance and heading; pins our hunter, held for, in place with its HP topped up) and "fps <n>" (frame rate
target from now on); KO trace lines say "own 1" on the game that runs the monster; MHGU_NETRATE=1 (runtime/hle/netrate.c:
real fps, UDP datagrams / bytes and RPC sends per send site every 5 s; RPC send 0xbfc3d8, the return address names the
message type). Caveat: the dummy (motion speed 0) also stops the KO's countdown, so a KO on it lasts minutes. Two-instance
route (both from the airship save, Hub Low 1 star quest 7): session da3c4186 scratchpad mp_go.ps1, mp_attack.ps1,
rate_phase.ps1.

Lag compensation (2026-11-08, branch feat/lag-compensation, prototype, tested with two instances on one PC): a hunter's melee hits count as that hunter saw them. runtime/net/hitsync.c, ini [Multiplayer] LagCompensation (default On), env MHGU_LAGCOMP; the file's header has the design. Only the owner applies a hit, for HP and parts as well as KO: 0x370968 -> 0x376ad0 (every game, one attack against one target) only adds to per-update fields of the status block, and 0x297ddc (consumes them into HP +0x370, parts, KO via 0x29a34c) returns at once when +0x7420 is 0; netEmAction overwrites the others' HP (0x2cc7dc). The fields: +0x484..+0x4ff, +0x3a0, +0x444, monster +0x142c.. (list in hitsync.c). Order: the collision update's start (0x36b15c -> 0x37260c) clears them if bit 30 of monster +0x1408 is set, hits add to them, the monster's update (0x2adb3c -> 0x2a5900 -> 0x2a59d0 -> 0x297ddc) consumes them and sets that bit. So a report added at 0x297ddc's entry is consumed once and cleared, without setting anything else (measured below). The design: the hunter's game snapshots the fields around 0x370968 and sends the change (F_AUX, reliable link, magic 0xE7); the owner restores the fields after its copy of a reporting hunter hits (sparks still show) and adds received reports at 0x297ddc's entry. Aggro doesn't go through the fields: 0x29dd40 is recorded and called on the owner (+0x254 + 4 x slot: 50 + damage x 20 before multipliers, measured 730 for damage 34). The per-swing list (+0x448, one hit per attack number) is left alone. Direct weapon hits on large monsters only (attack +0x6d = 1, +0x10 = 0; bow and bowgun shells were added later, see the next paragraph): kinsects, phials, thrown items and Palicoes (+0x6d = 4) stay as they are. Mixed versions without touching PROTO_VERSION: each game with it on sends a Hello every second, an owner ignores a copy and applies its reports only while it hears that hunter's Hello (3.5 s) and has it on itself; emsync.c's and hpscale.c's handlers check their magic and ignore the rest, and the host relays every F_AUX frame. Off in crossplay. Reports are range-checked (MAX_ADD); a hostile client can still report fake hits within range. Checked: it builds; one game with an earlier build (only the tracer, MHGU_HITSYNC_DIFF=1), quest 404, MHGU_DUMMY=1, Great Sword: 14 hits (7 hunter, 7 Palico), every byte each one changed logged, all in the list above except the aggro score +0x254 / +0x268 and +0x2c9 (a byte the aggro code sets), plus monster +0x1432 on Palico hits only. No status or KO weapon in that run, so those fields come from the code. Two instances (host owns the monster, Hub 3 star Flames of Glavenus Passion, two copies of testsave/save_0, Great Sword, MHGU_DUMMY=1 + MHGU_DUMMY_SLOT=1 + MHGU_DUMMY_FACE=1, 1 damage per hit, the client swinging): on / on, 10 reports sent, 10 applied, 10 of the owner's copy's hits ignored; then a counted stretch: host HP -27 = 16 hits it applied itself (Palicoes) + 11 reports, its 11 copy hits adding nothing, so no double hits and no repeated damage. Owner on / client off: no reports, nothing filtered, HP -12 for 12 hits. Owner off / client on: 10 reports sent, none applied, HP -13 for 13 hits. With the released 0.15.5 (dist zip, no hitsync, MHGU_DATA_DIR at build/data): 0.15.5 owner, this branch's client: 10 reports sent and ignored, HP -19 for 19 hits; this branch's owner, 0.15.5 client: nothing filtered, HP -19 for 20 hits counted a moment apart (a Palico hit between the two readings is the likely reason). Both stayed connected. Free monster (MHGU_SUMMON=300, no dummy, real damage, hunters pinned, 70 scripted swings): 100 ms added each way: the client saw 7 hits (damage 302), the owner's copy of it 9 (422); no added lag: 6 (319) against 8 (402). Too few hits to say how often swings are lost, and these are totals, not matched hit by hit; both runs had the copy landing more than the hunter saw, the case where this feature lowers damage against the original. A real session with MHGU_LOG_HITSYNC=1 ("slot N so far: reports sent ..., its copy hit ...") would give the figure. Who owns a large monster: the quest's poster, not the hub's host. Measured with the second player posting and departing the quest: on the hub host's game +0x7420 was 0 and +0x7424 slot 1, on the poster's 1 and slot 1. The owner is set at start-up (0x2b167c) and claimed once (0x2b16e0, the only sender of an owner change found); nothing moves it by zone. With the hub host then swinging and each game holding the monster in front of its own hunter (MHGU_DUMMY without MHGU_DUMMY_SLOT, so its copy missed every time on the owner): 9 reports sent, 9 applied, 0 copy hits, owner's HP -9, where the original game would have done nothing. Hub host in camp, client alone in zone 1 with the held dummy (host also the owner): 10 reports sent and applied, HP exact. netEmMasterSelect / Inquire have only vtable senders: when they run is not known (a disconnect is a guess). Not tested: a KO or status weapon (those fields are from the code), the aggro replay's effect on targets (the call runs, the scores were not read), 3-4 players, two PCs, an owner handover mid-hit. Open: species overrides of the on-hit vtable slots +0x2f8 / +0x98 run for the copy's hit, not for a report; a hit arriving during an owner handover can be lost. Scripts: testsave/lagcomp_test (outside the repo): full.sh <tag> <host on> <client on> runs the whole route and prints the counts; full_old.sh with OH=1 / OJ=1 runs 0.15.5 as that side; full_free.sh is the free monster run. A save for the joiner must be high enough rank for the hub (testsave/urgent_joiner isn't). MHGU_SUMMON now waits for a quest (it fired in the hub, zone 255).

Lag compensation for bows and bowguns (2026-11-09, two instances on one PC, 30 fps, 640x360): the same design as melee, because shells go through the same 0x370968 on every game. An earlier note here said they are hit-checked on the owner only; the trace shows otherwise: 6 shots, 13 arrow hits on the shooter's game (+0x7420 0) and 13 on the owner's copy (+0x7420 1), each with attack +0x10 = 2, +0x6e = 0, +0x70 = the player, +0xc = the shell, and the same fields changed as a melee hit (status block +0x444, +0x484.., +0x4e4, +0x4f0, the per-swing list; +0x2cc changes too and is not reported, like a melee hit's). Reported per hit, so a Rapid shot's arrows or a Pierce shot's hits are counted one by one. Which shells: by vtable (SHOT_VT in hitsync.c), uShellPlw10_000 / _001 (bow) and uShellPlw04_000 / _100 / _101 (w04 for both bowguns); every other player shell stays as it was. A copy's arrows still fly and spark on the owner, with no damage. Mixed versions: shots are their own message kind (M_SHOT, which a melee-only build drops) and the Hello gets a fifth byte, caps bit 0 = this hunter reports shots (older builds send and read only four bytes); the owner ignores a copy's shots only from a hunter with that flag. Checked (host owns the monster, MHGU_DUMMY=300 + MHGU_DUMMY_SLOT=1 + MHGU_DUMMY_FACE=1, control "dummy 800 180" on both, the client shooting, 1 damage per hit): on / on, 8 shots: 24 reports sent, 24 applied, the owner's copy landed 16 hits, all ignored; owner HP -33 between the first and the last report = 23 reports + 10 Palico hits. Client off: no reports, nothing filtered. Owner off / client on: 19 sent, none applied. Melee-only owner (the build before this change) / this client: 21 sent, none applied, nothing filtered. This owner / melee-only client: no shot reports, nothing filtered. Not tested: a bowgun (the vtables come from the class list and the bow's was confirmed live; the only save had a bow), uShellPlw10_001, Pierce and other shot types, bow / bowgun Hunter Arts, real damage on a free monster or with added lag, 3-4 players, two PCs. Explosions that bowgun ammo may spawn through other shell classes (uShellPlEffect*) stay as they were. The user's bow save (run3/bowsave, Rapid bow) fires with X held about 1 s, then R; X alone only charges.

Lag compensation in crossplay, with the emulators' Forge plugin (2026-11-10, branch feat/lagcomp-plugin-interop): hitsync.c ported to a Forge plugin for emulator players (lagcomp.nro, "Lag Compensation", kept outside this repo in C:\MHGURecompile\lagcomp-forge with its notes). The plugin can't use F_AUX, so it sends the same messages (magic 0xE7, Hello / Report / Shot, same layout) as UDP broadcasts on port 47318 of the local play network, through the game's own nn::socket; Ryujinx's LDN proxy carries any port. Now the port does the same in crossplay (ldn_crossplay(): a Ryujinx LDN lobby or a room): hitsync sends there with ldn_send (UDP broadcast, port HITSYNC_UDP_PORT) instead of ldn_send_aux, and vsock_deliver hands datagrams to that port to hitsync_aux_received; outside crossplay it stays F_AUX, so older builds keep working with this one. LagCompensation is no longer off in crossplay. A Hello or report carrying our own slot is dropped (a broadcast can come back). forge.c doesn't start a plugin named "Lag Compensation" (logged): the port has it built in, and with both on every hit would be reported twice. Checked: recomp-only hub, two instances, testsave/lagcomp_test/full.sh: 10 reports sent, 10 applied, 10 copy hits ignored, as before. Crossplay, one PC, this build with RyuServe = On as the LDN server and a Ryujinx 1.2.82 copy (C:\Ryujinx\lc1, Forge 1.5.1 + the plugin's test build that holds the monster like MHGU_DUMMY_SLOT=1), Great Sword, 1 HP per hit: the port's log "slot N reports its hits (crossplay, UDP)" and the plugin's Hello both ways. Port host owns the monster, Ryujinx swings: 6 reports sent by the plugin, 6 applied by the port, 6 copy hits ignored, HP -10 for 10 damage calls. Ryujinx posts the quest and owns it, the port's hunter swings: 9 sent by the port over UDP, 9 applied by the plugin, 9 copy hits ignored, each report consumed as one hunter damage call (3 more kind-1 calls of 10-13 damage on another part came with no swing, on both games: not weapon hits, left as they were). The plugin with the port's built-in one on the same machine: "plugin lagcomp.nro (Lag Compensation) not started". Not tested: suyu-style rooms, 3-4 players, two PCs.

Two-button inputs and the frame rate (2026-10-28): fixed. Reported: the Hunting Horn's X+A (and the Lance's R+X+A)
need both buttons almost together at high frame rates. The player's input update (0x47ca28, every weapon; called
from the player update at 0x4a7dec) holds a new attack-button press (the key config's mask from 0x85f93c, | 0x1b0)
to see whether another joins it: bit 0 of the player's input bits +0x1444 and a countdown +0x1448 = 2.0
(0x47d558), less 1.0 each update (0x47ca84 `vmov.f32 s2, #-1.0`, 0x47ca90 `vadd`); at 0 the press counts alone.
Measured (MHGU_LOG_MOVES, quest 101 with the user's HH, X then A d frames later): at 30 fps X+A (0010:006) for
d <= 2, X alone (0010:000) 2 frames after the press otherwise; at 120 fps the same 2 frames (17 ms). The command
tables (rPlBaseCmd: act_st / act_no / act_param, cmd_type, cmd_param0..3; cmd_type 8 = key param0 just pressed)
read logical keys the weapon's key function (0x1360058 and its siblings, one per weapon) sets from +0x1444: held
+0x1414, pressed +0x1424 (0x485e2c / 0x485e78 test, 0x485de4 / 0x485e54 set). Fix (runtime/hle/combowin.c, tools/gen.py
PATCHES): the constant is -step / 2 updates (at most 1). Checked: at 120 fps X+A for d <= 8 and X alone 8 frames
(67 ms) after the press; 30 fps unchanged. A lone attack button is read 67 ms after the press at any frame rate,
as on the Switch (it was 17 ms at 120 fps).

Three-button inputs at high frame rates (2026-11-08): fixed in Lenient. Reported: R+X+A (Lance charge, Wyvern's Fire)
inconsistent, by a player with the Better Inputs plugin; SDL's side was clean. The window in 0x47ca28 ends on the second
attack-button press and resolves saved | new at once (0x47cb44), so the third button had to come in the same update,
7 ms wide at 150 fps. Lenient's longer window made R pressed just before X and A resolve as R+X (flags +0x1444: 0x400
R+X+A, 0x40 X+A, R held at that update is R+X+A too, 0x80 R+X). Better Inputs (no source; hooks the pad update 0x5de064)
ORs held & mask into the pad's new-press word every update for its hold-to-repeat, so a window closed after one
update and R held earlier + X was R+X at once. Fix (runtime/hle/combowin.c, tools/gen.py PATCHES at 0x47ca38 and
0x47cc58, local player, step < 2.0, Lenient only): that code decides on a corrected word: R / ZR new only on a real
press (word & ~last held), a running window sees real presses only, and a press making two of R, X, A with the third
not held waits for it up to 2.0 of the step with the countdown stopped; the word is put back for the rest of the
function. Measured (scripted R/X/A, MHGU_PLSNAP, player flags, not on a physical controller): 8 timings at 150 fps, 5
failed without mods before, 6 with the plugin, none now in either; 240 fps with the plugin none. Plain R+X, R+A, X+A
come up to 33 ms later (X+A pressed together 0 -> 33 ms); a lone press is unchanged (53 ms for a tap); Strict and 30 fps
are as before. The plugin's held X fired ~40 times in 0.6 s at 150 fps, now 7-8 (one per 67 ms window, as at 30 fps).
Follow-up (2026-11-09), reported with the plugin at 60 fps: R held, X+A pressed together gave a guard poke. Measured on
a Lance (every weapon of a save copy changed to one; act 0010:010 from the guard is the poke): when A goes up a moment
before X the plugin goes on repeating X alone, which opens a window, expires as an X tap (flags bit 1) and, R held, is
the poke (the Lance's key function 0x137731c). With the plugin 6 of 6, without 0 of 6. Now a button left over from an
input of two or more doesn't repeat until it goes up: 0 of 6. Not fixed, the original game's: with R held, A a whole
update before X sets X's tap bit with X+A and pokes, with or without the plugin. That save copy's Lance starts no charge
from R+X+A or guard + X+A even without mods (its style not checked), so the charge itself wasn't seen.

Mashing out of a stun and the frame rate (2026-10-30): fixed. Reported: at high frame rates mashing buttons and
turning the stick ends a stun far sooner than at 30 fps. The stun (dizzy) is act 0x40:026 (update 0x4bcfd0, motion
0x1a; the knockback before it is 1:085 / 1:087, not part of it): up to 4 rounds of 750 (60 fps frames, counted down
by the step, so it lasts up to ~50 s untouched); every update 0x47f590 says the player mashed adds 1 to the round's
count (byte 6 of player +4; rounds left: byte 7), and 13 (fewer in later rounds) end the round. 0x47f590 is 1 when
the input state (player +0x13fc: buttons in the low half, the left stick's direction bits 16-19; +0x1400 the last
update's) gained a button of 0x5f0 or a stick direction (+0x13f8 / +0x1406 = state & ~last), local player only
(+0x13cc bit 0): at most once per update, so 30 a second on the Switch, where a quick press or stick turn between
two updates isn't seen. 13 callers share it (other holds mashed out of: pins, snowman, paralysis, as the user
describes them; only the stun checked). Found from the user's play (MHGU_PLSNAP: the player's memory every update,
the act change at their two stuns; mashing visible as +0x13f8 / +0x1406 bursts). Fix (runtime/hle/mashrate.c, a
hook of 0x47f590): below 2.0 of the player's step it looks at the input state once per 30 fps update (2.0 of the
step) against its copy from the last look, as the 30 fps game does; nothing counts in between. Measured (forced
stun, quest 101, mashing from the control file, time from the stun to the last round): input in whole 33 ms steps
(A held 33 ms every 66 ms, the stick turned every 66 ms) 1.74 s at 30 fps, 1.66 s at 120 fps with the fix, 1.47 s
without; faster input (stick every 17 ms) 1.5 s at 30 fps, 0.83 s at 120 without the fix. The first try (count at
most once per 30 fps update, a mash in between kept for later) still ended them as fast as without it; the second
(any new press within the 30 fps update counts) was in between. MHGU_NO_MASHRATE=1 turns it off. Debug aids added:
MHGU_LOG_MOVES also logs every act change ("is", with the time) and the stun's rounds; the control file's
"plact <act_st hex> <act_no> [param]" / "plsweep" start player actions; MHGU_PLSNAP=<file> + "plsnap [updates]"
(also from a knockback) save the player's memory every update; "interpread" now also sees register-offset loads and
VLDR (interp.c). Not tested yet: by the user at a high frame rate; the other holds.

The frame-rate fixes for emulators, as a Forge plugin (2026-11-11, branch feat/highfps-plugin-skip): emjump.c, emstall.c,
hatestep.c, combowin.c (Lenient), mashrate.c and buffcycle.c ported to "High Frame Rate Fixes" (highfps.nro, kept outside this
repo in C:\MHGURecompile\highfps-forge with its NOTES.md), for emulator players on a 60 / 240 fps mod or cheat. The PATCHES sites
become Forge hooks inside their functions: each site's two words jump to a stub that saves every register, runs the C, runs the
second word (or emulates it when it reads pc or branches) and goes on. forge.c doesn't start a plugin of that name (both would
scale the same counters twice); MHGU_FORGE_HFR=1 starts it anyway, for tests with MHGU_NO_EMJUMP=1 MHGU_NO_EMSTALL=1
MHGU_NO_HATESTEP=1 MHGU_NO_MASHRATE=1 (its hooks then take the patched sites over, their functions interpreted). Checked here,
quest 404 with MHGU_SUMMON, Volvidon's 7:92 / 7:98 forced, MHGU_EMTRACE=2: at 240 fps with the plugin the body press is in the air
1.06-2.18 s, apex ~900 at 1.67 s, the drop hop 0.03-0.90 s, apex 532 at 0.50 s; at 30 fps 1.03-2.10 s / 1.63 s and 0.03-0.87 s /
0.50 s; at 240 fps with nothing 1.14 s to the apex and the hop 0.03-0.11 s. Ryujinx 1.2.82 at 240 fps: see the plugin's notes.

## Fidelity audit (2026-10-20)

Silent-bug sweep after the shimmer and shadow fixes (the two classes found: a driver needing explicit barriers, and a
translator ignoring condition codes). Diagnostics now built in: MHGU_NVN_NOOP_LOG=1 logs the first call of every NVN
command the port ignores; the translator warns when a branch tests zero / sign flags last written by a .CC
instruction whose flags it doesn't model ("[shader] ... condition-code test"); MHGU_VK_STATS=1 counts skipped draws.
Village run + the user's hunt logs: the game calls only nvnCommandBufferAddControlMemory and SetShaderScratchMemory
(both harmless); no CC warnings, translation failures or unsupported formats. Audio effects are now complete for
MHGU: I3DL2 reverb (type 5; mix 1 chains three mono I3DL2 reverbs with buffer mixers, the environmental reverb) is a
port of Ryujinx's Reverb3d, with yuzu's max + 1 delay-line ring (Ryujinx's re-reads a stale sample every 400 ms); Aux
(type 2, 6 channels on the final mix) sends each frame into the game's guest ring and plays its return, as Ryujinx's
AuxiliaryBuffer: the game keeps up in lockstep (MHGU_AUDIO_LOG=1 logs the ring offsets; MHGU_NO_AUX=1 bypasses it).
Splitter updates skipped the 12 unused bytes after each splitter's destination ids, so everything after the first
splitter in an update was dropped: stereo sounds made of two mono voices (menu confirm, load fanfare) played left only.
docs/SWITCH_COMPARE.md lists what to check against the Switch version by ear.
Draws skipped while their shaders / pipeline build (the main remaining cause of transient glitches: a flashing status
bar, missing lens-flare pieces on entering an area). MHGU_VK_STATS=1 now also logs a "2s builds" line (skips by
cause and in how many frames, the waits, build times per stage, request -> ready latency, the slowest frame). Entering
the village needed 112 new programs and ~140 pipelines at once: translation (one thread, the translator isn't
re-entrant, ~2.3 ms each) + GLSL -> SPIR-V / modules (~3.6 ms, three workers) dominate, pipelines take ~0.2 ms (Vulkan
pipeline cache), so ~1100-1230 draws were skipped over 13 frames. Now (exec.c):
- a draw whose program / pipeline is still building waits for it, up to MHGU_PIPE_WAIT_MS (default 6) per frame in
  all, and its job moves to the front of its queue;
- cache/programs.bin keeps every translated program (GLSL + reflection, keyed by a hash of the guest code the
  translator reads + the shader keys; tied to the translator: the Makefile's SHADER_ID, a hash of
  runtime/nvn/maxwell/translate.c + shader.h, and exec.c's CACHE_FORMAT, so updates that leave the translator alone
  keep it, as Ryujinx's cache does; until 2026-10-28 any rebuild started it afresh), and
  cache/pipelines.bin each pipeline's state (program by content key, render pass by formats). The next run builds them
  all on the workers at its first draw (~130 programs + ~170 pipelines: well under a second, during the logos), like
  Ryujinx's shader cache. Both are appended as they grow, so a killed run keeps them. MHGU_NO_PROGRAM_CACHE=1: off.
Village load on the R9 (warm caches): 0 skipped draws on entering (was 1064 / 1230), 6 in a whole 60 s run (the first
logo frames), slowest frame 56-62 ms (was 83, the load hitch itself), steady 57 fps unchanged. First run ever (empty
caches): 761 skipped over 9 frames (was 1230 over 13): translation throughput bound, waits cap at 6 ms a frame.
Known gaps that remain:
- A program never seen before (first run, or after the translator changed) can still be missing for a few frames when many arrive
  at once (fewer since the start-up prewarm: next section).
- R9 200 approximations: no custom border colours (nearest standard colour), D24S8 stored as D32F_S8 (polygon-offset
  units differ for decals).

## Fixed (2026-10-28): black quest-end photo; shader prewarm at start-up

The Quest Rewards / Reward Box screen shows a photo of the moment the quest was cleared. A player saw it fully black
on a first run, with the user's screenshot also showing junk blocks. How the game does it: sScreenShot (cSystem,
setup 0xa6f854 at quest start) makes its buffers (nScreenShot::Buffer, 0x2c bytes; Buffer::create 0xe48814: an
rTexture of the 3D size / 1, 2 or 4); at the clear, uFestaScreenShot (0x7628d8) calls the request 0xa6f97c, and the
unit's draw copies the scene once into the buffer: one draw, never repeated. The reward screen draws the buffer each
frame (pass vs 77e9f300 fs 79c6ef00). Evidence (R9, Harvest Tour: Jurassic Frontier, quest 11119, finished by
delivering the Paw Pass Ticket from the camp's supply box): with empty caches the capture draw (vs 78515c00 fs 7a2ac600,
into a 960x540 RGBA8 target) was skipped two frames after the delivery, its program needed 9 ms and the per-frame
wait budget is 6 ms; the buffer was never drawn, and a texture never drawn is read from its guest memory (zeros or
whatever the pool held before: black, or junk). With that program and its pipeline in cache/ (the next run) the photo
was right.

Fix: prewarm every program at start-up (exec.c "prewarm", backend_program_created). The game makes all its programs
before its first frame (nvnProgramSetShaders: ~6300 vertex / fragment pairs, 5589 distinct; the shader code is in GPU
memory by then, so nothing is read from AppShaderPackage.mfx). Each one not in cache/programs.bin is translated with
the keys most draws use (float vertex inputs and colour targets, no alpha test, the game's window origin / depth mode)
on the translate thread and its SPIR-V compiled into cache/spirv on the workers, all behind any build a draw asked for
(low-priority job lists; a draw waiting for one promotes it), recorded in programs.bin (the sources in programs.src)
and left dormant (state 3): the first draw that needs one loads its sources back and makes its modules from the
SPIR-V cache in ~1-3 ms. At start-up only the programs earlier runs drew (those with pipelines in pipelines.bin) are
built; the rest stay dormant. Draws never wait past the 6 ms per-frame budget (942d7ee's 2 s wait for a target's first
draw is gone): a program the prewarm has not reached yet is skipped as before. Measured on the R9 (960x540 window, hidden):
- Cold (empty cache/): the prewarm takes 16-18 s from the first program (5581 translated, 730 duplicates, 0 failed),
  done ~29 s after launch, about when the opening movie starts (the health notice is up from ~18 s). Opening movie at
  27.9 s vs 26.4 s without the prewarm; 48-58 fps while it runs (the no-prewarm start ran 36-46 fps over the same
  stretch: this machine's fps is noisy), slowest frames 135 / 124 / 91 ms in the first seconds.
- Warm: programs.bin (the index, 20 MB) read in 42-47 ms at the first frame (with the sources in the same file it took
  650-1140 ms when the OS file cache was cold: hence programs.src), the prewarm's check of all 6311 programs 0.8 s in
  the background, 5-6 skipped draws in the first frames; opening movie 26.0 s vs 26.3 s without the prewarm (this
  machine varies 22-28 s between runs).
- Disk: programs.bin 20 MB, programs.src 164 MB (GLSL), cache/spirv 157 MB (2388 shaders). Memory: +28 MB working
  set (609 vs 581 MB). Building the modules of every program at start-up instead was measured and rejected: 2.0 GB
  working set.
- Photo on a cold cache: the capture program came from the prewarm (dormant), ready 1 ms after the draw asked, 0
  skipped draws at the clear, photo right.
- Skipped draws over the whole test route (boot, Pub, quest in Jurassic Frontier, reward) on a cold cache: 379-385 in
  21 frames (was 476 in 36). What remains: the first frames of the boot while the prewarm runs; area loads, where ~70
  dormant programs and ~100 pipelines are needed in the same frame (1-4 frames of skips, need -> ready 1-4 ms average
  instead of 35-200 ms); variants with other keys (integer vertex inputs: skinned models; alpha-tested materials, ~15%
  of the programs draws use) are translated on first use as before; new pipelines on a cold driver cache.
Not covered: draws of the scene itself skipped in the very frame the photo is taken stay missing from it (a "half
black" photo may be that; not reproduced). Debug aids: MHGU_SKIP_LOG=1 (each skipped draw with its shaders and colour
target), the ini's [Performance] ShaderPrewarm = Off (default On; a restart setting, in the F1 menu's Graphics & Audio
page) or MHGU_NO_PREWARM=1, the prewarm's progress in MHGU_VK_STATS's 2 s builds line ("prewarm N new, N cached, N
queued") and a "[shader] prewarm:" line when it is done. MHGU_QUICKHUNT from the airship (an HR save in the Hub)
crashes (null function in the town's depart path), so the test route walks: scratchpad scripts hstart.ps1 (scratch
MHGU_HOME / save), to_pub_quest.ps1, to_depart.ps1, to_box.ps1.

Follow-up (2026-10-29): a Steam Deck player (0.10.8, warm program cache but only 14 pipelines in pipelines.bin) saw
the photo garbled, often: stripes of other textures (wood, clouds, ground) behind an intact reward UI. Same cause, a
skipped capture draw; RADV hands the never-drawn buffer recycled memory where the R9 gives zeros. The prewarm makes
programs, not every pipeline, and a dormant program still needs 1-3 ms to load: the 6 ms budget can be gone by the
capture in a busy clear frame. Reproduced here with MHGU_PIPE_WAIT_MS=0 and no pipelines.bin / vk_pipelines.bin: the
capture (vs 78515c00 fs 7a2ac600, 960x540) skipped for its program, photo black. Fix: tools/gen.py hooks the request
(0xa6f9ac, the `mov r1, #1` stored to sScreenShot+0x2c) to backend_photo_requested (exec.c); for PHOTO_FRAMES (8)
frames after it every draw waits for its build up to PHOTO_WAIT_NS (2 s) instead of being skipped, so the capture and
the scene it copies are complete (also covers the "half black" case above). Same test with the fix: one "[vk] quest
photo requested" line, 2 waits (2 ms) at the clear, 0 skips, photo right. The reward screen's own draw of the buffer
still skips its first frame (redrawn every frame: unseen).

Shipped pipeline list (2026-10-29). Surfaces black for a moment on entering an area the first time, with the prewarm
done: not programs missing but pipelines (a program with the draw's blend / depth / vertex layout / target formats:
Vulkan 1.2 bakes all of it in; NVN has it as state) and dormant programs loading, past the 6 ms budget. The game
never lists its combinations, so they are recorded: extras/pipelines.list (make copies it beside the executable,
dist ships it) holds the pipelines recorded while playing the common areas (first: the user's town and three hunts,
904). A record names its program by the game's shader code hashes (code_hash) and shader keys, not by a translated
program, so it outlives translator changes (unlike pipelines.bin, tied to SHADER_ID) and other GPUs: DEPTH24_STENCIL8
and vertex formats are made again for the GPU at load (D32S8 on AMD; widened vertex formats). Records whose program is
in programs.bin are attached at start-up like pipelines.bin's; the others when the prewarm meets their shader code
(plist_seen on the translate thread, plist_drain on the render thread makes the variant and its pipelines). The
header checks sizeof ShaderKey / PipeKey / ListRec: a change there needs a new recording. Matches only the settings
it was recorded with for MSAA (Off) and anything else in PipeKey. Measured (R9, empty cache\, quick start into quest
101 with the user's save, skipped draws over the same 40 s): 1398 without, 163 with (the quest area's load 1225 -> 51;
what is left is the town's first frames while the prewarm still runs); the next start 6. Recording more:
MHGU_PIPELIST_EXPORT=<file> writes pipelines.bin's records plus the loaded list's at the first draw, then copy it
over extras/pipelines.list (MHGU_PIPELIST=<file>: read another list; MHGU_NO_PIPELIST=1: none).

## Updater (2026-10-28)

`mhgurecomp-updater(.exe)` (updater/, built by `make` beside the game) is a separate program that is started instead
of the game. It installs GitHub's latest release over its own folder when it is newer, then starts the game. The game
itself has no networking for this and never changes: `mhgurecomp` always just starts the game.
- Flow (updater/updater.c):
  - It reads `[Application] Updates` from mhgurecomp.ini. `Ask` (the default) or `Auto` checks for an update, `Off`
    goes straight to the game. The setting is a g_settings row and is in the settings menu; the game ignores it.
  - It asks for `GET /repos/morerokk/MHGURecomp/releases/latest`, which never returns drafts or pre-releases (the
    `draft` / `prerelease` fields are checked as well), with a 5 s timeout and the last ETag (`update/latest.etag`,
    `latest.json`: a 304 reuses the saved JSON).
  - It compares the tag numerically with its own MHGU_VERSION and only installs a strictly newer one.
  - It picks the asset by name prefix (`Windows-`, `Linux-` / `ArchLinux-`, the name up to 0.11.4; `.tar.gz` before `.zip`), downloads it to
    `update/<asset>.part` and checks the size and the `sha256:` digest GitHub keeps per asset. An asset without a
    digest is not installed.
  - It extracts to `update/new/`, dropping the archive's single top folder. Unsafe paths (`..`, absolute, `:`) are
    refused, and the player's own files are never written (`data mods cheats bonus cache shots save update
    mhgurecomp.ini log.txt`).
  - It moves each file it replaces to `update/backup/` and renames the new one in. On a failure everything is put
    back. update/backup and update/new are removed at the next start; Windows can't delete the running updater's own
    exe and SDL3.dll, but it can rename them, which is how the updater replaces itself.
  - Before installing it refuses if the game is running from that folder (Windows: the exe or game DLL can't be
    opened for writing; Linux: /proc/*/exe).
  - On Linux it sets 0755 on the programs and `.so` files, taken from the tar's modes or by name, since a zip made on
    Windows has none.
  - It starts the game with the arguments it was given, minus its own (`--update-force`, `--update-no-launch`).
    Windows: CreateProcess with CREATE_NO_WINDOW, so the game logs to log.txt as it does from Explorer, then waits for
    it and returns its exit code, so Steam sees the game run. Linux: execv, the same process.
  - No connection, GitHub's rate limit (403/429; 60 an hour unauthenticated, and a 304 still counts), no asset or
    digest, or "Not now": it starts the game without a word. A failed download or install shows the reason, then
    starts the game after 10 s.
- Version: the Makefile's `VERSION ?= git describe --tags` goes into the updater and the game's log ("MHGU Recomp
  <version>", runtime/main.c). Only an exact tag (`0.10.4`) updates itself: a build between tags or `unknown` is left
  alone unless `--update-force` is given. `make dist VERSION=x.y.z` packs the release (tools/dist.py): a .zip for
  Windows, a .tar.gz for Linux (modes kept). It refuses a VERSION that isn't x.y.z and an updater built with another
  version.
- HTTPS: WinHTTP on Windows; on Linux the system's libcurl loaded with dlopen (libcurl.so.4 /
  libcurl-gnutls.so.4), retried with the usual CA bundle paths when a runtime's libcurl can't find its own. Archives:
  zlib (static on Windows, libz.so.1 on Linux). On Linux SDL3 is linked in (the Makefile's SDL3), so the updater
  needs glibc 2.38 at most, checked like the game (GLIBC_CHECK). Window: SDL3 with SDL_RenderDebugText, shown only when there is something to say (after 0.7 s of
  checking, or a question); keyboard, mouse and controller (South: choose, East / Back: not now). Without a display it
  installs in Auto mode and doesn't ask in Ask mode.
- Tested 2026-10-28 on throwaway copies:
  - A 0.9.0 updater installed GitHub's latest release on Windows (zip) and on Linux in WSL (zip on ext4: the
    programs came out 0755). The installed files were byte-identical to the release, and the player's files were
    unchanged.
  - A local fake GitHub served a `make dist` 0.99.0 release (Windows zip, Linux tar.gz). The 0.9.0 updater replaced
    itself, then reported "up to date" on the next run and removed the backup.
  - Correctly refused or skipped: wrong digest, no digest, draft, 403, closed port, game running, newer than GitHub,
    development build. When 0.10.3 was turned into a pre-release mid-test, the updater took 0.10.2.
  - Arguments with spaces, quotes, trailing backslashes and empty strings reach the game unchanged, and its exit
    code comes back. A second check got a 304 from GitHub.
- Not covered: a release that drops a file leaves the old copy behind, and a new `bonus/system` is never installed,
  since bonus/ belongs to the player.

## Fixed (2026-10-28): Linux sleeps were busy loops

Reported (Fedora, Intel N100, 4 cores): all four cores saturated, 40-50% of it kernel time, not smooth at any render
size. plat_sleep_until_ns (runtime/platform/linux.c) gave clock_nanosleep(TIMER_ABSTIME) the time left as if it were
the absolute deadline: long past, so it returned at once and every sleep spun on syscalls until its deadline. Every
sleeping thread did this: the 60 Hz vblank timer (hle/vi.c), svcSleepThread (every game thread that sleeps), Local
Play. Fix: sleep until 200 us before the deadline, then yield as designed. Measured (WSL, 200 sleeps of 5 ms): before
60% of a core (0.5 s sys a second), after 2%, still on time (1 us late on average, 42 us at worst). Windows was not
affected (its own sleep). Since the Linux port began; a 4-core machine shows it the most.

## Fixed (2026-10-30): the Linux release needed the system's SDL3 and shaderc

Reported (Linux Mint 22.3): `./mhgurecomp: error while loading shared libraries: libSDL3.so.0`, before log.txt. The
Linux build linked libSDL3.so.0 and libshaderc_shared.so.1 from the system; Ubuntu 24.04 (Mint 22's base) has no
SDL3 package at all, and shaderc (`libshaderc1`) isn't installed by default. Arch's own SDL3 could not be shipped
instead: it needs glibc 2.43 (sqrtf, acosf, asinf, atan2f, log10f).
- The Makefile now builds SDL 3.4.18 and shaderc 2026.4 (glslang 16.6.0, SPIRV-Tools / SPIRV-Headers 1.4.363.0: the
  versions MSYS2 has for the Windows build) from their release sources like FFmpeg (third_party/sdl3, third_party/
  shaderc, checked against their SHA-256; cmake, into obj/) and links them in statically: the game and the updater.
  SDL still loads X11, Wayland, libdecor, PipeWire / PulseAudio / ALSA, udev and D-Bus from the system when it runs;
  the build stops when SDL's configure didn't find one of those (SDL3_NEED). `SDL3=system` / `SHADERC=system` link
  the system's instead. Windows is unchanged (MSYS2's DLLs).
- The glibc wrappers moved to runtime/platform/linux_glibc.c (also linked into the updater), with asinf and log10f
  added; GLIBC_MAX went from 2.41 to 2.39 (Ubuntu 24.04), and the check now also holds libstdc++ to GLIBCXX_3.4.32
  (GCC 13; shaderc needs that one). `-Wl,--exclude-libs,ALL`: the executable exports none of the static libraries'
  symbols (SDL, glslang, FFmpeg), so a Vulkan layer with its own glslang or SDL doesn't bind to ours (see the ImGui
  note on IMGUIFLAGS).
- The newer SDL wins (runtime/platform/linux_sdl.c, the game and the updater): a constructor, before anything uses
  SDL, opens the system's libSDL3.so.0, and when its SDL_GetVersion is ours or newer sets SDL3_DYNAMIC_API, so the
  built-in SDL hands every call to it: Arch keeps Arch's SDL (controllers newer than ours) as before. No system SDL3
  or an older one: ours. MHGU_SDL=bundled keeps ours; a player's own SDL3_DYNAMIC_API is left alone. Logged as
  `[ui] SDL 3.4.18, the system's (/usr/lib/libSDL3.so.0; built in: 3.4.18); video x11`. Checked in WSL: Arch maps
  /usr/lib/libSDL3.so.0 (with MHGU_SDL=bundled it doesn't), Ubuntu 24.04 runs the built-in one.
- The game now needs from the system: libc, libm, libstdc++, libgcc_s and libvulkan.so.1; the updater libc, libm and
  libz (and libcurl, opened at run time). Both at most glibc 2.38. New licenses: licenses/SDL3.txt, shaderc.txt.
- Tested in WSL: Arch (the game runs to the title, its shaders compiled by the bundled shaderc, 0 failed; the settings
  tests pass) and an Ubuntu 24.04.5 root file system with Ubuntu's own Mesa, where 0.11.3 stops with that same error.
  Not tested on a real Mint desktop or with a real GPU on Linux.

## Keybinds (2026-10-30)

The keyboard and mouse controls were fixed in runtime/host_input.c. Now each is a setting of the ini's `[Keybinds]`
(MoveUp/Down/Left/Right, Walk, A..ZR, Plus, Minus, DpadUp..Right, LeftStickClick, RightStickClick; config.h BIND_*),
up to two keys or mouse buttons each: `Plus = Return, Keypad Enter`, `X = Mouse Left`, `None`. The defaults are the old
fixed keys. SDL's key names, but the file's own for the keys whose name has a ',' (the separator) or ';' / '#' (a
comment): Comma, Keypad Comma, Semicolon, Keypad Hash; Mouse Left / Right / Middle / 4 / 5 (KEY_MOUSE + SDL_BUTTON_*).
The recomp's own keys (keymap.h: Escape, Insert, F1, F7..F12) are refused, in the file and in the menu. Live: a save
applies them at once (config_live_bind). An older ini gets the section added with the defaults (as other sections).
- Settings (F1), Controls, Keybinds: a submenu with a row per keybind; Confirm: Set key / Add a second key / None, then
  a key, or a mouse button clicked away from the menu's rows (ImGui counts the controller-focused row as hovered, so
  this asks ImGuiHoveredFlags_NoNavOverride). A key that is also another keybind's, the chat key or the recomp's shows
  red with what else uses it. The Chat key row moved there (still `[Controls] ChatKey`); Reset this tab and the
  submenu's Reset keybinds reset both.
- Any mouse button captures the mouse now (only left / right did); the capturing click is still not a button press.
- Tests: test_settings (names, aliases, two keys, refused keys, save and reload, live values), test_settings_panel
  (a key and a mouse button chosen for B, F12 refused, saved, reset). Not tried in the game by hand: the game started
  with an older ini, which got the section.

## exefs code mods: subsdk modules and code patches (2026-10-30)

Asked for the MH4U Port (github.com/Scrimas/MH4U-port-to-MHGU, core 1.7.1: exefs/subsdk1 and an IPS32 of main, 209
records: 154 hook jumps `add pc, pc, #x << 18`, 16 pc-relative literals into subsdk1, 39 immediates). Before, the
loader ran main and sdk only and code patches were skipped (logged as not applied).
- Code patches of main and sdk (runtime/mods.c): kept at load, written by mods_patch_code once the dispatch tables are
  set up (boot, before Forge); every function they touch runs in the interpreter from then on (dispatch_interpret, as
  cheats' code changes). Data patches as before. MH4U Port: 170 functions interpreted.
- Mods' subsdk0..9 (runtime/loader.c): on the console and in emulators the modules sit one after another (main, the
  subsdks, sdk; Ryujinx: main 0x704000, subsdk0, subsdk1 at 0x2E19000). MH4U Port's subsdk1 finds main as its own base
  minus MAIN_GAP = size(main) + size(subsdk0) = 0x2715000, and its hooks jump there: here 0x2915000, inside sdk
  (0x2400000-0x2D41000). So a subsdk goes where expected when that is free, else in the room between sdk and
  HLE_BASE at a multiple of 256 KiB from it (0x2D55000: `add pc` offsets are multiples of that), with Module.expected:
  its R_ARM_RELATIVE words outside its own image get the expected base (main's addresses), and mods_patch_code moves
  the patches' B / BL, `add` / `sub pc, pc, #imm` and pc-relative offsets (within 4 KiB) into it by the difference
  (loader_moved; MH4U Port: 169). Its code is interpreted; its DT_INIT runs after main's (rtld_init_main). The
  game's own subsdk0 (movies) still isn't loaded, but takes its room in the layout.
- Interpreter: integer VPMAX / VPMIN (also in tools/neon.py), the only instruction of subsdk1's code it lacked
  (checked: every word of its text through tools/lifter.py).
- Checked (hidden window, a test save): the mod's module_init finds main ("main 200000: ok"), its tables, gear, text
  and quest lists load; GU quest 101 departs and plays with it. Its own Tigerstripe Zamtrios quest (11493), by hand
  (the user, a progressed save): listed at the Hub counter, departs, the monster fights. (MHGU_QUICKHUNT can't depart
  a Hub quest from the Village: a plain GU Hub quest stops the same way with no mods.) Not measured: the frame rate
  cost of the interpreted functions in a hunt.
- Forge's own module (2026-10-30, a 0.11.6 regression): mods with Forge plugins bring Forge's loader as
  exefs/subsdk9 (Forge itself, and e.g. a Sharpness Bar mod that bundles it with its plugin). 0.11.6 loaded it as a
  code module: "no room for exefs/subsdk9 (0x1a6000 bytes)" and FATAL at the start. Now a mod's subsdk whose module
  name (start of rodata: u32 0, u32 length, the name) is "mhguForge" is passed over with a log line, as before:
  the port runs the plugins itself (runtime/forge.c). Checked (hidden window): MH4U Port + Forge + Sharpness Bar +
  Key Quest Markers start, both Forge subsdk9s passed over, the sharpness bar on the HUD in quest 101. Key Quest
  Markers then reports "MHGU 1.4.0 code mismatch at a required function" and stays off: MH4U Port's IPS patches the
  same two instructions it hooks (main +0x3b2174 and +0xa4faf0), a conflict between the two mods on the console as
  well (before 0.11.6 the port skipped MH4U Port's code patches, so they didn't meet). Without MH4U Port it loads.
- Its cost (2026-10-31, a report: much slower from 0.11.3 to 0.11.7 on a laptop, GeForce 920MX, with MH4U Port and
  7 Forge plugins; the lag gone while talking to an NPC or in the item box). MHGU_INTERP_STATS=1 (interp.c: every 5 s
  the interpreted instructions a second, and per function a run started in, callees included, with the calls) on the
  Ryzen 7 9800X3D, MH4U Port only: town 3.7 M instructions/s, 26 ms/s in the interpreter (60 fps), all of it in one
  function: main 0x2e0da0, the game's "has skill" bit test (14 instructions), called 87 times a frame in town and
  142 in quest 101 (6.1 M instructions/s). MH4U Port hooks its entry (gear_has_skill_c, module/gear.c: Enlightened
  Blade answering for the GU skills it grants) and that looks up every ported monster's SKIL section on each call
  (port_section: a scan of the data file's section table, 7 monsters): ~715 instructions a call, almost always "no".
  Before 0.11.6 the hook didn't run (and the mod's monsters didn't work). Port side: interp_owns, asked after every
  interpreted instruction, scanned all ~180 interpreted ranges (MH4U Port's 170 functions and its subsdk1, the
  plugins): it now tries the last hit's range first, 26 -> 22 ms/s. The rest is the mod's: keeping the 7 SKIL
  pointers after the first lookup (the data never changes once loaded) would cut the hook to a few dozen
  instructions. A laptop dual-core is perhaps 2-3x slower a thread: ~1 ms a frame in town, more in quests, on the
  game thread.

## Loading screens (2026-10-31)

Noticed: loading screens take about as long on this PC (Ryzen 7 9800X3D) as on the oldest one (the minimum spec), and
longer with MH4U Port. Measured on quest 101 (Village, no large monster; MHGU_QUICKHUNT), seconds after Depart on
Quest, from screenshots every 0.1 s, the logged file reads and a sampling profiler (below):
- 0 - 0.4: fade to black. 0.4 - 1.9: black, the town area's depart states (aVillage, mode 4, 0x8bd720) waiting for
  the departure's fade object (0x5f85fc) and the music to stop.
- 1.9 - 4.2: the quest's card on the loading screen, and nothing loads: state 9 (0x8bdac0) counts area +0xe4 (150, 60 fps
  frames, less the engine step each update: 2.5 s at any frame rate, on the Switch too) down to 0 before it jumps to
  the quest's area.
- 4.2 - 5.4: the loading itself (62 files). 5.5: the quest fades in.
So 1.2 s of 5.5 is work; the rest is the game's own timing, the same on every PC. (A 2 s wait after the reads seen first
was the measurement's: screenshots every 0.4 s, each a PNG encoded while the game ran.) The CPU is nearly idle outside
the reads.
- Of the loading, the loader thread (main 0xdc74e0) was the work: 80% in zlib's inflate (the archives are zlib streams;
  the game's zlib is 1.2.8, "1.2.8.f-NINTENDO-SDK-v1"), 72% in inflate_fast (0x1422ce8) alone. Now inflate_fast and
  adler32 (0x1422774) are host code (runtime/hle/inflate.c: zlib 1.2.8's on the game's structures, whose inflate_state
  is 8 bytes shorter at the front; modes TYPE 11, BAD 27; no `sane` test, as the game's). The loader thread from start-
  up to a quest: 9.3 -> 5.4 Gcycles (inflate_fast 7.1 -> 3.2, adler32 0.9 -> 0.45); the quest's reads 1.14 -> 0.86 s
  here, more on a slower CPU. MHGU_INFLATE=check runs both on every call and compares (the output, z_stream and state):
  16384 calls and as many adler32s from start-up to the quest, none different. MHGU_INFLATE=game: the game's.
- MH4U Port: its hook quest_group_fix (module/quest.c, at the quest list loader step, the mod's 0x3b7de8 = main
  0x5b7de8 here) runs quest_group_rename on every step: every entry of the quest list (~1500) against every monster's
  12 quest slots, ~1 M instructions a call, in the interpreter (the mod's code). The town's load calls the step ~1000
  times, on a thread of its own (from main 0x5b7cf8): 21 Gcycles, all of it in the interpreter (MHGU_INTERP_STATS:
  up to 127 M instructions/s). The town's load (its first read to the town) took 7.4 s with MH4U Port, 2.5 s without:
  5 s of it the mod's, here; a laptop's CPU several times that. The mod's to change (e.g. its slot IDs' range worked
  out once, and an entry outside it skipped before the loops); the time is in the mod's own code, which only the
  interpreter runs (~20 cycles an instruction: faster would take pre-decoding, not a quick change). Quest 101 itself
  loads as fast with it as without.
- The game's waits, shortened when not in a network session (2026-11-08, runtime/hle/fastload.c; gate: !ldn_net_up(),
  checked with a local hub: the waits stay; MHGU_NO_FASTLOAD=1 for the game's timing). Three, none of them loading:
  state 9's count; the music streams' stop fade, 1500 ms leaving a town (0x6de8f4) and 1000 ms for a zone change
  (0x6de048), both through 0x6e3ecc, now 300 ms; and the counter 0x6dee48 polls on the black screen (sound +0x1c, to
  60 or 90 steps), now 4.5 times as fast. 0x6dee48 still waits until the streams and voices have stopped. Measured at 60
  fps, the fade's start to the arrival: Depart on Quest 5.0 -> 1.8 s, village to village 2.6 -> 1.4, zone change 1.4 ->
  0.7. The count is 150 updates of at least 1 each (the int drops the step's fraction): 2 - 2.5 s up to 60 fps, 1 s at
  150 fps. Title to village: none of these waits from the village area's creation to its start (2.4 s, reading files; the
  character select before that wasn't timed). Not
  changed: returning from a quest (other callers of 0x6dee48: 0x8a12e4, 0x20fcb8, 0x2121c8, not timed).
- Tools: MHGU_SAMPLE=<file> (runtime/sampler.c, Windows): a sampling profiler, every thread's call stack about every
  millisecond with the CPU cycles it used; tools/samples.py reads it (timeline / top / wait, game functions as their
  guest addresses). Sleeping threads are sampled every 16th round, for where they wait.

## Discord Rich Presence (2026-10-31, branch feat/discord-rich-presence)

ini [Discord] RichPresence / ShowHunter (settings menu: Network tab), both live. runtime/net/discord.c talks to the
Discord app over its local RPC (named pipe `\\.\pipe\discord-ipc-N`; on Linux the discord-ipc-N socket in
$XDG_RUNTIME_DIR, Flatpak and Snap paths too) as application 1566091085493571724 ("Monster Hunter GU Recomp", owned by
morerokk): handshake, then SET_ACTIVITY with the latest state at most every 4 s (Discord's rate limit); turning it off
closes the connection, which clears the profile. No Discord: a try every 15 s. runtime/hle/presence.c reads the game
once a second from the input polling (game thread): town / quest, map and zone, quest targets, hunter, party; field
addresses are in its header comment. A town shows "Bherna Village" / "Hub (online)" and "Name, HR 83 - Long Sword";
a quest "Hunting Great Maccao, Yian Kut-Ku, Malfestio" and "Jurassic Frontier, Area 1", the quest's name and the
hunter in the images' hover texts, the time since departing; (2 of 4) in a hub (ldn_party: the hub's
NetworkInfo node count, its session id as the party id) or a multiplayer quest (sQuestSelector join count).
Texts: monster and quest names from the game's English GMDs (romfs_host_path, so mods' copies count); map names and
weapon type names are tables in presence.c (the game draws map names as pictures; stage 15 and town type 5 unknown).
Tested on Windows (2026-10-31, test save, Discord running): town (Wycademy = town type 6), quest 404 (Volvidon, camp
then Area 1 while walking), quest 521 (all large monsters: the large monster list), both settings toggled in the menu.
Not tested yet: online hubs and the party size, Linux, the Hub / Pub / other villages' names in game.
Images are art assets of the Discord application (uploaded in its Developer Portal, used by key): "logo" as
the large image, a pixel-art icon per weapon type as the small one (presence.c g_weapon_icons; a fan-made sprite
sheet, used with permission). Next: map pictures as the large image in quests.

## Mouse look on the camera's angles (2026-10-31)

In a hunt the captured mouse turns the camera itself (runtime/hle/mousecam.c): each count is 0.08 degrees x
[Mouse] MouseSensitivity, at once (no dead zone, no speed curve, no smoothing lag), where the stick emulation it
replaces had a minimum turn speed. The quest camera (uQuestCamera, DTI 0x184d8b8, 0xb00 bytes; code 0x218000-0x22a400)
keeps its angles as 16-bit units: +0x9e8 / +0x9ec the pitch / yaw it heads for, +0x9e0 / +0x9e4 the smoothed ones
(0x225308: stepped toward those by 0x21c3cc), +0x9d8 / +0x9dc the ones the eye is placed by (the smoothed ones, the
pitch then lifted off the ground, 0x223d80). Its right stick handler 0x2255cc (r0 = camera, r1 = invert bits; called
by the normal update 0x224e54 with +0x97c, and at 0x22713c with +0x980) reads the player's camera actions 1-4 (up,
down, left, right: vfunc 0x2e8 of the player at camera +0x85c, bits of player +0x1434) and the stick's tilt (vfunc
0x238), turns by a speed from the camera's parameters at options byte +0x65 (camera speed), and clamps the pitch to
+-0x3f00; later code clamps it again to -0x2f00..0x2800 (down 66, up 56 degrees, measured). The game only calls it
while the player may turn the camera, so it is hooked: after it, the counts moved since the last update are added to
the heading and smoothed angles together. The game's invert option (options byte +0x64: bit 0 up / down, bit 1 left /
right; copied to camera +0x97c by 0x2220f8, and +0x68 to +0x980) is applied from r1. The game's camera speed is not
(MouseSensitivity is). Options object: *0x1a8ca48 (+0x63, 0-4, is copied to camera +0x434 too; not identified).
host_input.c gives the mouse to the camera while the handler ran in the last 200 ms (mousecam_active); otherwise
(villages, whose camera doesn't turn; other cameras; cutscenes) to the right stick as before.
Tested 2026-10-31 in quest 101 with the control file's mousemove: 500 counts = 40 degrees left and right, 20 counts
turn 1.6 degrees, 1 count a second still turns; pitch stops at the game's limits and comes back at once; all four
invert settings; the in-quest start menu (the camera turns there with the stick too). Not tried by hand with a real
mouse, nor with mounting or the second camera type (+0x980).

Aiming (2026-11-08): while aiming (the Bow's R, action 0010:011 and the charging actions) the stick turns the hunter
and the camera follows, so 0x2255cc doesn't run and the mouse fell back to the stick emulation. The aim camera
(0x226e84) takes its yaw from the hunter's +0x14a0 and its pitch from the float at +0x14bc (-100 to 100, spread over
camera parameters 0x1d up and 0x1e down, 56 degrees each), and steps its eye angles +0x9d8 / +0x9dc straight toward
them. 0x4a1738 (r0 = player, r1 = mode: the weapon's kind of aim, 3 for the Bow, r2 = yaw) applies the turn, reached
from the stick reader 0x4a07a8 only while the player may turn, so it is hooked too: the counts go to the yaw, the pitch
(+0x14b8 / +0x14bc) and the eye's angles, with the aim's own invert option (options byte +0x66). It stands aside when
0x2255cc also ran since its last call (camera options that keep the stick on the camera). Tested 2026-11-08 with a Bow
at 30 and 120 fps: 500 counts = 40.1 degrees aiming and charging, as out of aiming; 150 counts up = 12 degrees; the eye
within 3 units of the aim while turning; pitch stops at +-56 degrees. Not tried by hand with a real mouse, nor with
the Bowguns' aim (other modes; mode 1's pitch is +0x2714 instead), nor the aim invert settings.

## Mouse wheel on the item bar (2026-10-31)

The captured mouse's wheel turns the item bar directly (runtime/hle/itembar.c): up the item to the left, down to the
right, one item per notch, without holding L; middle click is a second default key for Y (use the item / sheathe;
existing ini files keep their `Y = R` until changed). The player keeps the selected pouch slot at +0x3298 (u16; 0x28
the empty "(No Item)" place at the bar's left end, else the pouch slot). Found by diffing the player's memory around
L+A / L+Y (control file `memsave`), then the writers of +0x3298 in the lifted code: the item bar handler 0x4f7f38
(r0 = the player, every update from 0x49baf4) checks f_47bcd0 == 1, f_47b918 == 0 and vfunc +0x230(player, 1) == 1,
then, with the bar open (vfunc +0x25c(player, 1); L held) or for the actions 0x43 / 0x44 (vfunc +0x2e8; no L
needed), actions 0xa / 0x44 go right and 9 / 0x43 left: +0x3298 = f_4880fc(player, slot, 0 right / 1 left) (through
0x39bfcc on the pouch: skips empty and unusable slots, stops at the left end) and +0x253c |= 2 (right) / 4 (left).
The handler is hooked; after it a waiting notch does the same past the same checks (one per update, at most 4
waiting; dropped when the player may not pick an item or outside a hunt). Note: vtables are in main's image (below
0x08000000), so a heap-range check on them fails. Tested 2026-10-31 in quest 101 (test save, John Rise) with the
control file's new `wheel <notches>`: 0x28 -> 0 Potion -> 1 Mega Potion -> 2 3 4 -> 7 (5 and 6 empty, skipped) -> 8
-> 9 and back, the HUD's item and count following. Tried by hand with a real mouse by the user: works.

Rebindable since: [Keybinds] ItemLeft / ItemRight (BIND_ITEM_LEFT / RIGHT, defaults Wheel Up / Wheel Down) turn the
bar one item per press of their keys or buttons, or per notch of the wheel. The wheel is a key of its own
(KEY_WHEEL_UP / DOWN = KEY_MOUSE + 0x10 / 0x11, "Wheel Up" / "Wheel Down"), usable on any keybind: on the others a
notch is a 70 ms press. The settings menu takes a turn of the wheel when choosing a key (settings_panel_wheel).
Existing ini files get the two lines when the settings are next saved, and keep their defaults until then. The
default ini text now has `Y = R, Mouse Middle` (the first commit changed only the built-in default). Tested in quest
101: defaults, and ItemLeft = Wheel Down / ItemRight = Wheel Up from the ini, through the control file's `wheel`.
The menu shows the Item bar rows. Not tested: choosing the wheel in the menu (needs a real wheel event), a keyboard
key on ItemLeft / ItemRight, the wheel on a button keybind.

Prowler (2026-11-10): uOtomo has its own bar handler, 0x1417d68 (vtable +0x5c4, called from the player update right
after the hunters' 0x4f7f38, which also runs for a Palico and passes its checks: without a test there the notch only moved
the unused pouch slot +0x3298). Selected slot u16 +0x3336 (0-8, wraps, skips the empty ones: f_1417efc(palico, slot, 0
right / 1 left)), turn bits +0x3338 (2 right, 4 left), select check vfunc +0x230(palico, 0x10), actions 0x47 / 0x48
without L. itembar.c hooks it too; a Palico is told apart by that vtable slot. Tested with the user's Prowler save in
quest 101 (uOtomo found with control `find ec159501`, vtable 0x19515ec; `peek` +0x3334): `wheel` -1 / 1 move the slot one each
way, HUD name and count following, 0 <-> 7 wraps (slot 8 empty in that save), 9 notches at once = 4 (MAX_WAITING). Hunter save (bow)
retested the same way: the bar still turns. Not tested: a Prowler in multiplayer.

## BC textures without GPU support (2026-10-31, branch feat/android-build)

First step of the Android build (docs/research/android.md): Adreno and Mali drivers on Android have no
textureCompressionBC, and the renderer then made an RGBA8 image and uploaded nothing into it (textures.c only decoded
ASTC on the CPU): with BC off, the terrain, models and most of the HUD were black. `MHGU_NO_BC=1` now makes a desktop
GPU report no BC (g_vk.bc; format_supports refuses the BC formats), to test it on PC.
- Which formats: a title -> town -> quest 101 run made 115 BC1 (nvn 0x42), 115 BC3 (0x44), 23 BC4 UNORM (0x49) and
  13 BC5 UNORM (0x4b) textures; no BC2, BC6H, BC7 or ASTC. The village (MHGU_QUICKHUNT=town) asked for nothing else
  (the "not supported: RGBA8 instead" line is now logged once per format, so a missing one shows in the log).
- runtime/nvn/bcn.c decodes BC1-BC5 (UNORM and SNORM) on upload as the ASTC path does: BC1-3 to RGBA8 (sRGB kept),
  BC4 to R8, BC5 to RG8 (TexBackend.bcn). vk_tex_decoded / vk_tex_decode cover both decoders. BC6H / BC7 are not
  decoded (none seen): they would still be the blank RGBA8 image.
- Copies from a buffer into such a texture (exec.c copy_buffer_to_texture) were dropped for ASTC; they now decode
  too, for ASTC and BC.
- Result (quest 101, 1280x720, no MSAA / FXAA): looks the same as the GPU's decode, also zoomed 3x. Pixel
  differences against a native run, ground region: mean 1.2 codes, 26% of pixels more than 2 apart, 0.3% more than 8
  (two native runs: 0.2, 4%, 0.1%). That is rounding: NVIDIA interpolates BC1 / BC4 with its own precision, bcn.c
  with the spec's rounded 8-bit formula. With BC on, the build matches the previous one within run-to-run noise.

## Android build (2026-10-31, branch feat/android-build)

`make PLATFORM=android ABI=x86_64|arm64-v8a` builds an APK (android/android.mk, android/apk.mk: the NDK, the SDK's
CMake and build tools, no Gradle). In the Android 15 x86_64 emulator the game boots, translates its shaders and
quick-hunts into quest 101, drawn as on PC, also with MHGU_NO_BC=1. Build and test instructions, how it is put
together and what is left: docs/research/android.md. Runtime changes for it, all under `__ANDROID__` (or per
architecture) except the shared ones noted: GUEST_BASE 64 GB on Android (cpu.h: the desktop game library's id changes
once with it); libmhgugame.so loaded by name; SDL_main; runtime/platform/android.c (the app's folder, env.txt for the
debug variables, the message box) beside linux.c; linux.c's fault handler reads arm64 registers too, and bionic gets
the unwinder's backtrace; umask 007; the startup messages name the Android folder; screenshots by absolute path.
VulkanMemoryAllocator 3.4.0's header vendored in third_party/vk_mem_alloc (the Windows build keeps MSYS2's). Windows
rebuilt and quick-hunted after it: unchanged.

## Vulkan 1.1 path (2026-11-02, branch feat/vulkan-1.1)

The backend now also runs on Vulkan 1.1 devices, which many Android devices are stuck on: `g_vk.api11` (device below
1.2, or `MHGU_VK11=1`) and `g_vk.fences` (no timeline semaphores). A Vulkan 1.2 device takes neither branch: same features,
timeline semaphore and SPIR-V as before, and its cache/spirv keys are unchanged. On api11: a fence per submission
(exec.c), SPIR-V 1.3 in its own cache keys (shaders.c), no 1.2 feature structures (device.c), no FSR 3.1 (fsr.c).
`MHGU_DATA_DIR=<folder>` puts only the game files elsewhere, e.g. on a USB drive (main.c). Results: R9 270X 53.6 fps
(1.2) and 53.7 fps (1.1, forced) over 14 minutes of quest 101, same picture; Shield TV Pro 2019 (first real device,
Vulkan 1.1.178, 3 GB): 41-45 fps at 1080p, 0 of 5518 programs failed. Details: docs/research/android.md "Vulkan 1.1".

## Android TV and game files on a drive (2026-11-02, branch feat/android-tv)

The app is on an Android TV home screen (LEANBACK_LAUNCHER and a banner; phones unaffected), and `[Android] GameFolder` uses
the game files where they are, for example on a USB drive: Game files folder in the settings' Android tab, or Use where they are
at the first start. Details and what is untested: docs/research/android.md "Android TV and game files on a drive".

## FSR 4 removed (2026-11-01)

`Upscaler = FSR4` is gone: fsr4.c / fsr4.h, third_party/ffx-api, docs/FSR4-PORT.md, the FSR4_DRIVER_PATCH build option
and the settings row. A release could only use it with a loader DLL the player supplied, the maintainer's GPU can't test
it, and bundling AMD's SDK DLLs (PR 168) would add 36 MB (uncompressed) for few players. FSR 3.1 stays. An ini that still
has `Upscaler = ...` loads as before: the line is logged as an unknown setting, ignored and kept. The instance asks for
Vulkan 1.2 in every case now.

## Interpreter: pre-decoded blocks (2026-11-06, branch perf/interp-blocks)

Asked for MH4U Port (reports: slow loading screens, frame drops with a bowgun even in the village, a laggy item box;
slower than on emulators, which JIT the mod's code). The costs are the ones measured above (the "has skill" hook,
quest_group_rename): the mod's own code, which only the interpreter runs. It took ~25 cycles a guest instruction
(4.95 ns here), decoding every instruction each time it ran. Now (runtime/interp.c "pre-decoded blocks") a run
decodes a straight stretch once into ops (up to an instruction that may branch, the end of its interpreted range, or
32): the class function the decode picks, called without decoding again, and fast handlers for the common forms
(data processing with an immediate or LSL'd register, CMP / CMN / TST, ADDS / SUBS, LDR / STR / LDRB / STRB / LDRH /
STRH / LDRSB / LDRSH with an immediate or LSL'd register offset and writeback forms, literal loads, MOVW / MOVT, B /
BL / BX / BLX). Anything else runs interp_exec as before. Blocks are per thread (no locks), direct-mapped by pc in a
2 MiB arena (dropped when full) and link to the last two blocks they went on to. Changed code: each op compares the
word in memory it was decoded from before it runs; fnhook_set / fnhook_keep_entry bump g_code_gen (code_word reads
the hook bits), which drops a thread's blocks at its next block. interpwatch / interpread step one instruction the
old way while on.
- Checked: tools/test_lift.py --interp-ops (new: the ops through interp_exec_op) against Unicorn, 20000 instructions
  of main and of sdk, and 20000 more of the fast-path forms each: none different from --interp and the lifted C (the
  one sdk failure, `and r3, r5, r3` at 0x2451bd4, fails the lifted C and --interp too: the test's). The test harness
  had bit-rotted for --interp (interp.c's newer externs): stubs added.
- Standalone (a scratch harness running the game's own code interpreted): adler32 over 1 MiB 20.4 -> 5.7 ms,
  the SDK's qsort of 20000 ints 203 -> 98 ms (2.5 ns an instruction, branchy code: blocks are ~5 instructions).
- In the game (hidden window, MH4U Port core 1.8.0 + its 4 monster packages from the releases, testsave/save_0,
  MHGU_QUICKHUNT=101, the master build at 6d81cc3 against this): the town's load with the mod 6.2 -> 3.0 s (from
  "tigerstripe_zamtrios installed" to the town, two runs each, within 0.2 s); quest_group_rename's stretch 4.95 ->
  2.3 ns an instruction; in quest 101 the interpreter 160 -> 82 ms a second of play (28 M instructions/s, 99% the
  "has skill" hook at 34000 calls/s, 240 fps). The mod's log the same (710 lines), no faults. Not tried by hand: a
  bowgun, the item box, a laptop CPU, Android / Linux builds (plain C, nothing platform-specific added).
- Still the mod's to fix for most of the rest: gear_has_skill_c rescans every monster's sections per call (~820
  instructions, almost always "no"); keeping the SKIL pointers once loaded cuts it to a few dozen. Further on our side:
  tail-call threaded ops (each handler jumping to the next) might give another ~1.5x; matching an emulator would take a
  JIT (AArch32 -> x86-64 and -> AArch64), a project of its own.

## Even letter spacing in the game's text: [Graphics] FixKerning (2026-11-07)

- The UI text (cGUI, font_festa.gfd) looked unevenly spaced, on the console too. Three causes, all fixed with
  FixKerning (default On, live; runtime/hle/textlayout.c has the details):
  - The 2D canvas is 1280x720 and the game snaps each glyph's x to it after aligning a line (0xc45548:
    floor(x + 0.5) + 0.5). At 1080p a unit is 1.5 px: letters start on whole and half pixels by turns, so the same
    pair ("he" in "sheathe" / "sheathing") is up to 1.5 px further apart in one word. tools/gen.py PATCHES 0xc45554 /
    0xc4555c skip the snap of x (y keeps it).
  - The font's cells hold their letters with uneven blank columns, and its signed x offsets (entry +0x10: -1 on c f m r
    s t, +1 on i l E H M N ( : ') only move the glyph, not the pen: "r elies", "ent er". The glyph placement
    (0xc45e64, hooked) places each Latin letter as if its cell held one blank column either side of its ink.
  - No kerning in the font: pairs whose ink stays 2+ px apart beyond the plain 2 px ("Va", "To", "LT", "r.") get
    closer, at most 3 px; never with a digit.
- Measured from the font the game reads (loc/arc/resident.arc through the RomFS, so a font mod's own): the font file and
  its first glyph page (RGBA8, block linear), at the first text (~15 ms; "[text] ... glyphs measured, N kerning pairs").
  The runtime links zlib for it (Windows static, Linux / Android the system's libz). MHGU_FIX_KERNING=0|1 overrides the
  file. How it was found: MHGU_CONTROL "interpwatch" on a glyph node's x showed the layout's write and the snap's.
- Checked by the user in game (1080p, the style descriptions of the Equipment Box); Linux / Android builds not yet.
  An aside found on the way: a tab whose longest help runs three lines at 640x480 makes End in the settings menu stop
  with the last row partly under the pinned help (test_settings_panel.cpp line 653); FixKerning's help is two lines.
- [Graphics] BoldText (default Off, On on Android for a phone's small screen; live, independent of FixKerning;
  MHGU_BOLD_TEXT=0|1): the glyph quad writers
  (0xc3f8c4, 0xc55524, 0xea757c: obj, list, glyph node) draw the whole cell but take the texture from half a texel
  inside each edge (list +0x38), so every letter is stretched about one font pixel each way: bolder, wider, 4% taller
  ('l' 25% wider, 'e' 8%; measured in the vertex dump: 'o' texels 926.5-938.5 over a 13-texel quad). Off moves the quad
  in by the inset for the write (hooks, node put back after): letters at true size, thinner and crisper. The user's
  side by side (Equipment Box, 1080p): better, but the stretched one reads more easily for some, so it stays an option
  ("Bold text"; its help names dyslexia).

## Next steps
1. Modding tools: decode resident.arc tables (weapon00..14 Base/Level data: record layouts derivable from the game
   code that reads them), monster files per `arc/enemy/emXXX_YY.arc` (`attackdata`, `bodydata`, `dtbase`,
   `dttune`), JSON <-> binary converters, and per-member ARC overrides in the virtual RomFS
   (`mods/<name>/romfs/<arc path>.arc.d/<member>`).
2. Play further (hunts work: Bherna Gal -> quest -> gate left of the balloon) and fix what breaks; shader global
   memory if some effect needs it.
3. A README with build instructions; Linux platform layer (runtime/platform/linux.c). It must also give
   plat_user_dir a home for save data: $XDG_DATA_HOME/MHGURecomp, else ~/.local/share/MHGURecomp (see "Save data").
4. Internet hubs: the hub server and client exist, and the public server runs (see "Internet hubs through a hub
   server"). Left: test across two PCs and real NATs, a hunt, 3-4 players; measure the
   relay's traffic per player; direct UDP by hole punching (relay as fallback); the rest of the security audit
   (vsock.c, emsync.c, hpscale / villagehub aux messages, IPC / fs boundary) before public hubs are advertised:
   docs/research/internet-hubs.md.
5. Android build (arm64, controller only, no touch controls): plan in docs/research/android.md.
6. Draw distance ([Graphics] DrawDistance, 2026-10-28): town NPCs (uLobbyNpc, the 15 people in Bherna) fade in
   within a distance and out beyond it (uLobbyNpc 0x8c2d9c: squared distance to the object at a global +0x54 against
   the table at 0x8c2ef0, 2500^2, or 1800^2 with flag 0x40 of +0x186a; fade value +0x1894, copied to the model's
   alpha +0x158). gen.py PATCHES at the load 0x8c2e34 -> config.c npc_fade_dist2: the factor squared times it, 0 =
   no limit; live (settings menu, Graphics & Audio page). Hunts are untouched (monsters are not uLobbyNpc). Found
   by diffing NPC objects at five player positions (+0x158 / +0x1894 1 near, 0 far). Checked in game (R9, 960x540,
   Bherna arrival view): at 2 and 0 the people far up the path are drawn, at 1 not (as the game). Cost: uncapped
   (VSync Off, FPS 240) ~119 fps at 1, ~113 at 0 (+0.4 ms); VSync Off at 60: a steady 60 at 0. With VSync On it
   fell to 33-45 fps: this driver has no mailbox, so VSync On is FIFO, and the game paces to vi.c's own 60 Hz timer,
   not the display's, so a frame that ends a little late waits a whole vblank (a pacing problem any heavier scene
   hits, not the NPCs' cost). Not looked at: gathering spots and other map objects, Hub NPC classes.
   Speech bubbles (reported 2026-10-28: the "new dialogue" bubble over an NPC still used the game's distance): the
   bubble has its own copy of the check (0x8c11f8, table at 0x8c1328, then 0x938530 puts the bubble above the head);
   its load 0x8c127c gets the same npc_fade_dist2. Checked (the user's save, MHGU_QUICKHUNT=town, Bherna arrival
   view): 1 bubble at 1 (as the game), 5 at 0, each on its NPC.
7. A settings launcher for players who don't edit ini files: every [section] / key of runtime/config.c (it already
   knows the names, defaults, ranges and comments) in a window, saved to mhgurecomp.ini. Cheapest: inside the exe
   with the ImGui the port already ships (a `--settings` switch, or a "Settings" shortcut), so no second program or
   toolkit; the same panel can serve item 8 and Android's controller-only settings (docs/research/android.md).
8. Look into the port's options in the game's own Options menu. The menu is the game's GUI (.gui layouts, gmd text,
   per-item code), so adding entries means extending its item tables, text and handlers: find how the Options list
   is built (fnnew while opening it, the gmd its labels come from) and judge the effort. Fallback: the port's own
   overlay panel (item 7) opened in game with a key / controller combination; settings that need a restart
   (resolution, MSAA) say so.
9. Other aspect ratios. Ultrawide is in (PR #6 by dmitsuki, 2026-10-25, then fixed up): [Display] AspectRatio
   (Auto: the window's), FOV, UIAnchor (Center / Edges / 21:9 / 32:9). Wider than 16:9: the 3D cameras made for the
   screen (aspect 16:9 in sCamera / uCamera +0x38) get the picture's shape (Hor+, gen.py PATCHES at the three
   callers of the perspective matrix 0x9c617c that load it; the other 9 callers are untouched), the game's 2D
   canvas gets the HUD's width (0xdbcd48 / 0xdbcd54), and exec.c (cbuf_info, vertex stage cbuf 3 of 2D draws)
   unstretches the HUD and places its parts left / right / center by their layer depth (94 center banners, 96
   dialogue box left, 97 menus by x, 100 / 105 right, 103 status left / item bar right). From 16:10 to 16:9
   (2026-10-25): the camera keeps 16:9's width and gets more height (Vert+: config.c camera_fovy, from the
   perspective matrix's fovy argument, radians: fovy' = 2 atan(tan(fovy / 2) * (16/9) / aspect)), and exec.c
   flattens the HUD to its 16:9 shape (sy) and moves each layer to the top (status, minimap, menus), the bottom
   (dialogue, item bar, Hunter Arts prompts) or the middle (banners), one anchor per layer so a window drawn in
   pieces stays together. Narrower than 16:10 (4:3) gets 16:10 with bars. Tested 1280x720, 1280x800, 1024x768
   (bars), 1680x720 Center, 1792x504 / 1680x840 Edges: hunt HUD, pause menu, help box, equipment windows,
   nameplates. 16:10 fixes by Oddity-git (PR 21, 2026-10-26; tested on a Steam Deck size, Linux): target cam icons
   top, the loading screen as one picture (layer 110 strips at y 168 / 433 / 570), layer 98 with its 97 menu, the
   Request Log / quest card (layer 100 beside a 97 menu) top, the Quest Complete border and results rule bottom,
   the cutscene's top bar top, and the item bar drawn without the game's scissor (that draw only; the next draw and
   clears get it back). 2026-10-27 (issue 58): a window drawn in pieces on one layer (the chat window, the shoutout list,
   the Guild Card greeting, the Hunting Style viewer) takes one anchor when its pieces' rules disagree (exec.c
   ui_group_end: by the nearer edge, or the centre; patched in transient memory before the pass ends; the game's scissor
   of a piece moves with it, as its group was anchored last frame, so the help windows' body is not cut), the village / Hub
   button guides on layer 96 go top, layers below 95 by thirds (the Guild Card name plate), the Meownster Hunters return screen (marked by its map frame, layer 105 at 215, 0) goes top but for
   its prompts, the quest results screen (marked by its Time Left bar, layer 99 at y 643) centres its
   middle: the stamp, reward table, item lists' parchment and rows, the title's PRESS A scales
   about the centre with its layout (layer 108), and a model preview follows the frame drawn over it (also from an earlier pass: the Smithy's model is drawn in a pass of
   its own), not the last quad; its camera, made for its box stretched to the taller picture, gets the box's 16:9 shape
   (config.c camera_aspect: only a camera whose aspect is a preview box's the renderer drew), so the model is as big and
   as wide as at 16:9, and a prompt just under its box (the Palico Scout's "Rotate") goes with its frame; a preview window beside the menus (the Smithy's
   parchment, the Poogie costume's) goes Top with them, whichever is drawn first; layer 110 outside the loading screen
   (the bowgun's reticle, lock-on markers) is not stretched and scales about the centre; the bowgun's ammo list (layer 103, right side) goes with the item
   bar; a window's pieces up to 470 apart are one group (the Weapon Controls sheet's back parchment, 436 high), and a window stacked right on another of its layer
   that went the other way takes the pair's anchor with it (the chat log's "Chat" label over its box)
   (the Palico Scout's "Rotate" prompt). MHGU_CONTROL `hudtrace` logs a frame's HUD quads and their anchors. Left: the HUD's layout elsewhere (title, town, quest board, item box) unverified; at Edges
   the Hunter Arts prompt goes right with its layer; whether an off-screen 3D view (equipment box preview, guild
   card) uses one of the three cameras (they are left alone unless 16:9).
10. Keyboard remapping: an ini [Keyboard] section, one line per Switch button (`A = Mouse2`, `B = Space`; SDL key
   names, several keys per button, mouse buttons too), plus the left stick's four directions and the walk key. Today
   the layout is fixed: key_buttons in runtime/host_input.c, WASD / Shift handled beside it. The current layout stays
   the default, so existing ini files keep working; the settings launcher (item 7) can show it later.
11. Button-combo windows at high frame rates: fixed (2026-10-28), see "Two-button inputs and the frame rate" above.
   Hunter Arts on R+A+B (another control type, 2026-10-29): tested by the user at a high frame rate, works (R and A
   held then B, or all three at once). The countdown starts on A, B, X, Y and R / ZR (pad bits A 0x100, B 0x80,
   X 0x20, Y 0x10, R 0x40, ZL 0x200, ZR 0x800 at player +0x13f4 held / +0x13f8 new) and keeps each press of the
   window (+0x1444 bits 13+, 0x47d574), so the buttons need not be held together. Left: a check elsewhere that
   wants them held at the same moment would still miss a quick finger roll at very high frame rates (30 Hz polling
   hid that); a 30 Hz input polling option would cover it at up to 33 ms of input latency - not needed so far.
   Still to check: other weapons' timed inputs (Charge Blade, Insect Glaive, Styles') for other per-update windows.
   Mashing out of a stun at high frame rates: fixed (2026-10-30), see "Mashing out of a stun and the frame rate".
12. Main Menu without Download / Data Transfer, with a Quit item (on hold, 2026-10-30): the title sequence's state
   machine, the menu cursor, the help line and the bar labels (pictures in HD_title00, no "Quit" among them) are
   mapped; what is left and how: docs/research/title-menu.md.
13. Done when not in a network session (2026-11-08, see "Loading screens"); in one the waits are the game's. What was
   found: departing from a town calls the town area's depart method 0x8c02a4 (area mode +0xb8 = 4, a quest flag
   +0xda = 1). Mode 4's handler 0x8bd720 switches on the state byte at area +5 (byte 1 of the word +4): states 1-3
   start the fade, 4 (0x8bd8e0) waits for the fade object (0x5f85fc: its +0x54 object's +0x60 bit 0) and 0x6dee48
   (the music), 5-7 one update each, 8 (0x8bda88) sets state 9 when +0xda is set (else mode 6), and state 9
   (0x8bdac0) is the wait: area +0xe4 (an int, 150 = 0x96 already in state 4) less the engine step (G_SYSTEM
   0x2326764 +0x68, f32) each update; while > 0 (0x8bdaf0) nothing else; at 0 it reads the stage (sGameControl
   +0x48 / +0x4a), names the quest's area (0x15eff2c, 0x9aeebc -> area +0xc4) and goes to mode 6 (0x8bda98), and the
   jump starts the quest's loading (0x8bdfd0 via 0x8bcc64, mode 7). The quest card's loading screen is up from about
   state 9's start, so the 2.5 s are the card shown with nothing loading (the loader thread idle). Where +0xe4 gets
   its 150 wasn't found (no store to +0xe4 in 0x8bc000-0x8c1000 but state 9's own): a peek showed it 150 from mode
   4's start. A fix: at state 9 (an fnhook on 0x8bd720 seeing state 9, or on the countdown's caller), set +0xe4 to
   0 (or a shorter time) when the option is on: the jump and the loads then start at once. Seen in the Village (the
   area at 0x13800160 in those runs, aVillage); the Hub (aLobbyBase) presumably shares the class (quickhunt.c), not
   checked; nor whether anything (sound, the card's own animation) expects the 2.5 s.
## Build / run

MSYS2 UCRT64 on PATH (`C:\msys64\ucrt64\bin;C:\msys64\usr\bin`):

    make gen GAME=../mhgu/game     # recompile (needs tools/venv: capstone, unicorn, lz4)
    make -j4                       # ~8 min full, incremental (changed chunks only) is fast
    build/mhgurecomp.exe           # or double-click it; run-game.bat / run-debug.bat start it too

`make` also makes build/ the game folder: the MSYS2 DLLs the executable needs beside it (tools/bundle_dlls.py
follows the import tables; ~100 DLLs, most of them FFmpeg's; never vulkan-1.dll: the driver's loader must be used)
and the game files in build/data/exefs + build/data/romfs (target `data`, once: hard links to GAME's files, so no
second copy on disk; plain copies where hard links don't work). Started without a game folder argument, the
executable works in its own folder (runtime/main.c, platform plat_standalone): data/ for the game, cache/, mods/,
shots/, mhgurecomp.ini and log.txt beside it (save data elsewhere, see below); with a console of its own (Explorer, a shortcut) it drops the
console and logs to log.txt, and a fatal error shows a message box. `make clean` keeps all that (it removes the
compiled files only). With a game folder argument (or MHGU_GAME_DIR) it uses the current folder as before; then the
DLLs must be on PATH (C:\msys64\ucrt64\bin) unless it is the bundled build/mhgurecomp.exe.

Save data: the standalone executable keeps saves in the player's own folder, %APPDATA%\MHGURecomp\save\ (save_0/
system + system_backup, sdcard/), so deleting or rebuilding build/ can't take them along (platform plat_user_dir;
the path is in the log: "[fs] mounted host directory"). With a game folder argument (the test scripts in run/) saves
stay in save/ under the current folder, so automated runs never touch the real save. MHGU_SAVE_DIR overrides both.
Linux (not written yet): plat_user_dir should return $XDG_DATA_HOME/MHGURecomp, else ~/.local/share/MHGURecomp.
First start without a save (checked 2026-10-21 with an empty save_0): the game shows "There is no data to load." and
then the language / bonus notices; these boxes have no button prompt and only A (right click; keyboard L before 2026-10-23) closes them, B and Plus
do nothing, so it looks frozen. After that: title, New Game; a fresh system + system_backup is written by then.

Mods (runtime/mods.c, mods.h; tested 2026-10-21 with GU Rebalanced): drop a mod's folder into mods\ in the game folder (the
standalone build creates the empty folder), remove the folder to uninstall; nothing on disk is changed, all is layered
at start. romfs/ is found up to three levels down (Mod/Mod/romfs, atmosphere/contents/<title id>/romfs) or as a bare
nativeNX/ folder; names match in any case; new files are added (GU Rebalanced adds weapon/w11/163.arc). exefs/:
IPSwitch .pchtxt and IPS / IPS32 (<build id>.ips) patches, matched to main / sdk by build id; offsets are the module's
memory offsets (pchtxt with offset_shift 0x100, as all of theboy181's: 0xBBCD34 = runtime 0xdbcd34). Only data patches
(rodata / data) are applied; code patches can't be (the code is compiled ahead and literal pools are folded in), the
log lists them: "[mods] <mod>: <file> for main: ... code patch(es) NOT applied (at ...)". The three common MHGU exefs
mods are covered by the port itself: 4K-2K = ini resolution (gen.py PATCHES at the same two instructions), 60fps = ini
frame rate, Connecting-Error-Fix = nifm HLE'd as no internet. A code mod someone needs can become a gen.py PATCHES
entry (or a build option that reads .pchtxt at `make gen`). Order: folder names, or mods\load_order.txt; '_' prefix
skips a folder. Log lines: "[mods] <mod>: romfs <path>", "[romfs] mod <path>: <n> files".

Partial archives (arcmerge.c arc_partial, 2026-11-03): a mod's .arc that lacks some of the game's entries, but has at
least one of them, is merged over the game's even when it's the first mod to touch that archive; a full one still
replaces the file, and so does one with none of the game's entries (an unrelated or emptied archive). A mod that left
out entries on purpose now gets them back. So mods needn't ship the rest of the game's data; the load order doesn't
matter for this. Checked with quest 101: 85 partial arcs (9 MB, in place of 237 MB) plus a second partial mod over one
of them reached the hunt, the same 88 arcs read as without mods, a weapon texture changed on screen. Merged arcs are
full size in cache/arcmerge, and old ones aren't removed. A start with the merges cached reads only the entry tables,
unless a second mod changes the same arc (then all three files are read again, to report overlaps).

Forge plugins (runtime/forge.c, interp.c; 2026-10-21): Forge (github.com/Fexty12573/forge) is a loader for code mods:
its own module (exefs subsdk9) loads .nro plugins from the RomFS folder nativeNX/plugins/ and gives them hooks,
patches, singletons, save data, log and input. The port doesn't use Forge's module (it patches the console's code);
it finds the plugins itself (game RomFS + every mod's romfs, any case), loads them at 0x03200000 (relocated against
main / sdk, imports of forge_* bound to host code) and runs their code in an AArch32 interpreter (runtime/interp.c:
the lifter's semantics instruction for instruction, same Cpu state; tools/test_lift.py --interp checks it against
Unicorn like the lifter: 0 mismatches over 20k sampled game / SDK instructions incl. NEON + VFP). Calls between the
plugin and the recompiled game go through rt_dispatch both ways. Hooks: every generated function's FN_ENTER (cpu.h)
tests a bit in g_fnhook (one bit per code word, dispatch.c fnhook_set) and runs the detour in the function's place;
the "original" is a trampoline in guest memory with Forge's layout (two original words + `ldr pc` to target+8,
plugins verify it) that dispatch.c runs as the unhooked function. forge_hook_create also writes Forge's `ldr pc,
[pc,#-4]; detour` over the entry (plugins verify that too; a hook inside a function: see Damage Numbers below);
patches over code are re-read for that form (or a `b`),
anything else in code is logged as not applicable. Forge's own points: sApp::run (main+0xB8692C: resolve singletons,
forge_onLoad / version check / forge_onInit; every plugin's DT_INIT and DT_INIT_ARRAY run first, as nn::ro runs them
at load: an entry that is 0, -1, a Thumb address or outside the module is skipped and logged, DT_INIT 0 is no
initializer, DT_PREINIT_ARRAY is not run (nn::ro does not for a shared object); while DT_INIT runs the init array holds
no-ops and its constructors run once after it, so a module whose DT_INIT walks __init_array_start__ (Forge's
source/crti.c does) does not run them twice. A plugin with no forge_onLoad still gets update and ImGui calls, as in
Forge), the frame update (main+0x3DA8FC: forge_onUpdate(dt), then the input is read and the overlay drawn, in Forge's
order), cSystem ctor / dtor (singletons: typed at sApp::run, like Forge's; unlike Forge's, ones made later are typed
too, a frame after they are made and once their vtable looks finished, on a lookup or forge_singleton_getAllInstances;
one that never looks finished is given up after 120 frames). forge_socket_*: forwarded to the port's nn::socket (the
virtual local-play network of net/vsock.c; no internet), failures -1; forge_socket_init / deinit are nn::socket's
Initialize / Finalize with the plugin's arguments (no-ops there). Plugins built -mtp=soft -ftls-model=initial-exec get
__aeabi_read_tp (one block per thread: 8-byte TCB, then 4 KiB for each plugin that uses __thread data; a thread's block
goes back to a free list when the thread ends) and R_ARM_TLS_TPOFF32 is resolved against it. An NRO has no PT_TLS and
its link-time symbols for .tdata are not in the dynamic table, so the template cannot be found: __thread variables
start zeroed (a plugin with an initialized one would see zeros; none of the installed plugins uses TLS). A plugin with a
relocation type this port doesn't know, or a damaged NRO, is skipped with a "[loader]" line (the imports nothing
provides are named there too; MOD0, the dynamic section, DT_STRTAB / DT_STRSZ, symbol names and DT_HASH are bounds
checked). Hook creation fails cleanly (no original, a log line) when the trampoline region is full, the tables are
(1024 function hooks, 1024 trampolines, 1024 kept entry words, 512 interpreted functions), the next function starts
under two words after an entry hook, or an inside-hook's function cannot run in the interpreter (the two words are
put back); hooks may target a plugin's own code; Thumb targets are refused (the interpreter is ARM only; Forge hooks
Thumb code too).
forge_input_* is read once a frame after the plugins' forge_onUpdate, as Forge does when it draws: isConnected is true
from the first frame (the game's player 1 pad is always there), the sticks are clamped to -1..1, the buttons include the
stick-direction bits (16-23) of the game's pad. forge_input_getTouch is the free mouse's left button (not while the
mouse is captured or Forge's menu is open), as the first touch point in whole 1280x720 screen pixels: the pointer must be
on the game's picture (fitted in the window by g_render_aspect, centred; outside it: no touch), and the picture's HUD
canvas (g_ui_anchor_aspect wide at most, centred) spans 0..1279 (beyond it: the edge). The port adds three calls of its
own for mods (not Forge's), read at the same time: forge_input_getMouse(float *x, float *y, uint32_t *buttons) is the
free pointer in the same screen pixels with the buttons held or pressed since the last frame (1 left, 2 middle, 4 right,
8 / 16 the side buttons), false while the mouse is captured, Forge's menu is open or the pointer is off the picture;
forge_input_getMouseMove(float *dx, float *dy) is the movement since the last frame wherever it went, the hunt camera
too (counts while captured, window pixels while free, y down; 0 while Forge's menu is open); forge_input_setMouseFree(bool)
makes the mouse free for a mod's own pointer while true: not captured (let go if it was, captured again after if the
player had clicked in), shown in full screen, and its clicks only the mod's (not a capture, not the game's buttons).
Keybinds for mods, the port's calls too: forge_input_setKeybind(const char *row, const char *keys) gives a [Keybinds] row
other keys for now ("L", "Left Ctrl, Q", "None": spelled as the file has them; NULL: the settings' again; false for an
unknown row or key, an empty string or the chat key), on top of the settings in config_live_bind, so the game reads them at
once; mhgurecomp.ini keeps the player's, and the settings menu's Keybinds rows show the mod's beside them, in red (a key
changed there counts once the mod gives the row back; its "in use" check knows the mod's keys). One mod's keys per row: the
last call wins. forge_input_getKeybind(row, out, size) is the player's own keys for a row, forge_input_getModKeybind(row, out,
size) what a mod has set (false: none); forge_input_getKeyPressed(out, size) the first key, mouse button or wheel notch
pressed since the last frame, by its [Keybinds] name, also one Forge's menu took: never the port's own keys, except Escape
for a mod's menu to cancel with.
Forge's keyboard is 256 HID usages.
Forge's config.ini ([menu] key, font_size; [log] level) is read as iniparser reads it, from one file: the topmost mod's
romfs nativeNX/forge/config.ini (files are not merged; a long line, a stray line or an unreadable file means the defaults:
level info, key Insert, 12 px), key = strtol base 0 (decimal, 0x hex, 0 octal), font_size = atof, a level that is not a
name is error (as in Forge); the default key is Insert (73), not Forge's F9 (66), a choice of the port's author.
Forge's own messages are written at Forge's levels ("[forge] [INFO] ..."); third_party/cimgui's
cimgui.h / cimgui.cpp are byte-identical to cimgui commit d298666 (Forge's pin; checked against GitHub, ImGui itself
being a submodule there is 1.92.8 by its header only).
Extras beyond Fexty's exported.txt, kept as harmless: forge_log_trace(format, ...) (printed at any level, as [DEBUG]), forge_graphics_isInitialized, forge_graphics_isMenuOpen. MHGU_FORGE_LOG=debug|info|warn|error (default info; overrides the file when it names a level). Install = the mod's folder in mods\ (Forge itself is not needed). Log: "[forge] plugin ...",
the plugin's own messages as "[forge] [INFO] ..." (Forge's tags). Plugins are built -mfloat-abi=softfp, as
Forge is: floats in core registers (forge_onUpdate's dt in r0; until 2026-10-23 it went in s0 only).

Forge's ImGui overlay (runtime/overlay.cpp, forge_imgui.c, tools/imgui_thunks.py; 2026-10-23): Forge's "forge"
window (About, Loaded Plugins, Plugin UI = each plugin's forge_onImGuiRender) and forge_onImGuiFreeRender, on Dear
ImGui 1.92.8 + cimgui (third_party/cimgui, Forge's versions; ImGui's Vulkan backend). The menu starts closed; Insert
opens and closes it (or Forge's config.ini [menu] key / font_size from a mod's romfs nativeNX/forge/, with its Roboto
font from there too; else ImGui's own font). Sizes follow the window: x height/720. The frame is built on the game's
thread after forge_onUpdate (plugin code runs there); texture uploads there too, under vk_lock; the render thread
draws a copy of the draw lists at the end of the window image's pass (device.c). Input: while open, keyboard / mouse
/ text go to ImGui (host_input.c asks overlay_event first; F-keys and Alt+Enter still work), the controller navigates
(A activates, B cancels) and the game gets no input. Plugins call cimgui's C API (ig* / Im*, which Forge exports):
tools/imgui_thunks.py generates runtime/forge_imgui_thunks.inc from cimgui's generator output, 1445 of 1465 functions
(OVERRIDE ones are hand-written in forge_imgui.c; the rest, listed at its end: draw callbacks, size_t* helpers...): softfp arguments
converted, guest data pointers as their host address, printf-style ones formatted from the guest's arguments.
ImGui's objects (ImGuiIO, ImGuiStyle, ImDrawList...) reach plugins as mirrors in guest memory with the 32-bit
layout (computed per struct, checked against the compiler's with static asserts), synced both ways around each
call; internal structs are opaque. Functions taking or returning an ImTextureRef by value (ImDrawList_AddImage /
AddImageQuad / AddImageRounded, ImTextureData_GetTexRef, igImage...) are provided: its 16 bytes (pointer, pad, ImU64: 8-aligned,
so r2:r3 + the stack after a first argument, or the hidden result pointer in r0) are rebuilt field by field, _TexData as the
host ImTextureData behind the plugin's mirror. igNewFrame / igRender / igGetDrawData from a plugin are ignored; igMemAlloc is
the guest's malloc. Tested with Key Quest Markers r18 (its only ImGui is its colour settings): the menu over the
title and in a hunt, mouse (headers, tree node, buttons), typing into its hex colour fields, Save & apply (wrote
key_quest_markers.ini to the save folder), controller navigation; the game unaffected with the menu closed. Callback
trampolines (InputText callbacks, size constraints, list getters), mirrors of structs a plugin owns, and several
ImGui plugins at once are written but not exercised by that plugin. MHGU_CONTROL for tests: `sdlkey [ctrl+]<key>`,
`sdltext <text>`, `mouse <x> <y> [click]`; `mousemove <x> <y> <ms>` moves the camera as mouse look does.

Damage Numbers r30 (2026-10-26; it crashed the port at start, fine on emulators). Four gaps:
- A hook inside a function (main+0x16dd7c, the end of f_36dc6c, which works out a hit's weak-spot flag): Forge writes
  its jump wherever it is asked, and the port hooked function entries only. forge.c hook_inside: the jump goes into
  guest memory as on the console, the trampoline (two moved words + `ldr pc` to target+8) into the interpreted stub
  region, and the function holding it runs in the interpreter from then on (dispatch_interpret, as for cheats), which
  reads the jump and runs the plugin's detour and the trampoline as code. Tested with MHGU_FORGE_TESTHOOK=8bd100 (inside
  the town's mode-1 update, f_8bd0fc): its guest-code detour ran and the same function went on to depart the quest.
- igAddContextHook with the plugin's own ImGuiContextHook (no mirror: igAddContextHook(ctx, NULL), a crash at 0x10):
  hand-written, the struct copied to guest memory and a host hook whose callback runs the plugin's on the frame's
  thread.
- File names: the plugin passes console paths ("app:/nativeNX/plugins/...", forge_fs_getRomFsMountPoint) to
  AddFontFromFileTTF / ImFileOpen; every `*filename` argument now maps app:/ and rom:/ to the RomFS's host file
  (forge_imgui.c ig_path). ImFileOpen / Close / GetSize / Read / Write hand-written: the plugin gets a small handle
  number for the host FILE *.
- ImTextureData_GetPixels returned ImGui's host memory (NULL for the plugin): it now gets a copy in guest memory (its
  malloc), copied over ImGui's on RegisterUserTexture and whenever the texture waits for an upload (tex_sync).
- It also hooks f_36dc6c's entry, and that detour calls the original through the trampoline (rt_dispatch: a run of
  its own) into the now interpreted function, which returns into the detour, interpreted code too: the inner run went
  on into the detour and then hit "no function at" the outer caller's return address (crash when aiming the bow at a
  monster, 2026-10-26). interp_run now also ends at its return address in interpreted code when the stack is back
  where it started. MHGU_FORGE_TESTHOOK=8bd0fc,8bd104 (entry + inside, the town update) reproduces it without the fix.
In a quest with the mod: no crash, "8 Forge hooks", its font and effect atlas load. Left: "visible crop unavailable;
using Forge display bounds" (it falls back to the window); the numbers themselves not yet seen on a hit (quickhunt can't
start Arena quests: "no function at 0" when departing, with or without mods).

Cheats (runtime/cheats.c, 2026-10-24): Atmosphere-format cheat codes (as Ryujinx and a modded Switch read them) from
every .txt in cheats\ beside mods\ (MHGU_CHEATS_DIR; '_' prefix skips a file), all on; "[Name]" starts a cheat, "{Name}"
a master code (run first), '#' / "//" lines are comments (Atmosphere itself rejects those). The VM is written from
Atmosphere's docs/features/cheats.md (every code type; Atmosphere is GPL, its dmnt code is not used): 16 registers and
16 saved, both 0 at the start of every cheat (2026-10-25: before, they carried over from the cheat before it in a frame,
so a cheat leaving r0 set shifted the next one's 0TMR writes: a player's log had the positive-only skill cheat 0x14B0
off, its jump into read-only data: FATAL no function), 128 static (shared); blocks / elses / loops matched when a cheat
loads (a cheat that does not decode is logged and left out); key codes test the buttons the game sees (input_get; stick
directions at half tilt); pause / resume (FF0 / FF1) are ignored, debug log (FFF) goes to the log. Runs once in boot()
before the main thread starts, then on the window loop once per presented frame (as dmnt runs beside the game). Regions:
main 0x200000, heap HEAP_BASE, alias ALIAS_BASE, aslr 0x200000 (GetInfo's), 4 = absolute; kernel_mapped() checks every
access (unmapped: reads 0, writes dropped). A write into main / sdk code that changes it: dispatch_interpret() makes the
function holding the word (dispatch_function_at: nearest entry below, up to the next) run in the interpreter from then
on: its range becomes interpreted and its entry gets a hook to an `ldr pc, [pc, #-4]; .word entry` stub in interpreted
memory (an existing hook stays; fnhook_call_original then interprets). Words in the padding after .text
(main+0x13F1DEC..0x13F2000, zeros) are made interpreted ranges themselves: room for a cheat's new code. Limits: a
function the lifter split (a second entry inside it) has its other part still recompiled; a call already running
finishes the old code; an interpreted function is many times slower (fine for f_2df824, called on equipment changes).
interp.c's ranges went 16 -> 256 and merge when they touch. A function a Forge plugin hooks and a cheat changes
(2026-10-25): Forge's hook writes `ldr pc, [pc, #-4]; detour` over the entry in guest memory, so interpreting it jumped
back into the detour, whose original interpreted it again: a stack overflow. hook_install (and a plugin's code patch
that makes a hook) now keeps the two words it replaced (fnhook_keep_entry) and the interpreter runs those at a hooked
entry (code_word: only where g_fnhook has a bit). Tested both orders with MHGU_FORGE_TESTHOOK=2df824 (a plugin-style
hook at start-up, before the cheats) and the control file's `testhook 2df824` (after them, as plugins hook): the detour
runs, the skill table is the cheat's; without the fix, exception c00000fd. Tested: the skill-point cheats of
docs/research/skill-points.md on the test save in a quest (exact), a VM test cheat (loops, registers, master first, C4
once per press, a bad cheat refused), the Linux build. Log: "[cheats] <file>: <n> cheat(s): ...", "[cheats] <cheat>:
changes the code at main+<x>: the function at main+<y> runs in the interpreter now".

Skill points (docs/research/skill-points.md; extras/cheats): f_2df824 totals them, rows at [obj+0x188] (12 bytes:
+4 activation, +6 tree, +8..+14 points per slot weapon/head/body/arms/waist/legs/talisman, +15 total, s8). "Skill
points x2": 0x2dfab4 `uxtbne r0, r0` -> `lsl r0, r0, #1`, plus Double Talisman's two passes adding `r0, lsl #1`
(talisman x4 with it). "positive only": 0x2dfab4 -> `b` to main+0x13F1F00 (`cmp r0, #0; addgt r0, r0, r0; b back`)
and both Double Talisman passes' `ldrsb` -> the same through two more stubs there. Test save hunter (Double Talisman
and Skill +2 active): base tree 35 (Handicraft) = 1,2,2 + talisman 8 (+2) = 15; positive only 2,4,4,16 (+2) =
28, its negatives unchanged (-5 +2 = -3); full x2 the same positives, negatives -10 +2 = -8.

Bonus content (runtime/services/bonus.c, 2026-10-21): the free downloads (event / challenge quests, item packs,
Palicos) live in the shared part of the save file, not in the game files, and Capcom's server (meteor.capcom.co.jp)
is out of reach. So they are copied from a save that has them: put that save's `system` file in bonus\ in the game folder (next
to the exe, like mods\; the current folder with a game folder argument), else %APPDATA%\MHGURecomp\bonus\ is read;
MHGU_BONUS_DIR overrides. Only with ini [Bonus Content] BonusContent = On (default On again since 2026-10-23, was Off
from 2026-10-22; with Off saves are never touched; tested both ways on an empty save). When the game opens a save whose download regions are empty (0xb2a5-0xb310 unlock flags, 0xc000 to the first character slot: item packs,
Palicos, 160 + 40 quest slots of [id][size][ARC]), the donor's are written in; a save with downloads of its own is
left alone. A brand-new save gets them from the next start (the game writes it without reading it back). Tested with
the user's save (125 event + 40 challenge quests): Low and G Rank Event lists filled (URGENT: COAL MINERS NEEDED in
G Rank), Chamberlyne > Downloadable Content > Claim Items lists the packs and claiming works (Pirate's Booty Pack:
Slickaxe x20). Palico downloads not checked. The quest ARCs equal the RomFS files byte for byte, so a donor-free
version (building the regions from the RomFS) is possible once the flag bits and the pack / Palico records are known.

Controls: see `runtime/host_input.c` (keyboard and mouse: WASD, mouse look (relative mode after a click, Esc releases; in a
hunt the camera's angles directly, runtime/hle/mousecam.c; elsewhere the mouse speed smoothed
over 25 ms as the right stick tilt, offset past the camera's round ~39% stick dead zone; ini [Mouse] MouseSensitivity), clicks = X / A, Space / R = B / Y, Tab / T = ZL / ZR,
arrows = d-pad, Ctrl / Alt = stick clicks, Enter = Plus; SDL gamepads (all open, the one a button was last pressed on is
read: a Steam Deck with a controller plugged in has two, and taking the first one SDL listed left the player's pad dead;
MHGU_PAD=<name part or vid:pid> keeps only that one), face
buttons by position (Switch layout) or label: ini FaceButtons; the controller also works with the window in the
background, ini BackgroundInput = On (default; SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, set before SDL's gamepad
subsystem starts, runtime/ui.c; MHGU_BACKGROUND_INPUT=0|1), keyboard / mouse only with the focus;
F12 screenshot, F11 8-frame burst -> shots\ in the game folder; Alt+Enter windowed / full screen; F7 cycles MSAA). Display mode,
resolution, anti-aliasing and frame rate: mhgurecomp.ini (delete it to get the defaults back).
Game folder: where the settings, caches, mods\, bonus\, shots\ and log.txt are: the exe's folder when started on its
own (build\ itself holds only what the build makes; compiler files go to obj\). MHGU_HOME=<folder> moves them there
(run-game.bat: run\, test scripts: testsave\home); the game files are still read from data\ beside the exe.

When the game quits by itself (2026-10-28, a Fedora report: "ExitProcess" right after GetService acc:u0, no
reason): the SDK's failed checks (every AbortImpl variant ends in nn::diag::detail::VAbortImpl, 0x244a0d0), abort()
and exit() are HLE_SDK in runtime/hle/abort.c and log the condition, function, file and line, the Result (as
2xxx-yyyy) and the message, then the game's lr and callers (kernel_log_guest_stack, the same heuristic as
MHGU_DUMP_THREADS); svcExitProcess logs its caller too. Look the callers up with tools/disasm.py.

Incomplete romfs (2026-10-29, two reports): the update's romfs alone ("[romfs] 12 files", 0.2 GB) quit with the
game's "Shader compile failed. system\app_shader\AppShaderPackage" right after start-up (a black window); the base
game's without the update merged (34149 files, 12.1 GB) got through character creation, then crashed on the way into
town ("no function at 0", lr 0xdd8500: the resource manager at 0xdd84e4 calls a method of a resource whose vtable is
empty). A full 1.4.0 romfs has 35531 files, 2321 folders, 12.3 GB. Started on its own, the game now counts data\romfs
before its window opens (main.c; plat_count_files, the system's directory listing: ~80 ms on Windows, where a stat
per file took 450-900 ms) and stops with a message box below 35000 files or without
nativeNX/system/app_shader/AppShaderPackage.mfx. MHGU_ROMFS_ANY=1 skips the check. Checked on Windows and Linux (WSL):
the full romfs starts; 12 files without the shader package, 51 and 4 with it get the message.

Debug env: `MHGU_TRACE_SVC`, `MHGU_TRACE_IPC`, `MHGU_LOG_FILES`, `MHGU_FNPROF` (hot functions every 5 s),
`MHGU_FNTRACE=lo-hi[:n]` (calls into a guest address range, with caller and thread), `MHGU_DUMP_THREADS=<s>`
(every guest thread's wait state after s seconds), `MHGU_HLE_SKIP`, `MHGU_AUDIO_LOG`, `MHGU_AUDIO_TRACE=1` (once a
second: audio frames vs game updates, device queue underruns and pacing corrections, aux ring lag, voices in use /
playing; plus every voice that ended without playing (SKIP), only silently or cut short; `=2` every voice),
`MHGU_MOVIE_TRACE` (calls through the movie vtables), `MHGU_HIDDEN=1` (no visible window), `MHGU_SDL=bundled` (Linux: the built-in SDL even when the system's is as new), `MHGU_REGION=<n>` (GetRegionCode; default 2 Europe), `MHGU_NO_WRITE_WATCH=1` (Windows: no page write tracking, textures hashed as on Linux), `MHGU_INPUT="frame:BUTTON:frames,..."` (scripted
controller, frames = presented frames; e.g. `300:A:10`), `MHGU_NAME` (answers every text entry with that text at once),
`MHGU_CONTROL=ctl.txt` (drive a running game: append lines `A`, `DOWN 8`, `STICK_UP 60`, `shot name` -> shots/name.png;
`X 6 25` = X for 6 frames from 25 frames on, lines written together form a timed sequence; `fntrace lo hi n`;
`fnnew lo hi [learn ms]` = log only the first call of each function in [lo, hi) not seen while learning, to find what an
event runs; `peek` / `poke` / `memsave` / `find` for guest memory; `protect <addr> <size>` = that guest memory read-only,
so a wild write crashes at once with the writer named), `MHGU_POOL_LOG=1` (each NVN memory pool the game makes, with its
callers), `MHGU_QUICKHUNT=<quest number>` (from start-up
straight into that quest: A through the menus to the save's town, then the quest is ordered and departed on;
runtime/hle/quickhunt.c has how the game departs; `MHGU_QUICKHUNT=town` stops in the town), `MHGU_KILL_AFTER=<s>`
(the quest's large monster dies by one real hit that long into the quest), `MHGU_FORCE_EVENT=<n>` (the first quest-demo
lookup in entry n's own area plays it; both in quickhunt.c; a forced demo doesn't give the hunter back at its end: to
see a quest's demo as a player would, clear its seen bit instead, see "GPU pool at large render sizes"), `vpad` (control file:
attach an SDL virtual controller; `vpad <n> <button> <0|1>` presses its button), `MHGU_LOG_MOVES=1` (the player's actions and command table
changes, runtime/hle/movelog.c), `MHGU_EMTRACE=1/2/3` (large monster actions with their real-time length, height and
distance; 2: the position every update; 3: the monster object saved on 4 updates once a forced action is 200 up;
MHGU_CONTROL's `emact <group> <index>` starts an action, `emsweep <group> <first> <last>` each in turn;
`MHGU_EMTRACE_ZAKO=1`: small monsters' actions, targets, attention scores and rates: runtime/hle/emtrace.c), MHGU_CONTROL's `fntrace lo hi n r0lo r0hi` (only calls with r0 in that range: one object's
methods) and `interpwatch <addr> <file of function entries>` (runs those functions and all game code they call in the
interpreter, logging every instruction that changes the word at addr),
`MHGU_SHOT_AT=<frames>`, `MHGU_FPS=1`, `MHGU_VK_STATS=1`, `MHGU_VK_VALIDATION=1`, `MHGU_SYNC_SHADERS=1`, `MHGU_PIPE_WAIT_MS=n`, `MHGU_SKIP_LOG=1`, `MHGU_NO_PREWARM=1`,
`MHGU_NO_PROGRAM_CACHE=1`, `MHGU_SAVE_GLSL=1`.
`python tools/disasm.py <game dir> <addr | module:symbol> [count] [before]` disassembles guest code.

Plugin bug warnings (runtime/forge.c forge_guest_fault, interp.c gchk / bad_access, platform.h plat_touch_hook): the
port backs any untouched guest page with zeros, so a plugin's null / garbage pointer that crashes on the console
(Ryujinx) runs on here. Quiet `[forge] [WARN]` lines name it (MHGU_FORGE_LOG=error silences them):
`[forge] [WARN] foo.nro: 4-byte read at 0x00000008 (null page) by code at +0x1A4C (pc 03212A4C) r0=0 r1=.. lr=..`.
Detected, for code in a plugin's image (interpreted): any load / store below 0x10000 (the null page); one at
0x3C000000-0x43FFFFFF or 0xBC000000-0xC3FFFFFF (a float bit pattern: 0x3F800000 = 1.0f) that no region maps (the game's
heap counts as mapped); the first touch of any unmapped page, i.e. the fault that makes the port back it (size not
known, "unmapped page"). Not detected: later accesses in an unmapped 64 KB chunk after its first touch, other
unmapped addresses that the interpreter checks cannot see (outside the two float ranges) once their chunk is
backed, atomics (ldrex/strex), bad accesses by the game's own code or by host (HLE) functions, branches to bad
addresses, and a mapped but wrong pointer. Cost: one compare per interpreted load / store plus three thread-local
stores per interpreted instruction; recompiled code and mapped accesses are untouched (the fault hook runs only
when a page is first backed). Limits: once per (plugin, pc); at most 20 lines per plugin, then one "further memory
warnings ... suppressed" line; 128 sites tracked per plugin. Also WARN, once per site: a code patch that lands in
recompiled code is ignored (`foo.nro: code patch at main+0x... cannot apply to recompiled code: ignored`), and at
load `[forge] [WARN] foo.nro: import X is not provided (calls return 0)`. Failed hooks stay ERROR lines
(`Failed to hook ...`), as Forge's own.

Engine modules (runtime/engine_module.c, docs/ENGINE-MODULES.md; 2026-11-04): native libraries in engine_modules/ that extend
the port itself, loaded only when engine_modules/enabled.txt lists them, with no feature-specific seam in the port. Merged as
"engine plugins" (PR 242) and renamed before any release, since "plugin" already means a Forge plugin. Things the loader's own
test can't show: the renderer's atexit handler (nvn/vulkan/device.c exit_handler) is registered later, so it runs first and ends
the process with _exit: a module's shutdown is called from there, after vkDeviceWaitIdle and the pipeline cache. The API version
is an export (mhgu_engine_module_api) read before the entry is called: refused after the entry had run, a newer module could
have written past the host's table and left hooks into a library about to be unloaded. MhguHost.port_version is what a module
checks against the port's internals, which are not an API. The fault report names the modules that were loaded.
